# MODULE 2 — AGENT FIREWALL (ZÉRO-PATH)

A local Prolog-backed firewall for AI agents. Every action an agent wants to
perform is checked against a rule base *before* it happens. If the Prolog goal
`forbidden(action, args)` succeeds, the action is blocked at the root — no
shortcuts, no bypasses: **Zero-Path**.

## Architecture

```
+-------------+      +----------------+      +-------------------+
|  HTTP /gate | ---> |  firewall.rs   | ---> |  prolog.rs        |
|  JSON body  |      |  (action,args) |      |  mini engine      |
+-------------+      |  -> Verdict    |      |  parse+unify+DFS  |
                     +-------+--------+      +-------------------+
                             |
                             v
                     +-------+--------+
                     |  audit.rs      |
                     |  audit.log +   |
                     |  SHA-256 hash  |
                     +----------------+
```

* **`src/prolog.rs`** — Mini-Prolog engine implemented from scratch (no
  external Prolog crate). Tokenizer → Parser → AST (`Term::{Atom, Var, List,
  Compound}`) → unification → recursive DFS backtracking with a depth cap of
  1000 (terminates on adversarial inputs).
* **`src/firewall.rs`** — Wraps the engine: converts `(action, args)` to the
  Prolog goal `forbidden(action, args)`, runs the query, returns a `Verdict`.
* **`src/server.rs`** — HTTP/1.1 server on `std::net::TcpListener`, one thread
  per connection, hand-rolled request parsing.
* **`src/audit.rs`** — Append-only audit logger. Each `/gate` call writes one
  line with timestamp, action, args, verdict, matched rule, and SHA-256 hash
  of the canonical `action|args_json` string.
* **`src/main.rs`** — CLI entry point.
* **`rules.pl`** — Example rule base (forbidden commands, files, networks, and
  a composed rule using a clause body).

## Build

```bash
export PATH=$HOME/.cargo/bin:$PATH
cd agent-firewall
cargo build --release
# binary: ./target/release/agent-firewall
```

## Run

```bash
./target/release/agent-firewall --rules rules.pl --bind 127.0.0.1 --port 9002 --audit audit.log
```

CLI flags:

| Flag       | Default       | Description                       |
|------------|---------------|-----------------------------------|
| `--rules`  | `./rules.pl`  | Path to the Prolog rule file      |
| `--bind`   | `127.0.0.1`   | Bind address                      |
| `--port`   | `9002`        | Bind port                         |
| `--audit`  | `./audit.log` | Audit log path                    |
| `--help`   |               | Show usage                        |

## HTTP API

### `POST /gate`

Request body:

```json
{"action":"execute","args":["rm","-rf","/"]}
```

* `action` is a string.
* `args` is either a JSON string (`"evil.com"`) or a JSON array
  (`["rm", "-rf", "/"]`).

Response (blocked):

```json
{
  "allowed": false,
  "reason": "ZeroPath",
  "rule_matched": "forbidden(execute, ['rm', '-rf', '/'])",
  "evaluated_in_us": 42
}
```

Response (allowed):

```json
{
  "allowed": true,
  "reason": "ok",
  "rule_matched": null,
  "evaluated_in_us": 12
}
```

`evaluated_in_us` is the wall-clock time spent inside the Prolog engine (the
target SLA is `< 1000 µs`, i.e. < 1 ms).

### `GET /rules`

```json
{"rules_loaded": 30, "rules": ["forbidden(execute, ['rm', '-rf', '/']).", ...]}
```

### `POST /reload`

Reloads `rules.pl` from disk (the path passed at startup). Existing rules are
replaced atomically.

```json
{"ok": true, "rules_loaded": 30}
```

### `GET /health`

```json
{"status": "ok", "rules_loaded": 30, "audits": 7, "gate_calls": 7}
```

### `GET /`

Service banner + endpoint list.

## Curl examples

```bash
# Blocked: rm -rf /
curl -s -X POST http://127.0.0.1:9002/gate \
     -H 'Content-Type: application/json' \
     -d '{"action":"execute","args":["rm","-rf","/"]}'
# {"allowed":false,"reason":"ZeroPath","rule_matched":"forbidden(execute, ['rm', '-rf', '/'])","evaluated_in_us":35}

# Allowed: ls -la
curl -s -X POST http://127.0.0.1:9002/gate \
     -H 'Content-Type: application/json' \
     -d '{"action":"execute","args":["ls","-la"]}'
# {"allowed":true,"reason":"ok","rule_matched":null,"evaluated_in_us":11}

# Blocked: edit /etc/passwd
curl -s -X POST http://127.0.0.1:9002/gate \
     -H 'Content-Type: application/json' \
     -d '{"action":"edit_file","args":"/etc/passwd"}'
# {"allowed":false,"reason":"ZeroPath",...}

# Health
curl -s http://127.0.0.1:9002/health
# Reload
curl -s -X POST http://127.0.0.1:9002/reload
# Rules
curl -s http://127.0.0.1:9002/rules | jq
```

## Audit log format

Each `/gate` call appends one line to `audit.log`:

```
2026-11-05T20:48:13.452Z | ACTION=execute ARGS=["rm","-rf","/"] | ALLOWED=false | RULE=forbidden(execute, ['rm', '-rf', '/']) | SHA256=9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
```

The SHA-256 hash is computed over the canonical string
`action|args_json_canonical` (e.g. `execute|["rm","-rf","/"]`) and is a 64-char
lowercase hex string.

## Rule syntax (`rules.pl`)

* **Facts**: `forbidden(execute, ['rm', '-rf', '/']).`
* **Rules** with a body: `forbidden(Action, Args) :- dangerous_action(Action), sensitive_target(Args).`
* **Wildcards**:
  * `any` — matches anything
  * `_`  — matches anything
  * `any_evil`, `any_*` — named wildcards (match anything; the name is just documentation)
* **Atoms**: lowercase start or single-quoted (`'evil.com'`, `'/etc/passwd'`)
* **Variables**: uppercase start (`Action`, `Args`)
* **Lists**: `[a, b, c]` or `[]`
* **Comments**: `%` line comment, `/* ... */` block comment

## Performance & safety

* Every `/gate` call traverses the engine — **no shortcut path**.
* Backtracking is bounded by `max_depth = 1000` (configurable in `Engine::with_max_depth`); adversarial self-referential rules like `loop(X) :- loop(X).` terminate with `false`.
* On the demo rule set (~30 clauses), evaluation typically takes **5–80 µs** on commodity hardware — well below the 1 ms SLA.

## Tests

```bash
cargo test --release           # 13 unit tests (parser, unifier, engine, firewall, audit)
```

Integration tests (HTTP server + audit log + SLA) are driven by the shell
script that produced `test-report.txt` (see repo root).

## Stack

* Rust stable (1.99). Edition 2021.
* `serde`, `serde_json` for JSON.
* `sha2` for SHA-256.
* HTTP server hand-rolled on `std::net::TcpListener` — **no framework**.
* Mini-Prolog implemented **from scratch** — **no external Prolog crate**.

## Code 100% local — zero cloud.
