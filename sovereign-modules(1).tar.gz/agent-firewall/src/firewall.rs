//! Firewall wrapper.
//!
//! Takes an `(action, args)` pair, builds a Prolog goal `forbidden(action, args)`,
//! runs it through the mini-Prolog engine, and returns a `Verdict`.
//!
//! This is the **only** path an action can take to be cleared: there is no
//! shortcut, every check goes through the Prolog engine (Zero-Path guarantee).

use crate::prolog::{Engine, QueryResult, Term};
use serde_json::Value;

/// Result of evaluating an action against the rule base.
#[derive(Debug, Clone)]
pub struct Verdict {
    pub allowed: bool,
    /// `Some(prolog_source)` when a rule matched and the action is blocked.
    pub rule_matched: Option<String>,
}

impl Verdict {
    pub fn blocked(rule_matched: String) -> Self {
        Verdict { allowed: false, rule_matched: Some(rule_matched) }
    }

    pub fn allow() -> Self {
        Verdict { allowed: true, rule_matched: None }
    }
}

/// Convert a JSON value (string, array, number, ...) into a Prolog `Term`.
///
/// * JSON string  -> `Term::Atom(s)`
/// * JSON array   -> `Term::List([Atom(s), ...])`
/// * JSON number  -> `Term::Atom(n.to_string())`
/// * JSON bool    -> `Term::Atom("true"|"false")`
/// * JSON null    -> `Term::Atom("null")`
/// * JSON object  -> `Term::Atom(json_string)` (rare; kept for completeness)
pub fn args_to_term(args: &Value) -> Term {
    match args {
        Value::String(s) => Term::Atom(s.clone()),
        Value::Array(arr) => {
            let items = arr
                .iter()
                .map(|v| match v {
                    Value::String(s) => Term::Atom(s.clone()),
                    other => Term::Atom(other.to_string()),
                })
                .collect();
            Term::List(items)
        }
        Value::Null => Term::Atom("null".to_string()),
        Value::Bool(b) => Term::Atom(b.to_string()),
        Value::Number(n) => Term::Atom(n.to_string()),
        Value::Object(_) => Term::Atom(args.to_string()),
    }
}

/// Build the goal `forbidden(action, args)`.
pub fn build_goal(action: &str, args: &Value) -> Term {
    Term::Compound(
        "forbidden".to_string(),
        vec![Term::Atom(action.to_string()), args_to_term(args)],
    )
}

/// Evaluate `forbidden(action, args)` against the engine. Zero shortcut.
///
/// Returns a `Verdict` together with the raw `QueryResult` for inspection.
pub fn evaluate(engine: &Engine, action: &str, args: &Value) -> (Verdict, QueryResult) {
    let goal = build_goal(action, args);
    let result = engine.query(&goal);
    if result.success {
        let matched = result.matched_goal.clone().unwrap_or_else(|| goal.to_prolog());
        (Verdict::blocked(matched), result)
    } else {
        (Verdict::allow(), result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn demo_engine() -> Engine {
        let mut e = Engine::new();
        e.load_string(
            r#"
            forbidden(execute, ['rm', '-rf', '/']).
            forbidden(execute, ['rm', '-rf', any]).
            forbidden(execute, ['curl', 'http://evil.com']).
            forbidden(execute, ['chmod', '777', any]).
            forbidden(edit_file, '/etc/passwd').
            forbidden(read_file, '/etc/shadow').
            forbidden(network, 'evil.com').
            "#,
        )
        .unwrap();
        e
    }

    #[test]
    fn blocks_rm_rf_slash() {
        let e = demo_engine();
        let (v, _) = evaluate(&e, "execute", &serde_json::json!(["rm", "-rf", "/"]));
        assert!(!v.allowed);
        assert!(v.rule_matched.unwrap().contains("forbidden"));
    }

    #[test]
    fn allows_ls_la() {
        let e = demo_engine();
        let (v, _) = evaluate(&e, "execute", &serde_json::json!(["ls", "-la"]));
        assert!(v.allowed);
    }

    #[test]
    fn blocks_edit_etc_passwd() {
        let e = demo_engine();
        let (v, _) = evaluate(&e, "edit_file", &serde_json::json!("/etc/passwd"));
        assert!(!v.allowed);
    }

    #[test]
    fn allows_edit_user_file() {
        let e = demo_engine();
        let (v, _) = evaluate(&e, "edit_file", &serde_json::json!("/home/user/code.rs"));
        assert!(v.allowed);
    }

    #[test]
    fn blocks_network_evil() {
        let e = demo_engine();
        let (v, _) = evaluate(&e, "network", &serde_json::json!("evil.com"));
        assert!(!v.allowed);
    }
}
