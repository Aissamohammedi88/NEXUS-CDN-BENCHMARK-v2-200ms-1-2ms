//! Minimal HTTP/1.1 server built directly on `std::net::TcpListener`.
//!
//! One thread per connection. No external framework.
//! Endpoints:
//!   * `POST /gate`    -> evaluate an action against the rule base.
//!   * `GET  /rules`   -> dump loaded rules as JSON.
//!   * `POST /reload`  -> reload `rules.pl` from disk.
//!   * `GET  /health`  -> status + rules_loaded + audits.
//!
//! Every response includes a JSON body and the standard `Content-Type` and
//! `Content-Length` headers.

use crate::audit::AuditLogger;
use crate::firewall;
use crate::prolog::Engine;
use serde::Serialize;
use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::TcpListener;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, RwLock};
use std::time::Instant;

/// Shared server state passed to each connection thread.
pub struct AppState {
    pub engine: Arc<RwLock<Engine>>,
    pub audit: Arc<AuditLogger>,
    pub rules_path: PathBuf,
    pub audit_path: PathBuf,
    /// Total /gate evaluations served (for /health).
    pub gate_calls: AtomicU64,
}

#[derive(Serialize)]
struct GateResponse {
    allowed: bool,
    reason: String,
    rule_matched: Option<String>,
    evaluated_in_us: u64,
}

#[derive(Serialize)]
struct HealthResponse {
    status: String,
    rules_loaded: usize,
    audits: u64,
    gate_calls: u64,
}

pub fn run(state: Arc<AppState>, bind: &str, port: u16) -> Result<(), String> {
    let addr = format!("{}:{}", bind, port);
    let listener = TcpListener::bind(&addr).map_err(|e| format!("bind {}: {}", addr, e))?;
    eprintln!("[agent-firewall] listening on http://{}", addr);
    eprintln!(
        "[agent-firewall] rules loaded: {} | rules path: {} | audit path: {}",
        state.engine.read().unwrap().rules_count(),
        state.rules_path.display(),
        state.audit_path.display()
    );

    for stream_result in listener.incoming() {
        match stream_result {
            Ok(stream) => {
                let st = Arc::clone(&state);
                std::thread::spawn(move || {
                    if let Err(e) = handle_connection(stream, st) {
                        eprintln!("[agent-firewall] conn error: {}", e);
                    }
                });
            }
            Err(e) => eprintln!("[agent-firewall] accept error: {}", e),
        }
    }
    Ok(())
}

fn handle_connection(mut stream: std::net::TcpStream, state: Arc<AppState>) -> Result<(), String> {
    stream
        .set_read_timeout(Some(std::time::Duration::from_secs(5)))
        .map_err(|e| format!("set_read_timeout: {}", e))?;

    let raw = read_request(&mut stream)?;
    let (method, path, body) = parse_http(&raw)?;

    let (status, body_out) = route(&method, &path, &body, &state);
    write_response(&mut stream, status, &body_out)?;
    Ok(())
}

/// Read the full HTTP request from the stream (handles Content-Length).
fn read_request(stream: &mut std::net::TcpStream) -> Result<Vec<u8>, String> {
    let mut buf: Vec<u8> = Vec::new();
    let mut tmp = [0u8; 4096];
    let mut header_end: Option<usize> = None;
    let mut content_length: usize = 0;

    loop {
        let n = stream.read(&mut tmp).map_err(|e| format!("read: {}", e))?;
        if n == 0 {
            break;
        }
        buf.extend_from_slice(&tmp[..n]);

        if header_end.is_none() {
            if let Some(idx) = find_subseq(&buf, b"\r\n\r\n") {
                header_end = Some(idx);
                let headers_str = String::from_utf8_lossy(&buf[..idx]).to_string();
                content_length = parse_content_length(&headers_str);
            }
        }

        if let Some(idx) = header_end {
            let body_start = idx + 4;
            let have = buf.len().saturating_sub(body_start);
            if have >= content_length {
                break;
            }
        }

        // Hard cap to avoid runaway reads.
        if buf.len() > 8 * 1024 * 1024 {
            return Err("Request too large".to_string());
        }
    }
    Ok(buf)
}

fn find_subseq(buf: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || buf.len() < needle.len() {
        return None;
    }
    buf.windows(needle.len()).position(|w| w == needle)
}

fn parse_content_length(headers: &str) -> usize {
    for line in headers.lines() {
        if let Some((k, v)) = line.split_once(':') {
            if k.trim().eq_ignore_ascii_case("content-length") {
                if let Ok(n) = v.trim().parse::<usize>() {
                    return n;
                }
            }
        }
    }
    0
}

/// Parse raw HTTP bytes into `(method, path, body)`.
fn parse_http(raw: &[u8]) -> Result<(String, String, Vec<u8>), String> {
    let header_end = find_subseq(raw, b"\r\n\r\n")
        .ok_or_else(|| "Malformed request: no header terminator".to_string())?;
    let headers_str = String::from_utf8_lossy(&raw[..header_end]).to_string();
    let body = raw[header_end + 4..].to_vec();

    let mut lines = headers_str.lines();
    let first = lines.next().ok_or_else(|| "Empty request".to_string())?;
    let mut parts = first.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let path = parts.next().unwrap_or("").to_string();
    if method.is_empty() || path.is_empty() {
        return Err("Malformed request line".to_string());
    }
    Ok((method, path, body))
}

/// Route to a handler. Returns `(status_code, json_body)`.
fn route(method: &str, path: &str, body: &[u8], state: &AppState) -> (u16, String) {
    // Strip query string if any.
    let path_only = path.split('?').next().unwrap_or(path);
    match (method, path_only) {
        ("POST", "/gate") => handle_gate(body, state),
        ("GET", "/rules") => handle_rules(state),
        ("POST", "/reload") => handle_reload(state),
        ("GET", "/health") => handle_health(state),
        ("GET", "/") => (200, serde_json::json!({"service":"agent-firewall","endpoints":["POST /gate","GET /rules","POST /reload","GET /health"]}).to_string()),
        _ => (404, serde_json::json!({"error":"not_found","path":path_only}).to_string()),
    }
}

fn handle_gate(body: &[u8], state: &AppState) -> (u16, String) {
    state.gate_calls.fetch_add(1, Ordering::SeqCst);
    let parsed: serde_json::Value = match serde_json::from_slice(body) {
        Ok(v) => v,
        Err(e) => {
            return (
                400,
                serde_json::json!({"allowed": false, "reason": "bad_json", "error": e.to_string()}).to_string(),
            );
        }
    };

    let action = parsed
        .get("action")
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();
    let args = parsed.get("args").cloned().unwrap_or(serde_json::Value::Null);

    if action.is_empty() {
        return (
            400,
            serde_json::json!({"allowed": false, "reason": "missing_action"}).to_string(),
        );
    }

    // Engine is read-locked during evaluation: queries never mutate clauses.
    let engine_guard = state.engine.read().unwrap();
    let start = Instant::now();
    let (verdict, _query_result) = firewall::evaluate(&engine_guard, &action, &args);
    let elapsed_us = start.elapsed().as_micros() as u64;
    drop(engine_guard);

    // Audit log every /gate call (no shortcut).
    let _ = state.audit.log(
        &action,
        &args,
        verdict.allowed,
        verdict.rule_matched.as_deref(),
    );

    let resp = GateResponse {
        allowed: verdict.allowed,
        reason: if verdict.allowed { "ok".to_string() } else { "ZeroPath".to_string() },
        rule_matched: verdict.rule_matched.clone(),
        evaluated_in_us: elapsed_us,
    };
    let body_out = serde_json::to_string(&resp).unwrap_or_else(|_| "{}".to_string());
    (200, body_out)
}

fn handle_rules(state: &AppState) -> (u16, String) {
    let guard = state.engine.read().unwrap();
    let rules: Vec<String> = guard.dump_rules();
    let count = rules.len();
    let body = serde_json::json!({
        "rules_loaded": count,
        "rules": rules,
    })
    .to_string();
    (200, body)
}

fn handle_reload(state: &AppState) -> (u16, String) {
    let src = match std::fs::read_to_string(&state.rules_path) {
        Ok(s) => s,
        Err(e) => {
            return (
                500,
                serde_json::json!({"ok": false, "error": e.to_string()}).to_string(),
            );
        }
    };
    let mut new_engine = Engine::new();
    match new_engine.load_string(&src) {
        Ok(n) => {
            let mut guard = state.engine.write().unwrap();
            *guard = new_engine;
            let body = serde_json::json!({"ok": true, "rules_loaded": n}).to_string();
            (200, body)
        }
        Err(e) => (
            500,
            serde_json::json!({"ok": false, "error": e}).to_string(),
        ),
    }
}

fn handle_health(state: &AppState) -> (u16, String) {
    let rules_loaded = state.engine.read().unwrap().rules_count();
    let audits = state.audit.records_written();
    let gate_calls = state.gate_calls.load(Ordering::SeqCst);
    let body = serde_json::to_string(&HealthResponse {
        status: "ok".to_string(),
        rules_loaded,
        audits,
        gate_calls,
    })
    .unwrap_or_else(|_| "{}".to_string());
    (200, body)
}

fn write_response(stream: &mut std::net::TcpStream, status: u16, body: &str) -> Result<(), String> {
    let status_text = match status {
        200 => "OK",
        400 => "Bad Request",
        404 => "Not Found",
        500 => "Internal Server Error",
        _ => "OK",
    };
    let header = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        status,
        status_text,
        body.len()
    );
    stream
        .write_all(header.as_bytes())
        .map_err(|e| format!("write header: {}", e))?;
    stream
        .write_all(body.as_bytes())
        .map_err(|e| format!("write body: {}", e))?;
    stream.flush().ok();
    Ok(())
}

/// Small helper to convert a HashMap of strings to a JSON object string.
#[allow(dead_code)]
fn map_to_json(map: &HashMap<String, String>) -> String {
    let mut s = String::from("{");
    for (i, (k, v)) in map.iter().enumerate() {
        if i > 0 {
            s.push(',');
        }
        s.push_str(&format!(
            "\"{}\":\"{}\"",
            k.replace('"', "\\\""),
            v.replace('"', "\\\"")
        ));
    }
    s.push('}');
    s
}
