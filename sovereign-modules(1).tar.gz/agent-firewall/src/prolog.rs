//! Mini-Prolog engine (from scratch).
//!
//! Pipeline: source text -> Tokens -> AST (clauses) -> unification + DFS backtracking.
//!
//! Supported syntax:
//!   * Atoms (lowercase start or single-quoted):  `execute`, `'evil.com'`
//!   * Variables (uppercase start or `_`):        `X`, `Args`, `_`
//!   * Lists:                                     `[a, b, c]`, `[]`
//!   * Compound terms:                            `forbidden(execute, [...])`
//!   * Facts:                                     `head(arg).`
//!   * Rules:                                     `head(X) :- body1, body2.`
//!
//! Jokers:
//!   * `any`           -> wildcard (matches anything)
//!   * `any_*`         -> named wildcard (matches anything, name is documentation)
//!   * `_`             -> wildcard
//!
//! Backtracking is recursive DFS with a depth cap (`max_depth`, default 1000) to
//! guarantee termination even on adversarial rule sets.

use std::collections::HashMap;
use std::fmt;

// ---------------------------------------------------------------------------
// Term AST
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum Term {
    /// Lowercase-starting identifier or quoted string. e.g. `execute`, `'evil.com'`.
    Atom(String),
    /// Uppercase-starting identifier or `_`. e.g. `X`, `Args`.
    Var(String),
    /// `[a, b, c]` (no tail `|` support, kept minimal).
    List(Vec<Term>),
    /// `name(arg1, arg2, ...)`.
    Compound(String, Vec<Term>),
}

impl Term {
    /// Returns true if this term acts as a wildcard (matches anything).
    pub fn is_wildcard(&self) -> bool {
        match self {
            Term::Atom(s) => s == "_" || s == "any" || s.starts_with("any_"),
            Term::Var(s) => s == "_",
            _ => false,
        }
    }

    /// Pretty-print as Prolog source.
    pub fn to_prolog(&self) -> String {
        match self {
            Term::Atom(s) => {
                // Quote if it contains characters that aren't a plain atom.
                if is_plain_atom(s) {
                    s.clone()
                } else {
                    format!("'{}'", s.replace('\'', "\\'"))
                }
            }
            Term::Var(s) => s.clone(),
            Term::List(items) => {
                format!("[{}]", items.iter().map(|t| t.to_prolog()).collect::<Vec<_>>().join(", "))
            }
            Term::Compound(name, args) => {
                if args.is_empty() {
                    name.clone()
                } else {
                    format!("{}({})", name, args.iter().map(|t| t.to_prolog()).collect::<Vec<_>>().join(", "))
                }
            }
        }
    }
}

fn is_plain_atom(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let first = s.chars().next().unwrap();
    if !first.is_ascii_lowercase() && first != '_' {
        return false;
    }
    s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_')
}

// ---------------------------------------------------------------------------
// Clause
// ---------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct Clause {
    pub head: Term,
    pub body: Vec<Term>, // empty for facts
}

impl Clause {
    #[allow(dead_code)]
    pub fn is_fact(&self) -> bool {
        self.body.is_empty()
    }
}

impl fmt::Display for Clause {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.body.len() {
            0 => write!(f, "{}.", self.head.to_prolog()),
            _ => write!(
                f,
                "{} :- {}.",
                self.head.to_prolog(),
                self.body.iter().map(|t| t.to_prolog()).collect::<Vec<_>>().join(", ")
            ),
        }
    }
}

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq)]
enum Token {
    Atom(String),
    Var(String),
    Number(i64),
    LParen,
    RParen,
    LBracket,
    RBracket,
    Comma,
    Dot,    // `.`  clause terminator
    Neck,   // `:-` rule neck
    Query,  // `?-` query prefix
}

fn tokenize(src: &str) -> Result<Vec<Token>, String> {
    let mut tokens = Vec::new();
    let chars: Vec<char> = src.chars().collect();
    let n = chars.len();
    let mut i = 0usize;

    while i < n {
        let c = chars[i];

        // Whitespace
        if c.is_whitespace() {
            i += 1;
            continue;
        }

        // Line comment: `% ...`
        if c == '%' {
            while i < n && chars[i] != '\n' {
                i += 1;
            }
            continue;
        }

        // Block comment: `/* ... */`
        if c == '/' && i + 1 < n && chars[i + 1] == '*' {
            i += 2;
            while i + 1 < n && !(chars[i] == '*' && chars[i + 1] == '/') {
                i += 1;
            }
            if i + 1 < n {
                i += 2;
            } else {
                return Err("Unterminated block comment".to_string());
            }
            continue;
        }

        // Single-char punctuation
        match c {
            '(' => { tokens.push(Token::LParen);    i += 1; continue; }
            ')' => { tokens.push(Token::RParen);    i += 1; continue; }
            '[' => { tokens.push(Token::LBracket);  i += 1; continue; }
            ']' => { tokens.push(Token::RBracket);  i += 1; continue; }
            ',' => { tokens.push(Token::Comma);     i += 1; continue; }
            _ => {}
        }

        // `:-` neck
        if c == ':' && i + 1 < n && chars[i + 1] == '-' {
            tokens.push(Token::Neck);
            i += 2;
            continue;
        }

        // `?-` query
        if c == '?' && i + 1 < n && chars[i + 1] == '-' {
            tokens.push(Token::Query);
            i += 2;
            continue;
        }

        // Clause terminator `.` (must be followed by whitespace/EOF to distinguish
        // from a possible float; we don't support floats here so it's fine).
        if c == '.' {
            tokens.push(Token::Dot);
            i += 1;
            continue;
        }

        // Single-quoted string -> atom
        if c == '\'' {
            i += 1;
            let mut s = String::new();
            while i < n && chars[i] != '\'' {
                if chars[i] == '\\' && i + 1 < n {
                    // Simple escape handling
                    let next = chars[i + 1];
                    match next {
                        'n' => s.push('\n'),
                        't' => s.push('\t'),
                        'r' => s.push('\r'),
                        '\\' => s.push('\\'),
                        '\'' => s.push('\''),
                        other => s.push(other),
                    }
                    i += 2;
                } else {
                    s.push(chars[i]);
                    i += 1;
                }
            }
            if i >= n {
                return Err("Unterminated single-quoted string".to_string());
            }
            i += 1; // skip closing quote
            tokens.push(Token::Atom(s));
            continue;
        }

        // Double-quoted string -> atom (lenient)
        if c == '"' {
            i += 1;
            let mut s = String::new();
            while i < n && chars[i] != '"' {
                if chars[i] == '\\' && i + 1 < n {
                    let next = chars[i + 1];
                    match next {
                        'n' => s.push('\n'),
                        't' => s.push('\t'),
                        'r' => s.push('\r'),
                        '\\' => s.push('\\'),
                        '"' => s.push('"'),
                        other => s.push(other),
                    }
                    i += 2;
                } else {
                    s.push(chars[i]);
                    i += 1;
                }
            }
            if i >= n {
                return Err("Unterminated double-quoted string".to_string());
            }
            i += 1;
            tokens.push(Token::Atom(s));
            continue;
        }

        // Number
        if c.is_ascii_digit() {
            let mut s = String::new();
            while i < n && chars[i].is_ascii_digit() {
                s.push(chars[i]);
                i += 1;
            }
            // Negative numbers handled separately; we keep it simple here.
            let val: i64 = s.parse().map_err(|_| format!("Invalid number: {}", s))?;
            tokens.push(Token::Number(val));
            continue;
        }

        // Identifier (atom or var)
        if c.is_alphabetic() || c == '_' {
            let mut s = String::new();
            while i < n && (chars[i].is_alphanumeric() || chars[i] == '_') {
                s.push(chars[i]);
                i += 1;
            }
            if s == "_" {
                tokens.push(Token::Var("_".to_string()));
            } else if s.chars().next().map(|c| c.is_uppercase()).unwrap_or(false) {
                tokens.push(Token::Var(s));
            } else {
                tokens.push(Token::Atom(s));
            }
            continue;
        }

        return Err(format!("Unexpected character at offset {}: {:?}", i, c));
    }

    Ok(tokens)
}

// ---------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------

struct Parser<'a> {
    tokens: &'a [Token],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn new(tokens: &'a [Token]) -> Self {
        Parser { tokens, pos: 0 }
    }

    fn peek(&self) -> Option<&Token> {
        self.tokens.get(self.pos)
    }

    fn next(&mut self) -> Option<Token> {
        let t = self.tokens.get(self.pos).cloned();
        if t.is_some() {
            self.pos += 1;
        }
        t
    }

    #[allow(dead_code)]
    fn expect(&mut self, expected: &Token) -> Result<(), String> {
        match self.next() {
            Some(ref t) if t == expected => Ok(()),
            other => Err(format!("Expected {:?}, got {:?}", expected, other)),
        }
    }

    fn parse_term(&mut self) -> Result<Term, String> {
        let tok = self.next().ok_or_else(|| "Unexpected end of input while parsing term".to_string())?;
        match tok {
            Token::Atom(s) => {
                // Compound if followed by `(`
                if let Some(Token::LParen) = self.peek() {
                    self.next(); // consume LParen
                    let mut args = Vec::new();
                    if let Some(Token::RParen) = self.peek() {
                        self.next();
                        return Ok(Term::Compound(s, args));
                    }
                    loop {
                        let arg = self.parse_term()?;
                        args.push(arg);
                        match self.peek() {
                            Some(Token::Comma) => { self.next(); continue; }
                            Some(Token::RParen) => { self.next(); break; }
                            other => return Err(format!("Expected , or ), got {:?}", other)),
                        }
                    }
                    Ok(Term::Compound(s, args))
                } else {
                    Ok(Term::Atom(s))
                }
            }
            Token::Var(s) => Ok(Term::Var(s)),
            Token::Number(n) => Ok(Term::Atom(n.to_string())),
            Token::LBracket => {
                // LBracket was already consumed by `self.next()` at the top of
                // this function; do not consume again.
                let mut items = Vec::new();
                if let Some(Token::RBracket) = self.peek() {
                    self.next();
                    return Ok(Term::List(items));
                }
                loop {
                    let item = self.parse_term()?;
                    items.push(item);
                    match self.peek() {
                        Some(Token::Comma) => { self.next(); continue; }
                        Some(Token::RBracket) => { self.next(); break; }
                        other => return Err(format!("Expected , or ], got {:?}", other)),
                    }
                }
                Ok(Term::List(items))
            }
            other => Err(format!("Unexpected token while parsing term: {:?}", other)),
        }
    }

    fn parse_clause(&mut self) -> Result<Clause, String> {
        let head = self.parse_term()?;
        let mut body = Vec::new();
        match self.peek() {
            Some(Token::Neck) => {
                self.next();
                loop {
                    let goal = self.parse_term()?;
                    body.push(goal);
                    match self.peek() {
                        Some(Token::Comma) => { self.next(); continue; }
                        Some(Token::Dot) => { self.next(); break; }
                        other => return Err(format!("Expected , or . in rule body, got {:?}", other)),
                    }
                }
            }
            Some(Token::Dot) => { self.next(); }
            other => return Err(format!("Expected . or :- after clause head, got {:?}", other)),
        }
        Ok(Clause { head, body })
    }
}

pub fn parse_clauses(src: &str) -> Result<Vec<Clause>, String> {
    let tokens = tokenize(src)?;
    let mut p = Parser::new(&tokens);
    let mut clauses = Vec::new();
    while p.pos < p.tokens.len() {
        // Allow stray `?-` queries (we skip them, they're interactive).
        if let Some(Token::Query) = p.peek() {
            p.next();
            // Skip until Dot
            while let Some(t) = p.peek() {
                if matches!(t, Token::Dot) { p.next(); break; }
                p.next();
            }
            continue;
        }
        let clause = p.parse_clause()?;
        clauses.push(clause);
    }
    Ok(clauses)
}

// ---------------------------------------------------------------------------
// Unification
// ---------------------------------------------------------------------------

pub type Bindings = HashMap<String, Term>;

/// Walk the binding chain to find the ultimate value of `term`.
pub fn resolve(term: &Term, bindings: &Bindings) -> Term {
    match term {
        Term::Var(name) => match bindings.get(name) {
            Some(bound) => resolve(bound, bindings),
            None => Term::Var(name.clone()),
        },
        other => other.clone(),
    }
}

/// Recursively unify two terms, mutating the binding map on success.
/// Returns `true` if they unify.
pub fn unify(a: &Term, b: &Term, bindings: &mut Bindings) -> bool {
    let a = resolve(a, bindings);
    let b = resolve(b, bindings);

    // Wildcards match anything (no binding required).
    if a.is_wildcard() || b.is_wildcard() {
        return true;
    }

    match (&a, &b) {
        (Term::Atom(x), Term::Atom(y)) => x == y,
        (Term::Var(x), Term::Var(y)) if x == y => true,
        (Term::Var(x), _) => {
            bindings.insert(x.clone(), b.clone());
            true
        }
        (_, Term::Var(y)) => {
            bindings.insert(y.clone(), a.clone());
            true
        }
        (Term::List(xs), Term::List(ys)) => {
            if xs.len() != ys.len() {
                return false;
            }
            for (xi, yi) in xs.iter().zip(ys.iter()) {
                if !unify(xi, yi, bindings) {
                    return false;
                }
            }
            true
        }
        (Term::Compound(n1, args1), Term::Compound(n2, args2)) => {
            if n1 != n2 || args1.len() != args2.len() {
                return false;
            }
            for (a1, a2) in args1.iter().zip(args2.iter()) {
                if !unify(a1, a2, bindings) {
                    return false;
                }
            }
            true
        }
        _ => false,
    }
}

// ---------------------------------------------------------------------------
// Engine
// ---------------------------------------------------------------------------

pub struct QueryResult {
    pub success: bool,
    /// Prolog source of the (goal as evaluated) when a rule matched.
    pub matched_goal: Option<String>,
}

pub struct Engine {
    pub clauses: Vec<Clause>,
    pub max_depth: usize,
}

impl Default for Engine {
    fn default() -> Self {
        Engine { clauses: Vec::new(), max_depth: 1000 }
    }
}

impl Engine {
    pub fn new() -> Self {
        Self::default()
    }

    #[allow(dead_code)]
    pub fn with_max_depth(max_depth: usize) -> Self {
        Engine { clauses: Vec::new(), max_depth }
    }

    pub fn load_string(&mut self, src: &str) -> Result<usize, String> {
        let clauses = parse_clauses(src)?;
        let n = clauses.len();
        self.clauses = clauses;
        Ok(n)
    }

    pub fn load_file(path: &std::path::Path) -> Result<Self, String> {
        let src = std::fs::read_to_string(path)
            .map_err(|e| format!("Failed to read {}: {}", path.display(), e))?;
        let mut engine = Self::new();
        engine.load_string(&src)?;
        Ok(engine)
    }

    pub fn rules_count(&self) -> usize {
        self.clauses.len()
    }

    /// Format every clause as Prolog source (one per line).
    pub fn dump_rules(&self) -> Vec<String> {
        self.clauses.iter().map(|c| c.to_string()).collect()
    }

    /// Evaluate `?- goal.` and return whether any clause proves it.
    /// No shortcuts: every query traverses the full clause list with
    /// DFS backtracking.
    pub fn query(&self, goal: &Term) -> QueryResult {
        let mut bindings = Bindings::new();
        if self.prove(goal, &mut bindings, 0) {
            QueryResult {
                success: true,
                matched_goal: Some(goal.to_prolog()),
            }
        } else {
            QueryResult { success: false, matched_goal: None }
        }
    }

    fn prove(&self, goal: &Term, bindings: &mut Bindings, depth: usize) -> bool {
        if depth >= self.max_depth {
            return false;
        }
        for clause in &self.clauses {
            // Fresh bindings for each clause attempt: head variables are local
            // to the clause.
            let mut local: Bindings = bindings.clone();
            if unify(&clause.head, goal, &mut local) {
                if self.prove_body(&clause.body, &mut local, depth + 1) {
                    // Commit: copy local bindings back.
                    *bindings = local;
                    return true;
                }
            }
        }
        false
    }

    fn prove_body(&self, body: &[Term], bindings: &mut Bindings, depth: usize) -> bool {
        if body.is_empty() {
            return true;
        }
        // Try each ordering of the first goal with the rest.
        // Standard Prolog semantics: prove g1 with current bindings, then prove
        // the rest under the extended bindings.
        let goal = resolve(&body[0], bindings);
        let mut local: Bindings = bindings.clone();
        if self.prove(&goal, &mut local, depth + 1) {
            if self.prove_body(&body[1..], &mut local, depth + 1) {
                *bindings = local;
                return true;
            }
        }
        false
    }
}

// ---------------------------------------------------------------------------
// Tests (unit)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_and_query_simple_fact() {
        let mut e = Engine::new();
        e.load_string("forbidden(execute, ['rm', '-rf', '/']).").unwrap();
        let goal = Term::Compound(
            "forbidden".into(),
            vec![
                Term::Atom("execute".into()),
                Term::List(vec![
                    Term::Atom("rm".into()),
                    Term::Atom("-rf".into()),
                    Term::Atom("/".into()),
                ]),
            ],
        );
        assert!(e.query(&goal).success);
    }

    #[test]
    fn query_with_any_wildcard() {
        let mut e = Engine::new();
        e.load_string("forbidden(execute, ['chmod', '777', any]).").unwrap();
        let goal = Term::Compound(
            "forbidden".into(),
            vec![
                Term::Atom("execute".into()),
                Term::List(vec![
                    Term::Atom("chmod".into()),
                    Term::Atom("777".into()),
                    Term::Atom("/etc/passwd".into()),
                ]),
            ],
        );
        assert!(e.query(&goal).success);
    }

    #[test]
    fn query_does_not_match_unrelated() {
        let mut e = Engine::new();
        e.load_string("forbidden(execute, ['rm', '-rf', '/']).").unwrap();
        let goal = Term::Compound(
            "forbidden".into(),
            vec![
                Term::Atom("execute".into()),
                Term::List(vec![
                    Term::Atom("ls".into()),
                    Term::Atom("-la".into()),
                ]),
            ],
        );
        assert!(!e.query(&goal).success);
    }

    #[test]
    fn rule_with_body() {
        let src = r#"
            dangerous_action(execute).
            sensitive_target(['/etc/passwd']).
            forbidden(Action, Args) :- dangerous_action(Action), sensitive_target(Args).
        "#;
        let mut e = Engine::new();
        e.load_string(src).unwrap();
        let goal = Term::Compound(
            "forbidden".into(),
            vec![
                Term::Atom("execute".into()),
                Term::List(vec![Term::Atom("/etc/passwd".into())]),
            ],
        );
        assert!(e.query(&goal).success);
    }

    #[test]
    fn depth_limit_terminates() {
        // Self-referential rule that would loop forever without depth cap.
        let src = "loop(X) :- loop(X).";
        let mut e = Engine::with_max_depth(50);
        e.load_string(src).unwrap();
        let goal = Term::Atom("loop_y".into());
        // Should not hang and should return false.
        let res = e.query(&goal);
        assert!(!res.success);
    }
}
