//! `bench.rs` - Performance benchmark for the 1 MB snapshot target.
//!
//! Spec requirement: a 1 MB snapshot must be saved in **< 50 ms**.
//! We build a snapshot whose `memory` is exactly 1_000_000 bytes, then call
//! `AgentState::to_bytes()` 100 times, measuring the mean wall-clock duration.

use crate::state::AgentState;
use std::collections::HashMap;
use std::time::{Duration, Instant};

/// Number of serialization iterations to average over.
pub const ITERS: u32 = 100;

/// Target memory size: 1 MB (decimal).
pub const TARGET_MEMORY: usize = 1_000_000;

/// Build a deterministic ~1 MB snapshot (memory = 1_000_000 pseudo-random bytes).
pub fn build_1mb_snapshot() -> AgentState {
    // Deterministic PRNG (xorshift32) - no extra crate needed, fully reproducible.
    let mut state: u32 = 0x1234_5678;
    let mut memory = Vec::with_capacity(TARGET_MEMORY);
    for _ in 0..TARGET_MEMORY {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        memory.push((state & 0xff) as u8);
    }
    let mut ctx = HashMap::new();
    ctx.insert("bench".to_string(), "1mb".to_string());
    ctx.insert("target".to_string(), "<50ms".to_string());
    AgentState::new(
        "bench-agent".to_string(),
        "benchmark serialization throughput".to_string(),
        "fn bench() { /* ~1MB payload */ }".to_string(),
        memory,
        ctx,
        vec!["bench".to_string(), "perf".to_string()],
    )
}

/// Run the benchmark: serialize the 1 MB snapshot `ITERS` times, return
/// (mean_duration, min_duration, max_duration, total_bytes_per_iter).
pub fn run_bench() -> (Duration, Duration, Duration, usize) {
    let snapshot = build_1mb_snapshot();
    let mut total = Duration::ZERO;
    let mut min = Duration::MAX;
    let mut max = Duration::ZERO;
    let mut last_bytes = 0usize;
    // Warmup run (not measured) to settle allocator pages.
    let _ = snapshot.to_bytes();
    for _ in 0..ITERS {
        let start = Instant::now();
        let bytes = snapshot.to_bytes();
        let elapsed = start.elapsed();
        last_bytes = bytes.len();
        total += elapsed;
        if elapsed < min {
            min = elapsed;
        }
        if elapsed > max {
            max = elapsed;
        }
    }
    let mean = total / ITERS;
    (mean, min, max, last_bytes)
}

/// Pretty-print the benchmark result to stdout and return the mean in ms.
pub fn bench_1mb() -> f64 {
    let (mean, min, max, bytes) = run_bench();
    let mean_ms = mean.as_secs_f64() * 1000.0;
    let min_ms = min.as_secs_f64() * 1000.0;
    let max_ms = max.as_secs_f64() * 1000.0;
    let bytes_mb = bytes as f64 / 1_000_000.0;
    let throughput_mbs = if mean.as_secs_f64() > 0.0 {
        bytes_mb / mean.as_secs_f64()
    } else {
        f64::INFINITY
    };
    println!("=== snapshot-cli 1MB benchmark ===");
    println!("iterations     : {}", ITERS);
    println!("memory size    : {} bytes", TARGET_MEMORY);
    println!("serialized size: {} bytes ({:.3} MB)", bytes, bytes_mb);
    println!("mean save time : {:.3} ms", mean_ms);
    println!("min  save time : {:.3} ms", min_ms);
    println!("max  save time : {:.3} ms", max_ms);
    println!("throughput     : {:.2} MB/s", throughput_mbs);
    let target_ms = 50.0_f64;
    let pass = mean_ms < target_ms;
    println!(
        "target         : < {:.0} ms  ->  {}",
        target_ms,
        if pass { "PASS" } else { "FAIL" }
    );
    mean_ms
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn snapshot_is_about_1mb() {
        let s = build_1mb_snapshot();
        assert_eq!(s.memory.len(), TARGET_MEMORY);
        let bytes = s.to_bytes();
        // serialized file should be ~1MB + small overhead (header + trailer + struct fields).
        assert!(bytes.len() > TARGET_MEMORY);
        assert!(bytes.len() < TARGET_MEMORY + 1024);
    }

    #[test]
    fn bench_runs() {
        // Just make sure run_bench terminates without panic.
        let (mean, _, _, _) = run_bench();
        // Should be near-instant; assert a generous upper bound to catch regressions.
        assert!(mean.as_millis() < 1000);
    }
}
