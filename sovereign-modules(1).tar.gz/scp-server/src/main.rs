//! main.rs - SCP server entry point and minimal CLI.

mod dag;
mod indexer;
mod server;

use std::process::ExitCode;

const HELP: &str = "\
SCP - Sovereign Context Protocol server

USAGE:
    scp-server [OPTIONS]

OPTIONS:
    --root <DIR>     Project root to index        (default: current directory)
    --bind <ADDR>    Bind address                 (default: 127.0.0.1)
    --port <PORT>    Bind port                    (default: 9001)
    -h, --help       Show this help message

ENDPOINTS (once running):
    GET  /health                 -> server status + indexation timing
    GET  /context?file=<path>    -> direct/indirect deps + security rules
    GET  /dag                    -> full dependency DAG (debug)
    POST /reindex                -> force a full re-indexation
";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().collect();

    let mut root: String = ".".to_string();
    let mut bind: String = "127.0.0.1".to_string();
    let mut port: u16 = 9001;

    let mut i = 1;
    while i < args.len() {
        let arg = &args[i];
        match arg.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                return ExitCode::SUCCESS;
            }
            "--root" => {
                if let Some(v) = next_value(&args, &mut i, "--root") {
                    root = v;
                } else {
                    return ExitCode::FAILURE;
                }
            }
            "--bind" => {
                if let Some(v) = next_value(&args, &mut i, "--bind") {
                    bind = v;
                } else {
                    return ExitCode::FAILURE;
                }
            }
            "--port" => {
                if let Some(v) = next_value(&args, &mut i, "--port") {
                    match v.parse::<u16>() {
                        Ok(p) => port = p,
                        Err(_) => {
                            eprintln!("error: --port expects a number, got '{}'", v);
                            return ExitCode::FAILURE;
                        }
                    }
                } else {
                    return ExitCode::FAILURE;
                }
            }
            other => {
                eprintln!("error: unknown argument '{}'\n", other);
                print!("{}", HELP);
                return ExitCode::FAILURE;
            }
        }
        i += 1;
    }

    // Canonicalise the root so DAG keys are stable.
    let root_path = match std::fs::canonicalize(&root) {
        Ok(p) => p,
        Err(e) => {
            eprintln!("error: cannot access --root '{}': {}", root, e);
            return ExitCode::FAILURE;
        }
    };

    let addr = format!("{}:{}", bind, port);
    let server = server::Server::new(root_path, addr);

    match server.run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: server stopped: {}", e);
            ExitCode::FAILURE
        }
    }
}

/// Fetch the value following a `--flag` argument and advance the index past it.
fn next_value(args: &[String], i: &mut usize, flag: &str) -> Option<String> {
    if *i + 1 >= args.len() {
        eprintln!("error: {} expects a value", flag);
        return None;
    }
    let v = args[*i + 1].clone();
    *i += 1;
    Some(v)
}
