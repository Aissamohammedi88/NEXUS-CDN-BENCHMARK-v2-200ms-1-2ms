package main

// cache.go — Cache en mémoire des réponses identiques.
//
// La clé de cache est SHA-256(normalized_prompt + model + temperature + max_tokens).
// Le cache est thread-safe (sync.RWMutex + atomics pour les compteurs).
// TTL optionnel : les entrées expirées sont ignorées et supprimées paresseusement.

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sync"
	"sync/atomic"
	"time"
)

// CacheEntry stocke une réponse mise en cache avec son timestamp de création.
type CacheEntry struct {
	Response  *ChatResponse
	CreatedAt time.Time
}

// CacheStats est un snapshot des statistiques du cache.
type CacheStats struct {
	Hits    int64   `json:"cache_hits"`
	Misses  int64   `json:"cache_misses"`
	Size    int     `json:"cache_size"`
	HitRate float64 `json:"hit_rate"`
}

// Cache est le cache en mémoire partagé entre toutes les requêtes.
type Cache struct {
	mu      sync.RWMutex
	entries map[string]*CacheEntry
	ttl     time.Duration
	hits    int64
	misses  int64
}

// NewCache crée un cache avec un TTL donné (0 = pas d'expiration).
func NewCache(ttl time.Duration) *Cache {
	return &Cache{
		entries: make(map[string]*CacheEntry),
		ttl:     ttl,
	}
}

// CacheKey calcule SHA-256(prompt normalisé + model + temperature + max_tokens).
//
// Le prompt est normalisé en concaténant role:content de chaque message.
func CacheKey(req *ChatRequest) string {
	var promptBuf string
	for _, m := range req.Messages {
		promptBuf += m.Role + ":" + m.Content + "\n"
	}
	raw := fmt.Sprintf("%s|%s|%.6f|%d", promptBuf, req.Model, req.Temperature, req.MaxTokens)
	h := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(h[:])
}

// Get retourne la réponse mise en cache si elle existe et n'est pas expirée.
// Incrémente les compteurs hits/misses atomiquement.
func (c *Cache) Get(key string) (*ChatResponse, bool) {
	c.mu.RLock()
	entry, ok := c.entries[key]
	expired := false
	if ok && c.ttl > 0 && time.Since(entry.CreatedAt) > c.ttl {
		expired = true
	}
	c.mu.RUnlock()

	if !ok || expired {
		atomic.AddInt64(&c.misses, 1)
		if expired {
			// Suppression paresseuse de l'entrée expirée.
			c.mu.Lock()
			if e, exists := c.entries[key]; exists && c.ttl > 0 && time.Since(e.CreatedAt) > c.ttl {
				delete(c.entries, key)
			}
			c.mu.Unlock()
		}
		return nil, false
	}
	atomic.AddInt64(&c.hits, 1)
	return entry.Response, true
}

// Set ajoute ou remplace une entrée dans le cache.
func (c *Cache) Set(key string, resp *ChatResponse) {
	c.mu.Lock()
	c.entries[key] = &CacheEntry{
		Response:  resp,
		CreatedAt: time.Now(),
	}
	c.mu.Unlock()
}

// Clear vide entièrement le cache et retourne le nombre d'entrées supprimées.
func (c *Cache) Clear() int {
	c.mu.Lock()
	n := len(c.entries)
	c.entries = make(map[string]*CacheEntry)
	c.mu.Unlock()
	return n
}

// Stats retourne un snapshot cohérent des statistiques du cache.
func (c *Cache) Stats() CacheStats {
	c.mu.RLock()
	size := len(c.entries)
	c.mu.RUnlock()
	hits := atomic.LoadInt64(&c.hits)
	misses := atomic.LoadInt64(&c.misses)
	total := hits + misses
	var rate float64
	if total > 0 {
		rate = float64(hits) / float64(total)
	}
	return CacheStats{
		Hits:    hits,
		Misses:  misses,
		Size:    size,
		HitRate: rate,
	}
}
