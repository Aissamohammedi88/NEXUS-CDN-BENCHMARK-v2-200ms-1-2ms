package main

// router.go — Logique de routage du gateway.
//
// Le routeur analyse la requête entrante et choisit le backend approprié :
//   - model == "auto" : heuristique basée sur la longueur du prompt.
//       prompt court (< seuil tokens)  -> backend local (ollama)
//       prompt long  (>= seuil tokens) -> backend cloud  (openai)
//   - model explicite : mapping vers le backend correspondant.
//   - En cas d'erreur (backend indisponible, pas de clé API) : fallback Mock.
//
// La séparation ChooseBackendName / ForwardWithBackend permet de mesurer
// précisément l'overhead du routeur (sans inclure le temps backend).

import (
	"context"
	"log"
	"strings"
)

// RoutingConfig est la section "routing" du fichier de configuration.
type RoutingConfig struct {
	AutoShortPromptThresholdTokens int    `json:"auto_short_prompt_threshold_tokens"`
	AutoShortPromptBackend          string `json:"auto_short_prompt_backend"`
	AutoLongPromptBackend           string `json:"auto_long_prompt_backend"`
}

// Router est le routeur central du gateway.
type Router struct {
	backends map[string]Backend
	mock     Backend
	config   RoutingConfig
	logger   *log.Logger
}

// NewRouter crée un routeur avec ses backends et sa config de routage.
func NewRouter(backends map[string]Backend, cfg RoutingConfig, logger *log.Logger) *Router {
	return &Router{
		backends: backends,
		mock:     &MockBackend{},
		config:   cfg,
		logger:   logger,
	}
}

// ChooseBackendName décide du backend à utiliser pour cette requête.
// Retourne "mock" si aucun backend ne correspond.
//
// Cette méthode est pure (pas d'I/O) : son temps d'exécution correspond à
// l'overhead de routage qui doit être < 10ms.
func (r *Router) ChooseBackendName(req *ChatRequest) string {
	if req.Model == "auto" || req.Model == "" {
		// Heuristique : estimer le nombre de tokens du prompt.
		var promptChars int
		for _, m := range req.Messages {
			promptChars += len(m.Content)
		}
		promptTokens := (promptChars + 3) / 4 // ~4 chars/token

		threshold := r.config.AutoShortPromptThresholdTokens
		if threshold <= 0 {
			threshold = 200
		}

		if promptTokens < threshold {
			return r.resolveBackendName(r.config.AutoShortPromptBackend, "ollama")
		}
		return r.resolveBackendName(r.config.AutoLongPromptBackend, "openai")
	}

	// Mapping explicite model -> backend.
	switch {
	case strings.HasPrefix(req.Model, "gpt-"):
		return r.resolveBackendName("openai", "openai")
	case strings.HasPrefix(req.Model, "claude"):
		return r.resolveBackendName("anthropic", "anthropic")
	case strings.Contains(req.Model, "llama") ||
		strings.Contains(req.Model, "ollama") ||
		strings.Contains(req.Model, "mistral") ||
		strings.Contains(req.Model, "qwen") ||
		strings.Contains(req.Model, "phi"):
		return r.resolveBackendName("ollama", "ollama")
	}

	// Modèle inconnu : fallback openai (puis mock si échec).
	return r.resolveBackendName("openai", "openai")
}

// resolveBackendName retourne le nom du backend s'il est configuré,
// sinon retourne le fallback par défaut, sinon "mock".
func (r *Router) resolveBackendName(name, fallback string) string {
	if name == "" {
		name = fallback
	}
	if _, ok := r.backends[name]; ok {
		return name
	}
	return "mock"
}

// ForwardWithBackend exécute l'appel au backend choisi avec fallback Mock.
// Retourne (réponse, backend_effectivement_utilisé, erreur).
func (r *Router) ForwardWithBackend(ctx context.Context, req *ChatRequest, backendName string) (*ChatResponse, string, error) {
	// Si le routeur a déjà décidé "mock", on y va directement.
	if backendName == "mock" || backendName == "" {
		resp, err := r.mock.Forward(ctx, req)
		return resp, "mock", err
	}

	backend, ok := r.backends[backendName]
	if !ok || backend == nil {
		r.logger.Printf("router: backend %q not registered, using mock", backendName)
		resp, err := r.mock.Forward(ctx, req)
		return resp, "mock", err
	}

	resp, err := backend.Forward(ctx, req)
	if err != nil {
		r.logger.Printf("router: backend %s failed: %v — falling back to mock", backend.Name(), err)
		resp, err = r.mock.Forward(ctx, req)
		return resp, "mock", err
	}
	return resp, backendName, nil
}
