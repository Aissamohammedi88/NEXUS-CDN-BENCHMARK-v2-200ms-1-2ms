package main

// main.go — Point d'entrée du Sovereign AI Gateway.
//
// Le gateway est un reverse proxy HTTP qui :
//   - expose une API unifiée au format OpenAI (/v1/chat/completions)
//   - route les requêtes vers le meilleur backend disponible (local ou cloud)
//   - cache les réponses identiques (SHA-256)
//   - bascule en mode mock si aucun backend n'est joignable
//
// Endpoints :
//   POST /v1/chat/completions   — completion au format OpenAI
//   GET  /health                — santé du service + stats
//   GET  /config                — config masquée (clés API -> ***)
//   POST /cache/clear           — vide le cache
//   GET  /cache/stats           — statistiques détaillées du cache
//   GET  /                      — page d'accueil
//
// Stack : stdlib Go uniquement (net/http, encoding/json, crypto/sha256, sync).

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"sync/atomic"
	"time"
)

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

// BackendConfig décrit un backend dans le fichier de configuration.
type BackendConfig struct {
	URL            string `json:"url"`
	APIKey         string `json:"api_key"`
	DefaultModel   string `json:"default_model"`
	TimeoutSeconds int    `json:"timeout_seconds"`
}

// Config est la structure du fichier config.json.
type Config struct {
	Listen          string                   `json:"listen"`
	CacheTTLSeconds int                      `json:"cache_ttl_seconds"`
	Backends        map[string]BackendConfig `json:"backends"`
	Routing         RoutingConfig            `json:"routing"`
}

// loadConfig charge et valide le fichier de configuration JSON.
func loadConfig(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	if cfg.Listen == "" {
		cfg.Listen = "127.0.0.1:9004"
	}
	if cfg.CacheTTLSeconds <= 0 {
		cfg.CacheTTLSeconds = 3600
	}
	if cfg.Routing.AutoShortPromptThresholdTokens <= 0 {
		cfg.Routing.AutoShortPromptThresholdTokens = 200
	}
	if cfg.Routing.AutoShortPromptBackend == "" {
		cfg.Routing.AutoShortPromptBackend = "ollama"
	}
	if cfg.Routing.AutoLongPromptBackend == "" {
		cfg.Routing.AutoLongPromptBackend = "openai"
	}
	return &cfg, nil
}

// ---------------------------------------------------------------------------
// État global du gateway
// ---------------------------------------------------------------------------

var (
	cache      *Cache
	router     *Router
	logger     *log.Logger
	cfg        *Config
	routesTotal int64
)

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

func main() {
	configPath := flag.String("config", "config.json", "path to config file")
	flag.Parse()

	logger = log.New(os.Stderr, "[ai-gateway] ", log.LstdFlags|log.Lmicroseconds)

	var err error
	cfg, err = loadConfig(*configPath)
	if err != nil {
		logger.Fatalf("load config: %v", err)
	}

	cache = NewCache(time.Duration(cfg.CacheTTLSeconds) * time.Second)

	// Construction des backends depuis la configuration.
	backends := make(map[string]Backend)
	for name, bc := range cfg.Backends {
		timeout := time.Duration(bc.TimeoutSeconds) * time.Second
		if timeout <= 0 {
			timeout = 60 * time.Second
		}
		client := &http.Client{Timeout: timeout}
		switch name {
		case "anthropic":
			backends[name] = &AnthropicBackend{
				url:          bc.URL,
				apiKey:       bc.APIKey,
				defaultModel: bc.DefaultModel,
				timeout:      timeout,
				client:       client,
			}
			logger.Printf("backend registered: %s (model=%s url=%s)", name, bc.DefaultModel, bc.URL)
		case "ollama", "openai":
			backends[name] = &OpenAICompatBackend{
				name:         name,
				url:          bc.URL,
				apiKey:       bc.APIKey,
				defaultModel: bc.DefaultModel,
				timeout:      timeout,
				client:       client,
			}
			logger.Printf("backend registered: %s (model=%s url=%s)", name, bc.DefaultModel, bc.URL)
		default:
			logger.Printf("WARNING: unknown backend %q in config (ignored)", name)
		}
	}

	router = NewRouter(backends, cfg.Routing, logger)

	mux := http.NewServeMux()
	mux.HandleFunc("/", indexHandler)
	mux.HandleFunc("/v1/chat/completions", chatHandler)
	mux.HandleFunc("/health", healthHandler)
	mux.HandleFunc("/config", configHandler)
	mux.HandleFunc("/cache/clear", cacheClearHandler)
	mux.HandleFunc("/cache/stats", cacheStatsHandler)

	srv := &http.Server{
		Addr:         cfg.Listen,
		Handler:      loggingMiddleware(mux),
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 120 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	logger.Printf("sovereign-ai-gateway listening on %s", cfg.Listen)
	if err := srv.ListenAndServe(); err != nil {
		logger.Fatalf("server error: %v", err)
	}
}

// ---------------------------------------------------------------------------
// Middleware de logging
// ---------------------------------------------------------------------------

type statusWriter struct {
	http.ResponseWriter
	status int
	size   int
}

func (sw *statusWriter) WriteHeader(code int) {
	sw.status = code
	sw.ResponseWriter.WriteHeader(code)
}

func (sw *statusWriter) Write(b []byte) (int, error) {
	if sw.status == 0 {
		sw.status = 200
	}
	n, err := sw.ResponseWriter.Write(b)
	sw.size += n
	return n, err
}

// loggingMiddleware log chaque requête HTTP (timestamp + méthode + path + code + durée).
func loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		sw := &statusWriter{ResponseWriter: w, status: 0}
		next.ServeHTTP(sw, r)
		logger.Printf("HTTP %s %s -> %d (%d bytes, %dms)",
			r.Method, r.URL.Path, sw.status, sw.size, time.Since(start).Milliseconds())
	})
}

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

// indexHandler — GET / : page d'accueil JSON.
func indexHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"service":     "sovereign-ai-gateway",
		"version":     "1.0.0",
		"description": "Reverse proxy HTTP unifié au format OpenAI avec cache et fallback mock.",
		"endpoints": []string{
			"POST /v1/chat/completions",
			"GET  /health",
			"GET  /config",
			"POST /cache/clear",
			"GET  /cache/stats",
		},
	})
}

// chatHandler — POST /v1/chat/completions : route + cache + mock fallback.
//
// La latence "overhead" mesurée = temps entre réception de la requête
// et forward/mock (cache lookup + routing). Exclue le temps backend.
func chatHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed, use POST")
		return
	}

	atomic.AddInt64(&routesTotal, 1)

	// --- Début mesure d'overhead (réception -> forward/mock) ---
	receiveStart := time.Now()

	body, err := io.ReadAll(r.Body)
	if err != nil {
		writeError(w, http.StatusBadRequest, "read body: "+err.Error())
		return
	}
	defer r.Body.Close()

	var req ChatRequest
	if err := json.Unmarshal(body, &req); err != nil {
		writeError(w, http.StatusBadRequest, "parse JSON body: "+err.Error())
		return
	}
	if len(req.Messages) == 0 {
		writeError(w, http.StatusBadRequest, "messages must not be empty")
		return
	}

	// 1) Cache lookup (partie de l'overhead).
	key := CacheKey(&req)
	if cached, ok := cache.Get(key); ok {
		overhead := time.Since(receiveStart)
		logger.Printf("REQ model=%q backend=cached cache=HIT overhead=%dµs",
			req.Model, overhead.Microseconds())
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("X-Cache", "HIT")
		w.Header().Set("X-Backend", "cache")
		w.Header().Set("X-Forward-Latency-Us", fmt.Sprintf("%d", overhead.Microseconds()))
		_ = json.NewEncoder(w).Encode(cached)
		return
	}

	// 2) Routing decision (partie de l'overhead).
	chosenBackend := router.ChooseBackendName(&req)
	overhead := time.Since(receiveStart) // overhead mesuré = cache miss + routing

	// 3) Forward au backend (hors overhead).
	ctx := r.Context()
	forwardStart := time.Now()
	resp, usedBackend, err := router.ForwardWithBackend(ctx, &req, chosenBackend)
	backendDuration := time.Since(forwardStart)

	if err != nil {
		logger.Printf("REQ model=%q chosen=%s used=error overhead=%dµs backend_time=%dµs err=%v",
			req.Model, chosenBackend, overhead.Microseconds(),
			backendDuration.Microseconds(), err)
		writeError(w, http.StatusBadGateway, "router error: "+err.Error())
		return
	}

	logger.Printf("REQ model=%q chosen=%s used=%s cache=MISS overhead=%dµs backend_time=%dµs",
		req.Model, chosenBackend, usedBackend,
		overhead.Microseconds(), backendDuration.Microseconds())

	// 4) Mise en cache de la réponse.
	if resp != nil {
		cache.Set(key, resp)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Cache", "MISS")
	w.Header().Set("X-Backend", usedBackend)
	w.Header().Set("X-Forward-Latency-Us", fmt.Sprintf("%d", overhead.Microseconds()))
	_ = json.NewEncoder(w).Encode(resp)
}

// healthHandler — GET /health : santé du service.
func healthHandler(w http.ResponseWriter, r *http.Request) {
	backendNames := make([]string, 0, len(cfg.Backends))
	for name := range cfg.Backends {
		backendNames = append(backendNames, name)
	}
	stats := cache.Stats()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"status":       "ok",
		"backends":     backendNames,
		"cache_size":   stats.Size,
		"cache_hits":   stats.Hits,
		"cache_misses": stats.Misses,
		"routes_total": atomic.LoadInt64(&routesTotal),
	})
}

// configHandler — GET /config : config masquée (clés API -> ***).
func configHandler(w http.ResponseWriter, r *http.Request) {
	bm := make(map[string]interface{}, len(cfg.Backends))
	for name, bc := range cfg.Backends {
		key := bc.APIKey
		if key != "" {
			key = "***"
		}
		bm[name] = map[string]interface{}{
			"url":             bc.URL,
			"api_key":         key,
			"default_model":   bc.DefaultModel,
			"timeout_seconds": bc.TimeoutSeconds,
		}
	}
	out := map[string]interface{}{
		"listen":            cfg.Listen,
		"cache_ttl_seconds": cfg.CacheTTLSeconds,
		"backends":          bm,
		"routing":           cfg.Routing,
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(out)
}

// cacheClearHandler — POST /cache/clear : vide le cache.
func cacheClearHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed, use POST")
		return
	}
	n := cache.Clear()
	logger.Printf("cache cleared: %d entries removed", n)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  "ok",
		"cleared": n,
	})
}

// cacheStatsHandler — GET /cache/stats : statistiques détaillées du cache.
func cacheStatsHandler(w http.ResponseWriter, r *http.Request) {
	stats := cache.Stats()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(stats)
}

// writeError envoie une réponse d'erreur au format JSON.
func writeError(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"error": map[string]interface{}{
			"message": msg,
			"type":    "gateway_error",
			"code":    code,
		},
	})
}
