# NEXUS EDGE — Rapport d'acceptation datacenter

**Généré** : 2026-11-11 21:14:43

## Synthèse

- Actions exécutées : 41
- Réussies : 41 (100.0%)
- Meilleur p99 mesuré (chemin Nexus) : 0.223 ms
- Objectif contractuel : p99 ≤ 2 ms à <50km

## Détail par catégorie

| Catégorie | Actions |
|---|---|
| CACHE | 2 |
| CFG | 1 |
| DEPLOY | 18 |
| FLEET | 1 |
| HDR | 1 |
| HTTP | 3 |
| LAT | 6 |
| LOAD | 1 |
| PROBE | 3 |
| RESIL | 2 |
| RPT | 3 |

## Conclusion

Le chemin Nexus tient l'objectif de latence mesurée. Le déploiement
datacenter (micro-nodes <50km) transpose ces mesures à l'échelle.
