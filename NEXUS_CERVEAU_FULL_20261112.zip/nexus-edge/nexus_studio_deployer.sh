#!/bin/bash
# ═════════════════════════════════════════════════════════════════════════════
#   NEXUS STUDIO v1.1 — DÉPLOYEUR BRILLANT (build · trace · bootstrap · launch)
# ═════════════════════════════════════════════════════════════════════════════
#
#   bash nexus_studio_deployer.sh
#
#   Ce qu'il fait — DANS L'ORDRE, avec TRACE à chaque étape :
#     1.  Bannière + détection OS
#     2.  Bootstrap des OUTILS SYSTÈME nécessaires (python3, unzip, zip, curl)
#         -> installés via apt / dnf / pacman / brew / pkg SANS toucher au projet
#     3.  Bootstrap des CHAÎNES DE CONSTRUCTION (pip, cargo, npm) si manquantes
#         -> installées au niveau SYSTÈME, jamais ajoutées dans nexus-edge
#     4.  Localisation auto du dossier de projet (argument, cwd, ~/Projects/cdn,
#         ~/nexus-edge, recherche récursive limitée dans $HOME)
#     5.  Localisation auto de l'archive nexus-edge-studio-v1.1.zip
#     6.  Vérification d'INTÉGRITÉ des modules v1.0 (jamais modifiés)
#     7.  Décompression de l'archive avec trace fichier par fichier
#     8.  Lancement de run_studio_demo.sh (la démo Datacenter Pro complète)
#     9.  Code de sortie propagé + récapitulatif final
#
#   RÈGLE D'OR : AUCUNE nouvelle brique, AUCUN nouveau matériau ajouté au
#   projet NEXUS. On ne fait qu'installer les OUTILS nécessaires sur ta machine
#   et qu'orchestrer les modules v1.0 + Studio déjà livrés.
#
# ═════════════════════════════════════════════════════════════════════════════
set -u
IFS=$'\n\t'

# ── Couleurs ANSI ────────────────────────────────────────────────────────────
G='\033[0;32m'; C='\033[0;36m'; Y='\033[1;33m'; R='\033[0;31m'; B='\033[1m'
P='\033[0;35m'; D='\033[0;90m'; N='\033[0m'

# ── Variables globales ───────────────────────────────────────────────────────
DEPLOY_VERSION="1.1.0-brillant"
ARCHIVE_NAME="nexus-edge-studio-v1.1.zip"
REQUIRED_MODULES=(nexusd.py nexus-ctl.py nexus-smi.py nexus-bench.py)
REQUIRED_CONFIG="config/nexus.json"
STUDIO_FILES=(nexus_studio.py run_studio_demo.sh)
STEPS_DONE=0
STEPS_TOTAL=8
LOG_DIR=""
LOG_FILE=""
START_TS=$(date +%s)

# ── Helpers d'affichage ──────────────────────────────────────────────────────
banner() {
  echo ""
  echo -e "${C}╔══════════════════════════════════════════════════════════════════════╗${N}"
  echo -e "${C}║${B}   NEXUS STUDIO v1.1 — DÉPLOYEUR BRILLANT  ${P}v${DEPLOY_VERSION}${C}                ║${N}"
  echo -e "${C}║${B}   Trace · Bootstrap · Build · Launch  (modules v1.0 inchangés)     ${C}║${N}"
  echo -e "${C}╚══════════════════════════════════════════════════════════════════════╝${N}"
}

step() {
  STEPS_DONE=$((STEPS_DONE + 1))
  echo ""
  echo -e "${P}┌─ [${STEPS_DONE}/${STEPS_TOTAL}] ${1}${N}"
}

ok()   { echo -e "  ${G}✓${N} $*"; }
warn() { echo -e "  ${Y}!${N} $*"; }
err()  { echo -e "  ${R}✗${N} $*" >&2; }
trace(){ echo -e "  ${D}·${N} $*"; }
die()  { err "$*"; echo -e "${R}Déploiement interrompu.${N}"; exit 1; }

# ── Log : tout est tracé dans un fichier temporaire ──────────────────────────
setup_log() {
  LOG_DIR="${TMPDIR:-/tmp}/nexus-deploy"
  mkdir -p "$LOG_DIR"
  LOG_FILE="${LOG_DIR}/deploy-$(date +%Y%m%d-%H%M%S).log"
  exec > >(tee -a "$LOG_FILE") 2>&1
  trace "Journal complet : ${LOG_FILE}"
}

# ── Détection de l'OS / gestionnaire de paquets ──────────────────────────────
detect_pkgmgr() {
  if   command -v apt-get >/dev/null 2>&1; then PM="apt-get"; PM_INSTALL="sudo apt-get install -y"
  elif command -v dnf     >/dev/null 2>&1; then PM="dnf";     PM_INSTALL="sudo dnf install -y"
  elif command -v yum     >/dev/null 2>&1; then PM="yum";     PM_INSTALL="sudo yum install -y"
  elif command -v pacman  >/dev/null 2>&1; then PM="pacman";  PM_INSTALL="sudo pacman -S --noconfirm"
  elif command -v brew    >/dev/null 2>&1; then PM="brew";    PM_INSTALL="brew install"
  elif command -v pkg     >/dev/null 2>&1; then PM="pkg";     PM_INSTALL="sudo pkg install -y"
  else PM="none"; PM_INSTALL=""; fi
  trace "OS détecté : $(uname -srm)"
  trace "Gestionnaire de paquets : ${PM:-aucun}"
}

# ── Bootstrap d'un outil système si manquant ─────────────────────────────────
ensure_tool() {
  local tool="$1"
  local pkg="$2"
  if command -v "$tool" >/dev/null 2>&1; then
    ok "${tool} déjà présent ($(command -v "$tool"))"
    return 0
  fi
  if [ -z "${PM:-}" ] || [ "$PM" = "none" ]; then
    warn "${tool} introuvable et aucun gestionnaire de paquets détecté."
    warn "Installe-le manuellement puis relance ce déployeur."
    return 1
  fi
  warn "${tool} manquant — installation via ${PM} (paquet « ${pkg} »)…"
  if $PM_INSTALL "$pkg"; then
    ok "${tool} installé"
    return 0
  fi
  err "Échec d'installation de ${tool} via ${PM}."
  return 1
}

# ── Bootstrap des chaînes de construction (pip / cargo / npm) ────────────────
# On installe UNIQUEMENT la chaîne si elle manque — JAMAIS de paquet ajouté
# au projet NEXUS. pip n'est utilisé que pour du stdlib Python ; cargo et npm
# ne sont installés que pour que l'utilisateur puisse construire d'autres
# briques lui-même s'il le souhaite plus tard.
ensure_toolchains() {
  # pip (utile pour python -m pip, même si nexus_studio ne l'utilise pas)
  if python3 -m pip --version >/dev/null 2>&1; then
    ok "pip disponible ($(python3 -m pip --version | awk '{print $2}'))"
  else
    warn "pip manquant — installation du bootstrap officiel…"
    if curl -fsSL https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py 2>/dev/null \
       && python3 /tmp/get-pip.py --user >/dev/null 2>&1; then
      ok "pip installé (user)"
    else
      warn "pip non installé (le Studio n'en a pas besoin — stdlib uniquement)."
    fi
  fi

  # cargo (Rust) — installé uniquement si demandé via NEXUS_BOOTSTRAP_CARGO=1
  if [ "${NEXUS_BOOTSTRAP_CARGO:-0}" = "1" ]; then
    if command -v cargo >/dev/null 2>&1; then
      ok "cargo disponible ($(cargo --version))"
    else
      warn "cargo manquant — bootstrap rustup (peut prendre 1–2 min)…"
      if curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \
         | sh -s -- -y --profile minimal >/dev/null 2>&1; then
        # shellcheck disable=SC1090
        . "$HOME/.cargo/env" 2>/dev/null || true
        ok "cargo installé ($(cargo --version 2>/dev/null || echo '?'))"
      else
        warn "cargo non installé — pas bloquant pour le Studio."
      fi
    fi
  else
    trace "cargo ignoré (active avec NEXUS_BOOTSTRAP_CARGO=1 si tu en as besoin)."
  fi

  # npm (Node.js) — uniquement si demandé via NEXUS_BOOTSTRAP_NPM=1
  if [ "${NEXUS_BOOTSTRAP_NPM:-0}" = "1" ]; then
    if command -v npm >/dev/null 2>&1; then
      ok "npm disponible ($(npm --version 2>/dev/null || echo '?'))"
    else
      warn "npm manquant — installation via ${PM:-gestionnaire}…"
      case "${PM:-}" in
        apt-get) $PM_INSTALL nodejs npm >/dev/null 2>&1 && ok "npm installé" || warn "npm non installé." ;;
        dnf|yum) $PM_INSTALL nodejs npm >/dev/null 2>&1 && ok "npm installé" || warn "npm non installé." ;;
        pacman)  $PM_INSTALL nodejs npm >/dev/null 2>&1 && ok "npm installé" || warn "npm non installé." ;;
        brew)    $PM_INSTALL node >/dev/null 2>&1 && ok "npm installé" || warn "npm non installé." ;;
        *) warn "npm non installé — installe-le manuellement si tu en as besoin." ;;
      esac
    fi
  else
    trace "npm ignoré (active avec NEXUS_BOOTSTRAP_NPM=1 si tu en as besoin)."
  fi
}

# ── Localisation auto du dossier de projet ───────────────────────────────────
# Ordre : argument > $NEXUS_PROJECT_DIR > cwd (si contient nexusd.py) >
#         ~/Projects/cdn > ~/nexus-edge > recherche limitée dans $HOME
locate_project() {
  local arg="${1:-}"
  local tried=()

  # 1) Argument explicite
  if [ -n "$arg" ] && [ -d "$arg" ]; then
    PROJECT_DIR="${arg/#\~/$HOME}"
    ok "Dossier fourni en argument : ${PROJECT_DIR}"
    return 0
  fi
  [ -n "$arg" ] && tried+=("argument: ${arg} (introuvable)")

  # 2) Variable d'environnement
  if [ -n "${NEXUS_PROJECT_DIR:-}" ] && [ -d "${NEXUS_PROJECT_DIR}" ]; then
    PROJECT_DIR="${NEXUS_PROJECT_DIR/#\~/$HOME}"
    ok "Dossier via NEXUS_PROJECT_DIR : ${PROJECT_DIR}"
    return 0
  fi

  # 3) Dossier courant s'il contient déjà nexusd.py
  if [ -f "$(pwd)/nexusd.py" ]; then
    PROJECT_DIR="$(pwd)"
    ok "Dossier courant contient les modules : ${PROJECT_DIR}"
    return 0
  fi
  tried+=("cwd: $(pwd) (pas de nexusd.py)")

  # 4) Cibles usuelles
  for candidate in "$HOME/Projects/cdn" "$HOME/nexus-edge" "$HOME/projects/cdn" \
                   "$HOME/Téléchargements/nexus-edge" "$HOME/Downloads/nexus-edge" \
                   "$HOME/Documents/nexus-edge"; do
    [ -d "$candidate" ] && [ -f "$candidate/nexusd.py" ] && {
      PROJECT_DIR="$candidate"
      ok "Dossier trouvé automatiquement : ${PROJECT_DIR}"
      return 0
    }
    [ -d "$candidate" ] && tried+=("${candidate} (existe mais sans nexusd.py)")
  done

  # 5) Recherche récursive LIMITÉE (depth 4) dans $HOME
  trace "Recherche récursive limitée dans ${HOME} (profondeur 4)…"
  local found
  found=$(find "$HOME" -maxdepth 4 -type f -name "nexusd.py" 2>/dev/null | head -n 1)
  if [ -n "$found" ]; then
    PROJECT_DIR="$(dirname "$found")"
    ok "Dossier trouvé par recherche : ${PROJECT_DIR}"
    return 0
  fi

  # 6) Échec — on demande à l'utilisateur
  echo ""
  echo -e "  ${Y}Chemins essayés et rejetés :${N}"
  for t in "${tried[@]}"; do echo -e "    ${D}-${N} $t"; done
  echo ""
  read -rp "$(echo -e ${B}\"Entre le chemin exact de ton projet NEXUS v1.0 : \"${N})" PROJECT_DIR
  PROJECT_DIR="${PROJECT_DIR/#\~/$HOME}"
  [ -d "$PROJECT_DIR" ] && [ -f "$PROJECT_DIR/nexusd.py" ] && {
    ok "Dossier validé : ${PROJECT_DIR}"
    return 0
  }
  die "Dossier invalide ou sans nexusd.py : ${PROJECT_DIR:-<vide>}"
}

# ── Localisation de l'archive ────────────────────────────────────────────────
locate_archive() {
  ARCHIVE_PATH=""
  # 1) À côté du projet
  [ -f "${PROJECT_DIR}/${ARCHIVE_NAME}" ] && ARCHIVE_PATH="${PROJECT_DIR}/${ARCHIVE_NAME}"
  # 2) Dossier courant
  [ -z "$ARCHIVE_PATH" ] && [ -f "$(pwd)/${ARCHIVE_NAME}" ] && ARCHIVE_PATH="$(pwd)/${ARCHIVE_NAME}"
  # 3) Téléchargements FR/EN + Desktop
  for d in "$HOME/Téléchargements" "$HOME/Downloads" "$HOME/Desktop" "$HOME/Bureau" \
           "$HOME/Projects" "$HOME/projects" "$PROJECT_DIR"; do
    [ -z "$ARCHIVE_PATH" ] && [ -f "${d}/${ARCHIVE_NAME}" ] && ARCHIVE_PATH="${d}/${ARCHIVE_NAME}"
  done
  if [ -n "$ARCHIVE_PATH" ]; then
    ok "Archive localisée : ${ARCHIVE_PATH}"
    ok "Taille : $(du -h "$ARCHIVE_PATH" | awk '{print $1}')"
    return 0
  fi
  warn "Archive ${ARCHIVE_NAME} introuvable."
  warn "Si le Studio est déjà décompressé dans le projet, on continue sans archive."
  return 0
}

# ── Vérification d'intégrité des modules v1.0 ────────────────────────────────
verify_v1_modules() {
  local missing=0
  for m in "${REQUIRED_MODULES[@]}"; do
    if [ -f "${PROJECT_DIR}/${m}" ]; then
      ok "${m} présent ($(wc -l < "${PROJECT_DIR}/${m}") lignes)"
    else
      err "${m} MANQUANT"
      missing=$((missing + 1))
    fi
  done
  if [ -f "${PROJECT_DIR}/${REQUIRED_CONFIG}" ]; then
    ok "${REQUIRED_CONFIG} présent"
  else
    err "${REQUIRED_CONFIG} MANQUANT"
    missing=$((missing + 1))
  fi
  if [ "$missing" -gt 0 ]; then
    die "${missing} module(s) v1.0 manquant(s) — déployeur interrompu (règle d'or : ne jamais reconstruire les modules)."
  fi
  ok "Tous les modules v1.0 sont intacts (jamais modifiés par ce déployeur)."
}

# ── Décompression de l'archive avec trace ────────────────────────────────────
extract_archive() {
  if [ -z "${ARCHIVE_PATH:-}" ]; then
    # Pas d'archive : on vérifie juste que le Studio est déjà là
    if [ -f "${PROJECT_DIR}/nexus_studio.py" ]; then
      ok "nexus_studio.py déjà présent dans le projet (archive ignorée)."
      return 0
    fi
    die "Ni archive ni nexus_studio.py trouvé — rien à déployer."
  fi
  trace "Décompression de ${ARCHIVE_PATH} → ${PROJECT_DIR}"
  if unzip -o -q "$ARCHIVE_PATH" -d "$PROJECT_DIR"; then
    ok "Archive décompressée avec succès."
    # Trace des fichiers Studio extraits
    for f in "${STUDIO_FILES[@]}"; do
      if [ -f "${PROJECT_DIR}/${f}" ]; then
        trace "extrait : ${f} ($(wc -l < "${PROJECT_DIR}/${f}") lignes)"
      fi
    done
  else
    die "Échec de décompression de ${ARCHIVE_PATH}"
  fi
}

# ── Lancement de la démo ─────────────────────────────────────────────────────
launch_demo() {
  local launcher="${PROJECT_DIR}/run_studio_demo.sh"
  local studio="${PROJECT_DIR}/nexus_studio.py"
  if [ ! -f "$launcher" ]; then
    err "${launcher} introuvable après décompression."
    if [ -f "$studio" ]; then
      warn "Bascule directe sur python3 nexus_studio.py --demo"
      cd "$PROJECT_DIR" || die "Impossible d'entrer dans ${PROJECT_DIR}"
      python3 nexus_studio.py --doctor
      python3 nexus_studio.py --demo
      return $?
    fi
    die "Aucun lanceur exploitable."
  fi
  chmod +x "$launcher" 2>/dev/null || true
  cd "$PROJECT_DIR" || die "Impossible d'entrer dans ${PROJECT_DIR}"
  ok "Lancement de run_studio_demo.sh depuis $(pwd)"
  echo ""
  echo -e "  ${C}══════════════════════════════════════════════════════════════════${N}"
  echo -e "  ${B}  Appuie sur 'q' pour quitter l'écran temps réel.${N}"
  echo -e "  ${C}══════════════════════════════════════════════════════════════════${N}"
  bash "$launcher"
  return $?
}

# ── Récapitulatif final ──────────────────────────────────────────────────────
final_recap() {
  local rc=$1
  local elapsed=$(( $(date +%s) - START_TS ))
  echo ""
  echo -e "${C}╔══════════════════════════════════════════════════════════════════════╗${N}"
  if [ "$rc" -eq 0 ]; then
    echo -e "${C}║${G}${B}  ✓ DÉPLOIEMENT TERMINÉ — NEXUS STUDIO v1.1 OPÉRATIONNEL${C}             ║${N}"
  else
    echo -e "${C}║${Y}${B}  ! Déploiement terminé avec code ${rc}${C}                                  ║${N}"
  fi
  echo -e "${C}║${N}  Durée      : ${elapsed}s${C}                                                  ║${N}"
  echo -e "${C}║${N}  Projet     : ${PROJECT_DIR}${C}                                              ║${N}"
  echo -e "${C}║${N}  Journal    : ${LOG_FILE}${C}                                              ║${N}"
  echo -e "${C}║${N}  Modules v1.0 : INTACTS (jamais modifiés)${C}                              ║${N}"
  echo -e "${C}╚══════════════════════════════════════════════════════════════════════╝${N}"
  echo ""
  echo -e "  ${B}Prochaines commandes (depuis ${PROJECT_DIR}) :${N}"
  echo -e "    ${Y}python3 nexus_studio.py --menu${N}              console interactive"
  echo -e "    ${Y}python3 nexus_studio.py --screen${N}            écran temps réel (q = quitter)"
  echo -e "    ${Y}python3 nexus_studio.py --workflow pitch_demo${N}  vente Oracle/Google"
  echo -e "    ${Y}python3 nexus_studio.py --list${N}              catalogue 400 actions"
  echo ""
}

# ═════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═════════════════════════════════════════════════════════════════════════════
main() {
  setup_log
  banner
  detect_pkgmgr

  step "Bootstrap des outils système (python3, unzip, zip, curl)"
  ensure_tool python3 python3          || die "python3 est requis (stdlib uniquement, mais indispensable)."
  ensure_tool unzip   unzip            || warn "unzip manquant — décompression impossible si archive."
  ensure_tool zip     zip              || warn "zip manquant — re-paquetage impossible (non bloquant)."
  ensure_tool curl    curl             || warn "curl manquant — certains bootstraps seront ignorés (non bloquant)."
  ensure_tool sha256sum coreutils 2>/dev/null || trace "sha256sum non testé (optionnel)."

  step "Bootstrap des chaînes de construction (pip / cargo / npm)"
  ensure_toolchains

  step "Localisation du dossier projet NEXUS v1.0"
  locate_project "${1:-}"
  cd "$PROJECT_DIR" || die "Impossible d'entrer dans ${PROJECT_DIR}"

  step "Vérification d'intégrité des modules v1.0"
  verify_v1_modules

  step "Localisation de l'archive ${ARCHIVE_NAME}"
  locate_archive

  step "Décompression de l'archive (avec trace)"
  extract_archive

  step "Lancement de la démo Datacenter Pro"
  launch_demo
  local rc=$?

  final_recap "$rc"
  exit "$rc"
}

main "$@"
