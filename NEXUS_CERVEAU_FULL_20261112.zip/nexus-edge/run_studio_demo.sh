#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# NEXUS STUDIO v1.1 — DÉMO DATACENTER PRO EN UNE COMMANDE
#
#   bash run_studio_demo.sh
#
# Ce lanceur s'exécute TOUJOURS depuis son propre dossier (peu importe
# d'où vous l'appelez) : plus jamais « run_studio_demo.sh introuvable ».
# Les modules v1.0 (nexusd.py, nexus-ctl.py, nexus-smi.py, nexus-bench.py,
# config/nexus.json) ne sont jamais modifiés.
# ═══════════════════════════════════════════════════════════════════════════
set -u
cd "$(dirname "$0")" || exit 1

G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; R="\033[0;31m"; B="\033[1m"; N="\033[0m"

echo ""
echo -e "${C}═══════════════════════════════════════════════════════════════════${N}"
echo -e "${B}   NEXUS STUDIO v1.1 — DATACENTER PRO${N}"
echo -e "   400 actions · 12 catégories · 4 workflows · écran temps réel"
echo -e "   Qualité de déploiement 2× Vercel — modules v1.0 inchangés"
echo -e "${C}═══════════════════════════════════════════════════════════════════${N}"

# ── 0. Environnement ──────────────────────────────────────────────────────
if ! command -v python3 >/dev/null 2>&1; then
    echo -e "${R}❌ Python 3 introuvable — installez python3 puis relancez.${N}"
    exit 1
fi

if [ ! -f nexus_studio.py ]; then
    echo -e "${R}❌ nexus_studio.py absent de ce dossier ($(pwd)).${N}"
    echo -e "   Copiez le Studio dans votre dossier nexus-edge v1.0 :"
    echo -e "   ${Y}cp nexus_studio.py run_studio_demo.sh ~/chemin/vers/nexus-edge/${N}"
    exit 1
fi

echo -e "\n${G}[1/4] Diagnostic de l'installation (--doctor)…${N}"
python3 nexus_studio.py --doctor

echo -e "\n${G}[2/4] Séquence de démonstration (nœud, cache, garde 2× Vercel, pitch, écran)…${N}"
python3 nexus_studio.py --demo
DEMO_RC=$?

echo -e "\n${G}[3/4] Workflows disponibles…${N}"
python3 nexus_studio.py --workflows

echo -e "\n${G}[4/4] Pour aller plus loin :${N}"
echo -e "   Console interactive      : ${Y}python3 nexus_studio.py --menu${N}"
echo -e "   Écran temps réel         : ${Y}python3 nexus_studio.py --screen${N}   (q = quitter)"
echo -e "   Pitch visuel Oracle/Google : ${Y}python3 nexus_studio.py --pitch${N}"
echo -e "   Vente (revue complète)   : ${Y}python3 nexus_studio.py --workflow pitch_demo${N}"
echo -e "   Acceptation datacenter   : ${Y}python3 nexus_studio.py --workflow acceptance_datacenter${N}"
echo -e "   Prêt pour le datacenter  : ${Y}python3 nexus_studio.py --workflow dc_readiness${N}"
echo -e "   Catalogue des 400 actions: ${Y}python3 nexus_studio.py --list${N}"
echo -e "   Guides intégrés (11)     : ${Y}python3 nexus_studio.py --guide${N}"
echo -e "   Rapports de preuve       : ${Y}python3 nexus_studio.py --report${N}"
echo -e "${C}═══════════════════════════════════════════════════════════════════${N}"
echo -e "   Le nœud continue de tourner en fond. Pour l'arrêter :"
echo -e "   ${Y}python3 nexus-ctl.py stop${N}   (module v1.0, inchangé)"
echo ""

exit $DEMO_RC
