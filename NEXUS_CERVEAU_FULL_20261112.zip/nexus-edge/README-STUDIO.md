# NEXUS STUDIO v1.1 — DATACENTER PRO (fichier unique)

**400 actions d'exécution / test / workflow + écran temps réel + pitch visuel,
qualité de déploiement 2× Vercel — ajoutées PAR-DESSUS nexus-edge-v1.0.**

Les modules d'origine (`nexusd.py`, `nexus-ctl.py`, `nexus-smi.py`, `nexus-bench.py`,
`config/nexus.json`, `run_demo.sh`) sont **inchangés**. Le Studio les pilote par
leurs interfaces existantes (CLI + `/nexus/*`). Rien n'a été refait : tout a été ajouté.

Un seul fichier à installer : **`nexus_studio.py`** (~4400 lignes, stdlib uniquement,
Python 3.8+, aucune dépendance). Le lanceur `run_studio_demo.sh` est optionnel.

---

## 1. Installation (30 secondes)

Copiez le Studio **dans** votre dossier nexus-edge v1.0 existant :

```
cp nexus_studio.py run_studio_demo.sh  ~/chemin/vers/nexus-edge/
cd ~/chemin/vers/nexus-edge
python3 nexus_studio.py --doctor      # diagnostic instantané (8 contrôles)
```

Arborescence après installation :

```
nexus-edge/
├── nexusd.py, nexus-ctl.py, nexus-smi.py, nexus-bench.py   ← v1.0, INCHANGÉS
├── config/nexus.json, run_demo.sh, README.md               ← v1.0, INCHANGÉS
├── nexus_studio.py          ← NOUVEAU : LE STUDIO (fichier unique)
├── run_studio_demo.sh       ← NOUVEAU : démo en une commande (optionnel)
├── workflows/               ← auto-générés (4 workflows)
└── studio/                  ← résultats (results/), preuves (reports/), tmp/
```

## 2. Commandes

```
bash run_studio_demo.sh                          démo complète en une commande
python3 nexus_studio.py --menu                   console interactive (13 options)
python3 nexus_studio.py --screen                 écran temps réel (q = quitter)
python3 nexus_studio.py --pitch                  pitch visuel Oracle / Google
python3 nexus_studio.py --demo                   séquence de démonstration
python3 nexus_studio.py --doctor                 diagnostic de l'installation
python3 nexus_studio.py --workflow pitch_demo    vente (revue Oracle/Google)
python3 nexus_studio.py --workflow smoke_test    validation rapide (~15 s)
python3 nexus_studio.py --workflow acceptance_datacenter   acceptation (~90 s)
python3 nexus_studio.py --workflow dc_readiness  prêt datacenter (~30 s)
python3 nexus_studio.py --list                   les 400 actions par catégorie
python3 nexus_studio.py --list DEPLOY            détail d'une catégorie
python3 nexus_studio.py --list --json            sortie JSON (intégrations)
python3 nexus_studio.py --search vercel          recherche
python3 nexus_studio.py --info DEPLOY-013        détail d'une action
python3 nexus_studio.py --run LAT-001,DEPLOY-013 exécution directe
python3 nexus_studio.py --history 50             derniers résultats
python3 nexus_studio.py --report                 preuves + dernier verdict
python3 nexus_studio.py --guide                  11 guides intégrés
python3 nexus_studio.py --selftest               intégrité du catalogue
```

## 3. Les 12 catégories (400 actions)

| Cat.  | Actions | Rôle |
|-------|--------:|------|
| PROBE | 30 | sondes de nœud (health, metrics, uptime, registre) |
| LAT   | 50 | tests de latence + gardes contractuelles p50/p95/p99 |
| LOAD  | 40 | charge, montées en charge, soaks, origine vs edge |
| CACHE | 40 | warm-up, hit ratio, TTL, préchargement, redémarrage |
| RESIL | 40 | stale-if-error, churn, requêtes malformées, keep-alive |
| HDR   | 30 | en-têtes X-Nexus / Cache-Control / ETag |
| HTTP  | 40 | statuts, intégrité octets, HEAD, méthodes, keep-alive |
| FLEET | 30 | vue de flotte, sweeps, benchs multi-nœuds |
| CFG   | 20 | validation config, warm-up, PID, idempotence |
| RPT   | 30 | exports json/csv/md/txt, chronologies, archives zip |
| WF    | 20 | exécution et plans de workflows |
| DEPLOY| 30 | **prérequis, intégrité v1.0, systemd, pare-feu, logrotate, checklist, topologie, capacité, garde GO-LIVE N× Vercel** |

## 4. La qualité 2× Vercel (le cœur commercial)

- `VERCEL_BASELINE_MS = 200` : votre mesure TTFB du CDN (bench v1).
- **DEPLOY-013** — Garde GO-LIVE 2× : bench 50 échantillons, `p95 ≤ 100 ms` → PASS.
- **DEPLOY-014/015** — gardes 5× (p95 ≤ 40 ms) et 10× (p95 ≤ 20 ms).
- **DEPLOY-016/017** — comparaison live/en cache : gain ×N affiché.
- L'écran temps réel (page 1) et le pitch (--pitch) affichent le verdict en direct.
- Latence contractuelle NEXUS : p99 ≤ 2 ms (gardes LAT-045..047).

## 5. Écran temps réel (5 pages)

`--screen` puis : **1** Vue d'ensemble (nœud · cache · qualité 2× Vercel) ·
**2** Latence & échelle 200→2 ms · **3** Flotte · **4** Déploiement ·
**5** Journal d'actions. Touches : `r` sonde, `b` bench, `p` pitch, `q` quitter.

## 6. Garanties

- Modules v1.0 **jamais modifiés** ; l'arrêt/démarrage passe par `nexus-ctl`.
- Tests destructeurs (origine morte…) sur **nœud temporaire (8799) + origine
  mock (9100)** — le nœud de production n'est pas touché.
- Aucune commande privilégiée : systemd/pare-feu/logrotate sont **générés en
  fichiers texte** dans `studio/reports/` ; l'application reste humaine et signée.
- Sans internet, tout fonctionne sauf les actions `Bench Origine`.

## 7. Guides intégrés (--guide SUJET)

`latency` argumentaire 200→2 ms · `archi` pourquoi c'est possible ·
`deploy` procédure datacenter · `pitch` script 5 minutes · `sales` objections
chiffrées · `faq` 8 objections · `metrics` glossaire p50/p95/p99 ·
`roadmap` v1.5/v2.0/v3.0 · `workflows` les 4 suites · `quickstart` prise en main ·
`dossier` le pack de preuves à imprimer.

---
NEXUS STUDIO v1.1 — complément officiel de nexus-edge-v1.0. Preuves dans `studio/reports/`.
