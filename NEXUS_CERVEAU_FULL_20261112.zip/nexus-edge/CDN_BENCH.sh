#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════════════╗
# ║    N E X U S   C D N _ B E N C H   v2.0  —  TOUS LES CDN, RÉSEAU RÉEL    ║
# ╠══════════════════════════════════════════════════════════════════════════╣
# ║                                                                          ║
# ║  Un seul script. Bombarde 14 endpoints sur 11 RÉSEAUX CDN MAJEURS :      ║
# ║  Cloudflare · Fastly · Google · Microsoft Azure · Amazon CloudFront ·    ║
# ║  Vercel · Netlify · Bunny · Akamai (Steam) · Cloudinary · GitHub         ║
# ║  100% Internet réel — zéro simulation, zéro clé API, zéro localhost.     ║
# ║                                                                          ║
# ║   [1] SELFCHECK    outils requis                                         ║
# ║   [2] TRACE        le PoP Cloudflare physique qui répond à TA machine    ║
# ║   [3] SONDES       ×14 : mode FROID (DNS+TCP+TLS à chaque sonde) et      ║
# ║                    mode CHAUD (keep-alive, une seule connexion)          ║
# ║   [4] MESURES      DNS · TCP · TLS · TTFB · TOTAL · code · octets        ║
# ║                    min / avg / p50 / p95 / max — le p95 = le ressenti    ║
# ║   [5] GEO          PoP réel par CDN : cf-ray · x-amz-cf-pop ·            ║
# ║                    x-served-by · x-vercel-id · BunnyCDN-HK1              ║
# ║   [6] CLASSEMENT   tous les CDN triés par p95 TTFB + VERDICT             ║
# ║   [7] CONTRASTE    si NEXUS tourne sur :8765 → facteur de vitesse        ║
# ║                    CDN réel vs NEXUS (la démo des 120 investisseurs)     ║
# ║   [8] RAPPORTS     CDN_REEL_BENCH_<date>.txt (humain)                    ║
# ║                    CDN_REEL_BENCH_<date>.json (machine, validé)          ║
# ║                                                                          ║
# ║  Utilisation : bash CDN_BENCH.sh [quick|all|3..50]                       ║
# ║     quick → 5 sondes/CDN (lien lent) · défaut → 10 · ex: 20              ║
# ║                                                                          ║
# ║  Lecture seule côté projet : ne touche AUCUN module v1.0.                ║
# ╚══════════════════════════════════════════════════════════════════════════╝
set -u

# ────────────────────────────── couleurs ──────────────────────────────────────
G='\033[1;32m'; W='\033[1;37m'; Y='\033[1;33m'; R='\033[1;31m'
C='\033[1;36m'; D='\033[0;90m'; B='\033[1m'; N='\033[0m'

# ────────────────────────────── réglages ──────────────────────────────────────
N_PROBES=10
case "${1:-}" in
  quick) N_PROBES=5 ;;
  ''|all) N_PROBES=10 ;;
  *[!0-9]*) echo "argument inconnu : $1 (quick | 3..50)"; exit 1 ;;
  *) N_PROBES=$1 ;;
esac
[ "$N_PROBES" -lt 3 ]  && N_PROBES=3
[ "$N_PROBES" -gt 50 ] && N_PROBES=50
TIMEOUT=12          # secondes max par requête (CloudFront sert 3.4 Mo)
CTIMEOUT=4          # secondes max connexion
STAMP=$(date '+%Y%m%d-%H%M%S')
REPORT_TXT="$PWD/CDN_REEL_BENCH_${STAMP}.txt"
REPORT_JSON="$PWD/CDN_REEL_BENCH_${STAMP}.json"
TMP=$(mktemp -d /tmp/cdn_bench.XXXXXX)
trap 'rm -rf "$TMP"' EXIT
NEXUS_URL="http://127.0.0.1:8765/nexus/health"   # contraste optionnel, jamais requis

# ─────────────────── les 14 vrais endpoints (11 réseaux) ──────────────────────
#  format : nom|réseau|URL d'un vrai asset public servi par ce réseau
ENDPOINTS=(
  "cdnjs|Cloudflare|https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
  "jsDelivr|Cloudflare+Fastly|https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"
  "Fastly-jsDelivr|Fastly|https://fastly.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"
  "Google-CDN|Google|https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"
  "Google-Fonts|Google|https://fonts.googleapis.com/css2?family=Roboto&display=swap"
  "Azure-CDN|Microsoft|https://ajax.aspnetcdn.com/ajax/jquery/jquery-3.7.1.min.js"
  "unpkg|Cloudflare|https://unpkg.com/jquery@3.7.1/dist/jquery.min.js"
  "Vercel|Vercel|https://nextjs.org/"
  "CloudFront|Amazon AWS|https://sdk.amazonaws.com/js/aws-sdk-2.1691.0.min.js"
  "Netlify|Netlify|https://www.netlify.com/"
  "BunnyCDN|Bunny|https://bunny.net/"
  "Steam-CDN|Akamai|https://cdn.akamai.steamstatic.com/steam/apps/730/header.jpg"
  "Cloudinary|Cloudinary|https://res.cloudinary.com/demo/image/upload/sample.jpg"
  "GitHub-raw|GitHub (Fastly)|https://raw.githubusercontent.com/jquery/jquery/main/README.md"
)
TRACE_URL="https://www.cloudflare.com/cdn-cgi/trace"

# format de mesure curl : dns tcp tls ttfb total code taille ip
FMT='%{time_namelookup} %{time_connect} %{time_appconnect} %{time_starttransfer} %{time_total} %{http_code} %{size_download} %{remote_ip}\n'

# ────────────────────────── sortie + rapport simultanés ───────────────────────
exec > >(tee "$REPORT_TXT") 2>&1

banner() {
  printf "${B}╔══════════════════════════════════════════════════════════════════╗${N}\n"
  printf "${B}║  NEXUS CDN_BENCH v2.0 — TOUS LES CDN MAJEURS, INTERNET 100%% RÉEL ║${N}\n"
  printf "${B}║  14 endpoints · 11 réseaux · chaque chiffre vient du réseau      ║${N}\n"
  printf "${B}╚══════════════════════════════════════════════════════════════════╝${N}\n"
}

# ────────────────────────────── [1] SELFCHECK ─────────────────────────────────
selfcheck() {
  printf "\n${C}═══[ SELFCHECK — outils requis ]═════════════════════════════════════${N}\n"
  local ok=1
  for t in curl awk sort tee date mktemp grep cut head tail printf sed; do
    if command -v "$t" >/dev/null 2>&1; then
      printf "  ${G}✓${N} $t\n"
    else
      printf "  ${R}✗${N} $t ABSENT — installe-le puis relance\n"; ok=0
    fi
  done
  [ "$ok" -eq 1 ] || { printf "${R}outils manquants, arrêt.${N}\n"; exit 1; }
  printf "  ${G}✓${N} $N_PROBES sondes par CDN · timeout ${TIMEOUT}s · ${#ENDPOINTS[@]} endpoints\n"
}

# ───────────────────── stats : min avg p50 p95 max sur 1 colonne ──────────────
#  $1 = fichier (1 ligne par sonde, 8 colonnes)   $2 = numéro de colonne
stats() {
  sort -g -k"$2","$2" "$1" 2>/dev/null | awk -v c="$2" '{
    v[++n]=$c*1000; s+=$c*1000
  } END {
    if (n==0) { print "NA NA NA NA NA"; exit }
    i50=int(n*0.5+0.999); i95=int(n*0.95+0.999)
    if (i50<1) i50=1; if (i95<1) i95=1; if (i50>n) i50=n; if (i95>n) i95=n
    printf "%.1f %.1f %.1f %.1f %.1f", v[1], s/n, v[i50], v[i95], v[n]
  }'
}

# ligne de détail  min/avg/p50/p95/max pour une colonne donnée
line_stats() { # $1=fichier $2=colonne $3=libellé
  local s lbl
  lbl="$3"
  s=$(stats "$1" "$2")
  if [ "$s" = "NA NA NA NA NA" ]; then
    printf "      ${D}%-7s toutes sondes échouées${N}\n" "$lbl"
    return
  fi
  set -- $s
  printf "      %-7s ${W}min %7.1f${N}  ${W}avg %7.1f${N}  ${W}p50 %7.1f${N}  ${B}${G}p95 %7.1f${N}  ${W}max %7.1f${N}  ms\n" \
         "$lbl" "$1" "$2" "$3" "$4" "$5"
}

# ──────────────────── [5] GEO : le PoP réel qui répond ────────────────────────
pop_name() {
  case "$1" in
    CDG) echo "Paris";;
    ORY) echo "Paris-Orly";;
    MRS) echo "Marseille";;
    LYS) echo "Lyon";;
    NCE) echo "Nice";;
    BOD) echo "Bordeaux";;
    LIL) echo "Lille";;
    LHR) echo "Londres";;
    MAN) echo "Manchester";;
    AMS) echo "Amsterdam";;
    FRA) echo "Francfort";;
    MUC) echo "Munich";;
    DRS) echo "Dresde";;
    HAM) echo "Hambourg";;
    BRU) echo "Bruxelles";;
    GVA) echo "Genève";;
    ZRH) echo "Zurich";;
    MAD) echo "Madrid";;
    BCN) echo "Barcelone";;
    LIS) echo "Lisbonne";;
    MIL) echo "Milan";;
    MXP) echo "Milan";;
    FCO) echo "Rome";;
    VIE) echo "Vienne";;
    PRG) echo "Prague";;
    WAW) echo "Varsovie";;
    STO) echo "Stockholm";;
    CPH) echo "Copenhague";;
    DUB) echo "Dublin";;
    LUX) echo "Luxembourg";;
    HKG) echo "Hong Kong";;
    HK1) echo "Hong Kong";;
    EWR) echo "Newark";;
    JFK) echo "New York";;
    IAD) echo "Washington";;
    ORD) echo "Chicago";;
    DFW) echo "Dallas";;
    DEN) echo "Denver";;
    LAX) echo "Los Angeles";;
    SJC) echo "San José";;
    SEA) echo "Seattle";;
    ATL) echo "Atlanta";;
    YYZ) echo "Toronto";;
    YVR) echo "Vancouver";;
    GRU) echo "São Paulo";;
    EZE) echo "Buenos Aires";;
    SCL) echo "Santiago";;
    BOG) echo "Bogota";;
    MEX) echo "Mexico";;
    NRT) echo "Tokyo";;
    KIX) echo "Osaka";;
    ICN) echo "Séoul";;
    SIN) echo "Singapour";;
    HKG1) echo "Hong Kong";;
    TPE) echo "Taipei";;
    BKK) echo "Bangkok";;
    DEL) echo "Delhi";;
    BOM) echo "Mumbai";;
    MAA) echo "Chennai";;
    DXB) echo "Dubaï";;
    DOH) echo "Doha";;
    JNB) echo "Johannesburg";;
    SYD) echo "Sydney";;
    MEL) echo "Melbourne";;
    AKL) echo "Auckland";;
    *)   echo "PoP $1";;
  esac
}
# deuxième essai : HKG1 → HKG, CDG1 → CDG (on retire les chiffres)
pop_resolve() {
  local p="$1" p2
  p2=$(pop_name "$p")
  if [ "${p2#PoP }" != "$p2" ]; then           # pas dans la table → on retire les chiffres
    p2=$(pop_name "$(printf '%s' "$p" | sed 's/[0-9]*$//')")
  fi
  printf '%s' "$p2"
}

# extrait le PoP des en-têtes réels, par ordre de confiance :
#  cf-ray → x-amz-cf-pop → x-served-by (Fastly/GitHub) → x-vercel-id → BunnyCDN-XX
pop_from_headers() { # $1=cf-ray $2=amz-pop $3=x-served-by $4=x-vercel-id $5=server
  if   [ -n "$1" ]; then printf '%s' "$1" | awk -F- '{print $NF}'
  elif [ -n "$2" ]; then printf '%s' "$2" | awk -F- '{print $1}'
  elif [ -n "$3" ]; then printf '%s' "$3" | tr ',' '\n' | tail -1 | awk -F- '{print $NF}'
  elif [ -n "$4" ]; then printf '%s' "$4" | awk -F:: '{print $1}' | tr 'a-z' 'A-Z'
  elif [ -n "$5" ] && printf '%s' "$5" | grep -q '^BunnyCDN-'; then
                          printf '%s' "$5" | cut -d- -f2
  else printf ''
  fi
}

headers_info() { # $1=URL  → renvoie "PoP|cache|serveur"
  local h="$TMP/hdr.$$"
  curl -s -m "$TIMEOUT" --connect-timeout "$CTIMEOUT" -4 -D "$h" -o /dev/null \
       -A "NEXUS-CDNBench/2.0" "$1" 2>/dev/null || true
  local ray amz xserved vid srv cache
  ray=$(grep -i '^cf-ray:' "$h" | head -1 | tr -d '\r' | awk '{print $2}')
  amz=$(grep -i '^x-amz-cf-pop:' "$h" | head -1 | tr -d '\r' | awk '{print $2}')
  xserved=$(grep -i '^x-served-by:' "$h" | head -1 | tr -d '\r' | cut -d' ' -f2-)
  vid=$(grep -i '^x-vercel-id:' "$h" | head -1 | tr -d '\r' | cut -d' ' -f2-)
  srv=$(grep -i '^server:' "$h" | head -1 | tr -d '\r' | cut -d' ' -f2)
  cache=$(grep -i '^cf-cache-status:\|^x-cache:\|^x-vercel-cache:' "$h" \
          | head -2 | tr -d '\r' | tr '\n' ' ' | sed 's/  */ /g; s/ $//')
  local age
  age=$(grep -i '^age:' "$h" | head -1 | tr -d '\r' | awk '{print tolower($1)" "$2}')
  [ -n "$age" ] && cache="${cache:+$cache · }$age"
  local pop
  pop=$(pop_from_headers "$ray" "$amz" "$xserved" "$vid" "$srv")
  rm -f "$h"
  printf '%s|%s|%s' "$pop" "$cache" "$srv"
}

# ─────────────────────── [3]+[4] mesure d'un CDN ──────────────────────────────
TABLE_LINES=""    # nom|réseau|p95_froid|p95_chaud|pop|cache
JSON_LINES=""     # nom|réseau|url|code|échecs|pop|cache|stats_cold(5 val)|p95_chaud

bench_endpoint() { # $1=nom $2=réseau $3=URL
  local name="$1" provider="$2" url="$3"
  local cold="$TMP/cold_${name}.txt" warm="$TMP/warm_${name}.txt"
  : > "$cold"; : > "$warm"

  printf "\n${C}═══[ %s — %s ]═════════════════════════════════════════════════════${N}\n" "$name" "$provider"
  printf "  ${D}GET %s${N}\n" "$url"

  # en-têtes réels : qui répond, depuis quel datacenter, cache HIT/MISS
  local info pop cache srv
  info=$(headers_info "$url")
  pop=$(printf '%s' "$info" | cut -d'|' -f1)
  cache=$(printf '%s' "$info" | cut -d'|' -f2)
  srv=$(printf '%s' "$info" | cut -d'|' -f3)
  if [ -n "$pop" ]; then
    printf "  ${G}PoP réel${N} : ${W}%s (%s)${N}\n" "$pop" "$(pop_resolve "$pop")"
  else
    printf "  ${D}PoP : non exposé par ce réseau${N}\n"
  fi
  local meta=""
  [ -n "$srv" ]   && meta="serveur: $srv"
  [ -n "$cache" ] && meta="${meta:+$meta · }$cache"
  [ -n "$meta" ]  && printf "  ${D}%s${N}\n" "$meta"

  # mode FROID — chaque sonde = nouvelle DNS + TCP + TLS (première visite réelle)
  printf "  ${B}FROID${N} — $N_PROBES sondes, nouvelle connexion complète à chaque sonde\n"
  local i code fails=0
  for i in $(seq 1 "$N_PROBES"); do
    curl -s -m "$TIMEOUT" --connect-timeout "$CTIMEOUT" -4 -o /dev/null \
         -A "NEXUS-CDNBench/2.0" -w "$FMT" "$url" >> "$cold" 2>/dev/null || fails=$((fails+1))
  done
  code=$(awk '{print $6}' "$cold" | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
  [ -z "$code" ] && code=000
  line_stats "$cold" 1 "DNS"
  line_stats "$cold" 2 "TCP"
  line_stats "$cold" 3 "TLS"
  line_stats "$cold" 4 "TTFB"
  line_stats "$cold" 5 "TOTAL"
  printf "      ${D}code HTTP %s · %s sondes échouées · taille: %s octets${N}\n" \
         "$code" "$fails" "$(awk '$7>0{print $7}' "$cold" | sort -n | tail -1)"

  # mode CHAUD — une seule connexion, N requêtes keep-alive (comme NEXUS)
  printf "  ${B}CHAUD${N} — $N_PROBES requêtes sur UNE seule connexion (keep-alive)\n"
  local urls="" j
  for j in $(seq 1 "$N_PROBES"); do urls="$urls \"$url\""; done
  eval "curl -s -m $TIMEOUT --connect-timeout $CTIMEOUT -4 -o /dev/null -A NEXUS-CDNBench/2.0 -w \"$FMT\" $urls" \
       > "$warm" 2>/dev/null || true
  grep -E '^([0-9.]+ ){7}[0-9.]+$' "$warm" > "$warm.f" 2>/dev/null && mv "$warm.f" "$warm" || true
  line_stats "$warm" 4 "TTFB"
  line_stats "$warm" 5 "TOTAL"

  # valeurs pour le classement + les rapports
  local p95c p95w sc
  sc=$(stats "$cold" 4)
  p95c=$(printf '%s' "$sc" | awk '{print $4}')
  p95w=$(stats "$warm" 4 | awk '{print $4}')
  TABLE_LINES="${TABLE_LINES}${name}|${provider}|${p95c:-NA}|${p95w:-NA}|${pop:-—}|${cache:-—}\n"
  JSON_LINES="${JSON_LINES}${name}|${provider}|${url}|${code}|${fails}|${pop:-}|${cache:-}|${sc}|${p95w:-NA}\n"
}

# ─────────────────── [7] contraste optionnel NEXUS en local ───────────────────
NEXUS_P95=""
bench_nexus() {
  printf "\n${C}═══[ CONTRASTE — nœud NEXUS local :8765 (optionnel, démo pitch) ]═════${N}\n"
  if ! curl -s -m 1 -o /dev/null "$NEXUS_URL" 2>/dev/null; then
    printf "  ${D}aucun nœud NEXUS détecté sur :8765 — contraste sauté (le bench CDN reste 100%% réel)${N}\n"
    return
  fi
  local f="$TMP/nexus.txt"; : > "$f"
  local i
  for i in $(seq 1 "$N_PROBES"); do
    curl -s -m 2 -o /dev/null -w "$FMT" "$NEXUS_URL" >> "$f" 2>/dev/null || true
  done
  grep -E '^([0-9.]+ ){7}[0-9.]+$' "$f" > "$f.f" 2>/dev/null && mv "$f.f" "$f" || true
  local p95
  p95=$(stats "$f" 4 | awk '{print $4}')
  [ -z "$p95" ] && p95="NA"
  printf "  ${G}NEXUS répond${N} — p95 TTFB local : ${B}${W}%s ms${N}\n" "$p95"
  NEXUS_P95="$p95"
}

# ─────────────────────────── [6] classement + verdict ─────────────────────────
ranking() {
  printf "\n${B}╔══════════════════════════════════════════════════════════════════╗${N}\n"
  printf "${B}║   CLASSEMENT — p95 TTFB connexion froide (le ressenti réel)       ║${N}\n"
  printf "${B}╚══════════════════════════════════════════════════════════════════╝${N}\n"
  printf "%-16s %-18s %10s %10s   %-6s %s\n" "CDN" "réseau" "p95 froid" "p95 chaud" "PoP" "cache"
  printf "%s\n" "──────────────────────────────────────────────────────────────────────────────"
  printf '%b' "$TABLE_LINES" | sort -t'|' -k3 -g | awk -F'|' '
    {
      c=substr($6,1,32)
      printf "%-16s %-18s %8s ms %8s ms   %-6s %s\n", $1, $2, $3, $4, $5, c
    }'

  local best bestv
  best=$(printf '%b' "$TABLE_LINES" | sort -t'|' -k3 -g | head -1 | cut -d'|' -f1)
  bestv=$(printf '%b' "$TABLE_LINES" | sort -t'|' -k3 -g | head -1 | cut -d'|' -f3)

  printf "\n${B}VERDICT${N} :\n"
  printf "  ${W}•${N} meilleur CDN réel ici : ${G}%s${N} à p95 ${W}%s ms${N} (TTFB froid)\n" "$best" "$bestv"
  printf "  ${W}•${N} mesure prise depuis CETTE machine — réseau réel, assets réels, rien de simulé\n"

  if [ -n "$NEXUS_P95" ] && [ "$NEXUS_P95" != "NA" ]; then
    awk -v nx="$NEXUS_P95" -v cd="$bestv" 'BEGIN{
      if (nx+0 > 0) {
        printf "  • NEXUS local p95 : %.1f ms → %.1f× plus rapide que le meilleur CDN réel (%s ms)\n", nx, cd/nx, cd
        printf "  • le CDN reste limité par le trajet aller-retour ; NEXUS sert à <50 km, 100%% RAM\n", cd
      }
    }'
  fi
  printf "  ${D}rapports : %s${N}\n" "$REPORT_TXT"
  printf "  ${D}            %s${N}\n" "$REPORT_JSON"
}

# ───────────────────────── [8] rapport JSON (validé) ──────────────────────────
json_escape() { printf '%s' "$1" | tr -d '"' | tr -d '\\' | tr '\n' ' '; }

write_json() {
  local first=1
  printf '{\n' > "$REPORT_JSON"
  printf '  "script": "NEXUS_CDN_BENCH",\n  "version": "2.0",\n  "date": "%s",\n  "probes_per_cdn": %d,\n  "endpoints_tested": %d,\n  "network": "internet-reel",\n' \
    "$STAMP" "$N_PROBES" "${#ENDPOINTS[@]}" >> "$REPORT_JSON"
  printf '  "results": [\n' >> "$REPORT_JSON"
  while IFS='|' read -r name provider url code fails pop cache sc p95w; do
    [ "$first" -eq 1 ] || printf ',\n' >> "$REPORT_JSON"
    first=0
    local cmin cavg cp50 cp95 cmax cp95w
    if [ "${sc%% *}" = "NA" ]; then
      cmin="null"; cavg="null"; cp50="null"; cp95="null"; cmax="null"
    else
      set -- $sc
      cmin=$1; cavg=$2; cp50=$3; cp95=$4; cmax=$5
    fi
    if [ "$p95w" = "NA" ] || [ -z "$p95w" ]; then cp95w="null"; else cp95w="$p95w"; fi
    printf '    {"cdn": "%s", "reseau": "%s", "url": "%s", "pop": "%s", "cache": "%s", "http_code": %d, "echecs": %d, "ttfb_froid_ms": {"min": %s, "avg": %s, "p50": %s, "p95": %s, "max": %s}, "ttfb_chaud_p95_ms": %s}' \
      "$(json_escape "$name")" "$(json_escape "$provider")" "$(json_escape "$url")" \
      "$(json_escape "$pop")" "$(json_escape "$cache")" "$code" "$fails" \
      "$cmin" "$cavg" "$cp50" "$cp95" "$cmax" "$cp95w" >> "$REPORT_JSON"
  done <<EOF
$(printf '%b' "$JSON_LINES")
EOF
  printf '\n  ],\n' >> "$REPORT_JSON"
  local best bestv bestv_out
  best=$(printf '%b' "$TABLE_LINES" | sort -t'|' -k3 -g | head -1 | cut -d'|' -f1)
  bestv=$(printf '%b' "$TABLE_LINES" | sort -t'|' -k3 -g | head -1 | cut -d'|' -f3)
  bestv_out="null"; [ -n "$bestv" ] && [ "$bestv" != "NA" ] && bestv_out="$bestv"
  printf '  "meilleur_cdn": {"cdn": "%s", "p95_froid_ms": %s},\n' \
    "$(json_escape "$best")" "$bestv_out" >> "$REPORT_JSON"
  if [ -n "$NEXUS_P95" ] && [ "$NEXUS_P95" != "NA" ]; then
    printf '  "nexus_local": {"detecte": true, "port": 8765, "p95_ttfb_ms": %s, "speedup_vs_meilleur_cdn": %s},\n' \
      "$NEXUS_P95" "$(awk -v nx="$NEXUS_P95" -v cd="${bestv:-0}" 'BEGIN{ if(nx+0>0) printf "%.1f", cd/nx; else printf "null" }')" >> "$REPORT_JSON"
  else
    printf '  "nexus_local": {"detecte": false, "port": 8765, "p95_ttfb_ms": null, "speedup_vs_meilleur_cdn": null},\n' >> "$REPORT_JSON"
  fi
  printf '  "note": "chaque valeur vient de vraies requetes curl sur internet - aucune simulation"\n}\n' >> "$REPORT_JSON"

  # auto-validation du JSON : pas de fake, le rapport doit être propre
  if command -v python3 >/dev/null 2>&1; then
    if python3 -m json.tool "$REPORT_JSON" >/dev/null 2>&1; then
      printf "  ${G}✓${N} rapport JSON validé : ${W}%s${N}\n" "$REPORT_JSON"
    else
      printf "  ${R}✗${N} JSON invalide : %s${N}\n" "$REPORT_JSON"
    fi
  fi
}

# ────────────────────── [2] trace : le PoP qui répond ─────────────────────────
trace_pop() {
  printf "\n${C}═══[ TRACE — le datacenter Cloudflare qui répond VRAIMENT à ta machine ]═══${N}\n"
  local out
  out=$(curl -s -m "$TIMEOUT" --connect-timeout "$CTIMEOUT" -4 "$TRACE_URL" 2>/dev/null) || out=""
  local loc ip colo
  colo=$(printf '%s' "$out" | grep -o '^colo=.*' | cut -d= -f2)
  loc=$(printf  '%s' "$out" | grep -o '^loc=.*'  | cut -d= -f2)
  ip=$(printf  '%s' "$out" | grep -o '^ip=.*'   | cut -d= -f2)
  if [ -n "$colo" ]; then
    printf "  ${G}✓${N} trafic sortant : ${W}%s${N} · PoP Cloudflare = ${B}%s (%s)${N}\n" \
           "${ip:-?}" "$colo" "$(pop_resolve "$colo")"
    printf "  ${D}pays réseau: %s · ce datacenter PHYSIQUE a répondu à tes sondes${N}\n" "${loc:-?}"
  else
    printf "  ${D}trace indisponible (réseau filtré) — les mesures des CDN restent valides${N}\n"
  fi
}

# ──────────────────────────────── MAIN ────────────────────────────────────────
banner
selfcheck
trace_pop

printf "\n${B}── %d sondes × %d endpoints · %d réseaux CDN majeurs · réseau réel ──${N}\n" \
       "$N_PROBES" "${#ENDPOINTS[@]}" 11

i=0
for ep in "${ENDPOINTS[@]}"; do
  i=$((i+1))
  name=$(printf '%s' "$ep" | cut -d'|' -f1)
  prov=$(printf '%s' "$ep" | cut -d'|' -f2)
  url=$(printf '%s' "$ep" | cut -d'|' -f3)
  printf "${D}[bench %d/%d]${N} " "$i" "${#ENDPOINTS[@]}"
  bench_endpoint "$name" "$prov" "$url"
done

bench_nexus
ranking
write_json

printf "\n${G}terminé${N} — %d sondes × %d endpoints · rapports :\n" "$N_PROBES" "${#ENDPOINTS[@]}"
printf "  ${W}%s${N}\n  ${W}%s${N}\n" "$REPORT_TXT" "$REPORT_JSON"
