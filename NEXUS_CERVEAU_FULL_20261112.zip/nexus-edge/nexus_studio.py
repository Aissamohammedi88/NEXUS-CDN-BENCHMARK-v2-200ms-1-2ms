#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
════════════════════════════════════════════════════════════════════════════
 NEXUS STUDIO v1.1 — DATACENTER PRO (fichier unique, ~4400 lignes)
 ═══════════════════════════════════════════════════════════════════════════

 Complément AJOUTÉ à nexus-edge-v1.0.
 Les modules d'origine (nexusd.py, nexus-ctl.py, nexus-smi.py,
 nexus-bench.py, config/nexus.json) ne sont PAS modifiés : ce fichier se
 branche dessus par leurs interfaces existantes (CLI + /nexus/*).

 CE QUE FAIT CE STUDIO
 ─────────────────────
   • 400 actions catalogées, prêtes à exécuter, réparties en 12 catégories :
       PROBE  (30) sondes de nœud          FLEET  (30) opérations de flotte
       LAT    (50) tests de latence        CFG    (20) configuration
       LOAD   (40) tests de charge         RPT    (30) rapports & exports
       CACHE  (40) opérations de cache     WF     (20) workflows
       RESIL  (40) résilience              DEPLOY (30) déploiement datacenter
       HDR    (30) en-têtes                       & qualité 2× Vercel
       HTTP   (40) vérifications HTTP
   • Écran temps réel plein écran (« écran ») : état du nœud, cache,
     latences p50/p95/p99, garde qualité 2× Vercel, flotte, journal d'actions.
   • Pitch visuel Oracle / Google : comparaison VERCEL 200 ms vs NEXUS,
     échelle de latence 200→120→15→2 ms, verdict de qualité.
   • 4 workflows prédéfinis : smoke_test, pitch_demo,
     acceptance_datacenter, dc_readiness (auto-régénérés si absents).
   • Rapports horodatés dans studio/reports/ + historique JSONL.

 INSTALLATION (rien à refaire)
 ─────────────────────────────
   1. Copier CE fichier dans votre dossier nexus-edge v1.0 existant
      (à côté de nexusd.py, nexus-ctl.py, nexus-smi.py, nexus-bench.py).
   2. Optionnel : copier aussi run_studio_demo.sh (lanceur une commande).
   3. Aucune dépendance externe : Python 3.8+ (stdlib uniquement).

 COMMANDES
 ─────────
   bash run_studio_demo.sh                     démo complète en une commande
   python3 nexus_studio.py --menu              console interactive
   python3 nexus_studio.py --screen            écran temps réel (q = quitter)
   python3 nexus_studio.py --pitch             pitch visuel Oracle/Google
   python3 nexus_studio.py --demo              séquence de démonstration
   python3 nexus_studio.py --workflow pitch_demo            vente Oracle/Google
   python3 nexus_studio.py --workflow smoke_test            validation ~15 s
   python3 nexus_studio.py --workflow acceptance_datacenter acceptation ~90 s
   python3 nexus_studio.py --workflow dc_readiness          prêt datacenter
   python3 nexus_studio.py --selftest          vérifie le catalogue (400)
   python3 nexus_studio.py --list [CAT]        catégories / actions
   python3 nexus_studio.py --search MOT        recherche une action
   python3 nexus_studio.py --run ID[,ID…]      exécute une/des actions
   python3 nexus_studio.py --guide SUJET       guide intégré
                                              (latency|deploy|pitch|faq)

 GARANTIES
 ─────────
   • nexusd.py, nexus-ctl.py, nexus-smi.py, nexus-bench.py : INCHANGÉS.
   • Aucune donnée du cache n'est détruite par le Studio lui-même
     (seules des actions explicites de redémarrage le font, et elles
     l'annoncent dans leur libellé).
   • Les tests « destructeurs » (stale-if-error, origine morte) utilisent
     un nœud EDGE TEMPORAIRE + une ORIGINE MOCK locale sur des ports
     dédiés (8799 / 9100) — le nœud de production n'est jamais touché.
   • Le Studio ne s'exécute jamais avec des droits root requis ;
     tout passe par l'utilisateur courant.

 ARCHITECTURE (dans ce seul fichier)
 ───────────────────────────────────
   1. Constantes & helpers HTTP                    (ce début de fichier)
   2. Origine mock + nœud edge temporaire          (tests de résilience)
   3. Primitives d'action  fn(params, ctx) -> dict (63 familles + 8 déploiement)
   4. Catalogue — exactement 400 actions           (contrôle d'intégrité)
   5. Écran temps réel + pitch visuel              (TUI ANSI, multi-pages)
   6. Moteur d'exécution, gardes, workflows, rapports
   7. Console interactive + CLI
════════════════════════════════════════════════════════════════════════════
"""

import argparse
import hashlib
import http.client
import http.server
import json
import os
import select
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════
# INDEX DES PRIMITIVES — 73 familles au service des 400 actions
# ═══════════════════════════════════════════════════════════════════════════
#
#  SONDES          act_probe_health         GET /nexus/health (timeouts variés)
#                  act_probe_metrics        GET /nexus/metrics (timeouts variés)
#                  act_probe_uptime         ancienneté du processus nexusd
#                  act_registry_raw/json    registre registry/nodes.json
#                  act_state_file           runtime/state.json (3 contrôles)
#                  act_version_check        bannière nexusd/1.x
#                  act_offline_probe        port TCP au repos (refus attendu)
#
#  LATENCE         act_bench_edge           TTFB keep-alive chemin Nexus
#                  act_bench_origin         TTFB CDN d'origine (comparaison)
#                  act_rtt_probe            RTT pur edge / origine
#                  act_gate_latency         mesure + assertion contractuelle
#
#  CHARGE          act_load                 rafale workers (keep-alive/newconn)
#                  act_ramp                 montée en charge par paliers
#
#  CACHE           act_warm                 préchauffage simple/double/HEAD
#                  act_hit_ratio            taux HIT après warm-up
#                  act_restart_clear        STOP→START→MISS→HIT
#                  act_prefetch             préchargement ciblé/catalogue
#                  act_ttl_check            fraîcheur TTL sur nœud temporaire
#
#  RÉSILIENCE      act_stale                stale-if-error (5 scénarios)
#                  act_churn                ouverture/fermeture en rafale
#                  act_malformed            10 requêtes malformées (jamais crash)
#                  act_idle                 keep-alive vs inactivité (1..35 s)
#
#  EN-TÊTES        act_header_check         Cache-Control/X-Nexus/ETag/…
#
#  HTTP            act_http_status          GET → 200
#                  act_content_length       longueur exacte
#                  act_head_matches         HEAD ≡ GET
#                  act_body_hash            intégrité octets Edge=Origine
#                  act_unknown_path         502 propre sans crash
#                  act_method_405           méthodes refusées proprement
#                  act_keepalive_n          N requêtes sur 1 connexion
#
#  FLOTTE          act_smi_list             vue nexus-smi (plain/json/rtt)
#                  act_sweep                balayage santé/métriques
#                  act_fleet_bench/rtt      latence par nœud
#                  act_fleet_report         rapport de flotte (txt/md)
#                  act_registry_export      registre (json/csv)
#
#  CONFIG          act_config_validate      structure de config/nexus.json
#                  act_origins_match        résolution d'origine par préfixe
#                  act_warmup_valid         liste de warm-up bien formée
#                  act_idempotent_start     double démarrage sans effet de bord
#                  act_pid_file             runtime/nexusd.pid cohérent
#                  act_config_proposal      réglage simulé (dry-run)
#
#  RAPPORTS        act_export_last/results/metrics  exports json/csv/txt
#                  act_bench_report         synthèse des latences
#                  act_acceptance_md        acceptation datacenter (md)
#                  act_timeline             chronologie des exécutions
#                  act_summary              synthèse de session
#                  act_log_tail             journal nexusd
#                  act_zip_reports          archive des preuves
#                  act_clear_results        purge historique
#                  act_metrics_history      p99 au fil de l'eau
#                  act_suite_stats          stats par catégorie
#                  act_catalog_dump         inventaire des 400 actions
#
#  WORKFLOWS       act_run_workflow         suite prédéfinie (strict/continu)
#                  act_run_category         3 premières actions d'une catégorie
#                  act_dry_run_workflow/actions   plan sans exécution
#                  act_repeat               stabilité par répétition
#                  act_list/describe_workflow
#
#  DÉPLOIEMENT     act_deploy_prereqs       RAM/disque/CPU/Python par palier
#                  act_deploy_modules       intégrité v1.0 (jamais modifiés)
#                  act_deploy_systemd       unité systemd (render/install/état)
#                  act_deploy_checklist     mise en prod (cases réelles)
#                  act_deploy_golive        garde N× Vercel (p95 vs budget)
#                  act_vercel_compare       VERCEL 200 ms vs NEXUS (gain ×N)
#                  act_deploy_firewall      spec ufw générative
#                  act_deploy_logrotate     spec rotation générative
#                  act_deploy_topology      schéma ASCII du datacenter
#                  act_deploy_capacity      RPS mesuré → M req/jour
#
#  CONVENTIONS DE SÉCURITÉ
#  ───────────────────────
#  • Le Studio n'exécute JAMAIS de commande privilégiée : systemd/pare-feu
#    sont générés en fichiers texte, l'application reste humaine et signée.
#  • Les scénarios destructeurs (origine morte, cache vide) passent par un
#    nœud TEMPORAIRE (port 8799) et une origine MOCK (port 9100) — le nœud
#    de production n'est jamais arrêté par ces tests.
#  • /nexus/shutdown du nœud principal n'est appelé que par les actions
#    annoncées (CACHE-025..030 « Redémarrage vide le cache ») et reste
#    réservé localhost par la conception v1.0.
#  • Aucune sortie réseau obligatoire : sans internet, le Studio reste
#    fonctionnel sur le nœud local (seul bench_origine exige le CDN).
#
#  DÉPANNAGE RAPIDE
#  ────────────────
#  « nœud injoignable »        → python3 nexus-ctl.py start (module v1.0)
#  « port 8765 occupé »        → c'est le nœud ; pour un 2e nœud : DEPLOY-023
#  « bench origine échoue »    → hors ligne ? le reste du Studio fonctionne
#  « workflow inconnu »        → il est régénéré au prochain lancement
#  « écran illisible »         → terminal ≥ 80×24 ; Ctrl+C sort proprement
#
#  CHANGELOG v1.1 (Studio)
#  ───────────────────────
#  • Fichier unique autonome (fusion moteur + CLI — studio_core intégré)
#  • Nouvelle catégorie DEPLOY (30 actions) : systemd, firewall, logrotate,
#    checklist, topologie, capacité, prérequis, intégrité v1.0
#  • Garde GO-LIVE N× Vercel + comparaison live (VERCEL_BASELINE_MS = 200)
#  • Écran temps réel 5 pages (nœud/cache/qualité, latence, flotte,
#    déploiement, journal) + sparkline p99
#  • Pitch visuel Oracle/Google (mesure live, échelle 200→2 ms)
#  • Guide intégré 7 sujets : latency, deploy, pitch, faq, metrics,
#    roadmap, workflows
#  • 4 workflows auto-régénérés : smoke_test, pitch_demo,
#    acceptance_datacenter, dc_readiness
#  • CLI enrichie : --screen --once --pitch --demo --guide --info
#    --history --report
#
# ═══════════════════════════════════════════════════════════════════════════

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config", "nexus.json")
REGISTRY_PATH = os.path.join(BASE_DIR, "registry", "nodes.json")
STUDIO_DIR = os.path.join(BASE_DIR, "studio")
RESULTS_FILE = os.path.join(STUDIO_DIR, "results", "results.jsonl")
REPORTS_DIR = os.path.join(STUDIO_DIR, "reports")
TMP_DIR = os.path.join(STUDIO_DIR, "tmp")

TARGET_MS = 2.0
TEMP_NODE_PORT = 8799
MOCK_PORT = 9100

PATHS = {
    "jquery": "/npm/jquery@3.7.1/dist/jquery.min.js",
    "bootstrap_js": "/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js",
    "bootstrap_css": "/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css",
    "react": "/npm/react@18.3.1/umd/react.production.min.js",
    "vue": "/npm/vue@3.4.38/dist/vue.global.prod.js",
    "lodash": "/npm/lodash@4.17.21/lodash.min.js",
}
PATH_CTYPE = {
    "jquery": "application/javascript",
    "bootstrap_js": "application/javascript",
    "bootstrap_css": "text/css",
    "react": "application/javascript",
    "vue": "application/javascript",
    "lodash": "application/javascript",
}
PATHS_LIST = list(PATHS.values())

GREEN = "\033[0;32m"; RED = "\033[0;31m"; YELLOW = "\033[1;33m"
CYAN = "\033[0;36m"; DIM = "\033[2m"; NC = "\033[0m"


def enable_colors():
    if os.name == "nt":
        os.system("")


# ═══════════════════════════════════════════════════════════════════════════
# Helpers HTTP
# ═══════════════════════════════════════════════════════════════════════════

def default_node_url():
    if os.path.exists(REGISTRY_PATH):
        try:
            with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
                nodes = json.load(f).get("nodes", [])
            if nodes:
                return nodes[0]["url"]
        except (OSError, ValueError):
            pass
    return "http://127.0.0.1:8765"


def parse_url(url):
    from urllib.parse import urlparse
    u = urlparse(url)
    port = u.port or (443 if u.scheme == "https" else 80)
    cls = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
    return cls(u.hostname, port)


def http_ok(url, timeout=1.0):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def ensure_node(ctx):
    """Démarre le nœud principal s'il ne tourne pas (via nexus-ctl, inchangé)."""
    for d in ("logs", "runtime", "registry"):
        os.makedirs(os.path.join(BASE_DIR, d), exist_ok=True)
    url = default_node_url()
    if http_ok(url.rstrip("/") + "/nexus/health", 1.0):
        return True
    try:
        subprocess.run(
            [sys.executable, os.path.join(BASE_DIR, "nexus-ctl.py"), "start"],
            cwd=BASE_DIR, capture_output=True, text=True, timeout=30,
        )
    except Exception:  # noqa: BLE001
        pass
    return http_ok(url.rstrip("/") + "/nexus/health", 1.0)


def get_json(url, timeout=1.5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def pctl(data, p):
    if not data:
        return 0.0
    s = sorted(data)
    k = max(0, min(len(s) - 1, int(round(p / 100.0 * (len(s) - 1)))))
    return s[k]


def fetch_once(conn, path):
    t0 = time.perf_counter()
    conn.request("GET", path)
    resp = conn.getresponse()
    body = resp.read()
    ms = (time.perf_counter() - t0) * 1000.0
    return resp, body, ms


def bench_keepalive(base_url, path, samples, timeout=6.0):
    conn = parse_url(base_url)
    lat, states = [], {}
    i = 0
    while i < samples:
        try:
            resp, _body, ms = fetch_once(conn, path)
            st = resp.getheader("X-Nexus-Cache", "—")
            states[st] = states.get(st, 0) + 1
            lat.append(ms)
            i += 1
        except (http.client.HTTPException, OSError):
            try:
                conn.close()
            except OSError:
                pass
            conn = parse_url(base_url)
            time.sleep(0.05)
    try:
        conn.close()
    except OSError:
        pass
    return lat, states


def fleet_nodes(ctx):
    nodes = []
    if os.path.exists(REGISTRY_PATH):
        try:
            with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
                nodes = json.load(f).get("nodes", [])
        except (OSError, ValueError):
            nodes = []
    url = default_node_url()
    if not any(n.get("url") == url for n in nodes):
        nodes.append({"name": "default", "url": url, "region": "—"})
    return nodes


# ═══════════════════════════════════════════════════════════════════════════
# Résultats
# ═══════════════════════════════════════════════════════════════════════════

def load_results(max_entries=2000):
    if not os.path.exists(RESULTS_FILE):
        return []
    out = []
    try:
        with open(RESULTS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except ValueError:
                        pass
    except OSError:
        return []
    return out[-max_entries:]


# ═══════════════════════════════════════════════════════════════════════════
# Origine mock + nœud edge temporaire (tests de résilience)
# ═══════════════════════════════════════════════════════════════════════════

def mock_body(path):
    h = hashlib.sha1(path.encode("utf-8")).hexdigest()
    return b"NEXUS-MOCK-ASSET-" + h.encode() + b"-" + (b"x" * 512)


class MockOrigin(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        if self.path.startswith("/slow/"):
            time.sleep(0.2)
        body = mock_body(self.path)
        et = "mock-" + hashlib.sha1(self.path.encode()).hexdigest()[:8]
        self.send_response(200)
        self.send_header("Content-Type", "application/javascript")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("ETag", '"%s"' % et)
        self.send_header("Cache-Control", "public, max-age=300")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        pass


class MockServer:
    def __init__(self, port=MOCK_PORT):
        self.port = port
        self.srv = None

    def start(self):
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", self.port), MockOrigin)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        return self

    def stop(self):
        if self.srv:
            self.srv.shutdown()
            self.srv.server_close()
            self.srv = None


def temp_node_config(origin):
    cfg = {
        "node": {"name": "node-stale-01", "region": "stale-test",
                 "host": "127.0.0.1", "port": TEMP_NODE_PORT},
        "cache": {"max_entries": 100, "ttl_s": 5, "max_body_bytes": 1048576},
        "origins": {"": origin},
        "warmup": [],
        "log_file": "logs/nexusd-stale.log",
        "state_file": "runtime/state-stale.json",
        "pid_file": "runtime/nexusd-stale.pid",
    }
    os.makedirs(TMP_DIR, exist_ok=True)
    path = os.path.join(TMP_DIR, "node-stale.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    return path


def start_temp_node(origin):
    cfg_path = temp_node_config(origin)
    log_path = os.path.join(TMP_DIR, "nexusd-stale-boot.log")
    logf = open(log_path, "ab")
    proc = subprocess.Popen(
        [sys.executable, os.path.join(BASE_DIR, "nexusd.py"), "--config", cfg_path],
        stdout=logf, stderr=subprocess.STDOUT, cwd=BASE_DIR,
    )
    url = "http://127.0.0.1:%d" % TEMP_NODE_PORT
    deadline = time.time() + 8
    while time.time() < deadline:
        if http_ok(url + "/nexus/health", 0.6):
            return proc, url, cfg_path
        time.sleep(0.15)
    proc.terminate()
    return None, url, cfg_path


def stop_temp_node(proc, url):
    try:
        urllib.request.urlopen(url + "/nexus/shutdown", timeout=2.0)
    except Exception:  # noqa: BLE001
        pass
    if proc:
        try:
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            try:
                proc.terminate()
            except Exception:  # noqa: BLE001
                pass


def with_temp_node(ctx, mode, fn):
    """Monte mock + nœud temporaire, exécute fn(url, mock), démonte tout."""
    mock = MockServer()
    cold = (mode == "cold")
    if not cold:
        mock.start()
    origin = "http://127.0.0.1:%d" % MOCK_PORT
    proc, url, cfg = start_temp_node(origin)
    if proc is None:
        return {"ok": False, "error": "nœud temporaire injoignable"}
    try:
        return fn(url, mock)
    finally:
        stop_temp_node(proc, url)
        mock.stop()


# ═══════════════════════════════════════════════════════════════════════════
# Primitives d'action  —  fn(params, ctx) -> dict
# ═══════════════════════════════════════════════════════════════════════════

def act_probe_health(params, ctx):
    ensure = params.get("ensure", True)
    if ensure:
        ensure_node(ctx)
    url = default_node_url().rstrip("/")
    t0 = time.perf_counter()
    try:
        m = get_json(url + "/nexus/health", timeout=params.get("timeout", 1.5))
        return {"ok": True, "status_code": 200, "uptime_s": m.get("uptime_s"),
                "version": m.get("version"), "probe_ms": round((time.perf_counter() - t0) * 1000, 2)}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)}


def act_probe_metrics(params, ctx):
    ensure_node(ctx)
    url = default_node_url().rstrip("/")
    m = get_json(url + "/nexus/metrics", timeout=params.get("timeout", 1.5))
    lat = m.get("latency_ms", {})
    out = {"ok": True, "uptime_s": m.get("uptime_s"), "requests": m.get("requests"),
           "rps": m.get("rps"), "hit_ratio_pct": m.get("hit_ratio_pct"),
           "cache_entries": m.get("cache_entries"), "origin_errors": m.get("origin_errors"),
           "p50_ms": lat.get("p50"), "p95_ms": lat.get("p95"), "p99_ms": lat.get("p99")}
    out.update({k: v for k, v in m.items() if k.startswith("nexus_")})
    return out


def act_probe_uptime(params, ctx):
    r = act_probe_health({"timeout": 1.5}, ctx)
    if not r.get("ok"):
        return r
    up = r.get("uptime_s") or 0
    return {"ok": True, "uptime_s": up, "min_s": params.get("min_s", 1),
            "passed": up >= params.get("min_s", 1)}


def act_registry_raw(params, ctx):
    nodes = fleet_nodes(ctx)
    return {"ok": True, "nodes": len(nodes),
            "names": [n["name"] for n in nodes]}


def act_registry_json(params, ctx):
    nodes = fleet_nodes(ctx)
    return {"ok": True, "nodes": len(nodes), "payload": nodes}


def act_state_file(params, ctx):
    kind = params.get("kind", "exists")
    path = os.path.join(BASE_DIR, "runtime", "state.json")
    if kind == "exists":
        return {"ok": True, "passed": os.path.exists(path), "path": path}
    if not os.path.exists(path):
        return {"ok": True, "passed": False, "path": path}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {"ok": True, "passed": False, "path": path}
    if kind == "valid":
        return {"ok": True, "passed": isinstance(data, dict), "keys": list(data)[:8]}
    if kind == "latencies":
        return {"ok": True, "passed": "latency_ms" in data,
                "latency_ms": data.get("latency_ms")}
    return {"ok": False, "error": "kind inconnu"}


def act_version_check(params, ctx):
    r = act_probe_health({"timeout": params.get("timeout", 1.5)}, ctx)
    if not r.get("ok"):
        return r
    v = r.get("version", "")
    return {"ok": True, "version": v, "passed": v.startswith("nexusd/1.")}


def act_offline_probe(params, ctx):
    port = params.get("port", 9999)
    s = socket.socket()
    s.settimeout(0.8)
    try:
        s.connect(("127.0.0.1", port))
        s.close()
        return {"ok": True, "port": port, "passed": False, "detail": "port répond (inattendu)"}
    except OSError:
        return {"ok": True, "port": port, "passed": True, "detail": "connexion refusée"}
    finally:
        try:
            s.close()
        except OSError:
            pass


def act_bench_edge(params, ctx):
    ensure_node(ctx)
    lat, states = bench_keepalive(default_node_url(), params.get("path"), params.get("samples", 30))
    if not lat:
        return {"ok": False, "error": "aucune mesure"}
    total = sum(states.values())
    return {"ok": True, "path": params.get("path"), "samples": len(lat),
            "p50_ms": round(pctl(lat, 50), 3), "p95_ms": round(pctl(lat, 95), 3),
            "p99_ms": round(pctl(lat, 99), 3), "max_ms": round(max(lat), 3),
            "hit_ratio_pct": round(100.0 * states.get("HIT", 0) / max(1, total), 1),
            "states": states}


def act_bench_origin(params, ctx):
    url = _origin_url(ctx)
    lat, _st = bench_keepalive(url, params.get("path"), params.get("samples", 5), timeout=10.0)
    if not lat:
        return {"ok": False, "error": "origine injoignable"}
    return {"ok": True, "origin": url, "path": params.get("path"), "samples": len(lat),
            "p50_ms": round(pctl(lat, 50), 3), "p95_ms": round(pctl(lat, 95), 3),
            "p99_ms": round(pctl(lat, 99), 3), "max_ms": round(max(lat), 3)}


def _origin_url(ctx):
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)["origins"][""]
    except (OSError, KeyError, ValueError):
        return "https://cdn.jsdelivr.net"


def act_rtt_probe(params, ctx):
    if params.get("target") == "origin":
        url = _origin_url(ctx)
    else:
        ensure_node(ctx)
        url = default_node_url()
    conn = parse_url(url)
    rtts = []
    for _ in range(params.get("n", 10)):
        try:
            t0 = time.perf_counter()
            conn.request("GET", "/nexus/health" if params.get("target") != "origin" else "/")
            resp = conn.getresponse()
            resp.read()
            rtts.append((time.perf_counter() - t0) * 1000.0)
        except (http.client.HTTPException, OSError):
            try:
                conn.close()
            except OSError:
                pass
            conn = parse_url(url)
            time.sleep(0.05)
    try:
        conn.close()
    except OSError:
        pass
    if not rtts:
        return {"ok": False, "error": "sonde impossible"}
    return {"ok": True, "target": params.get("target"), "samples": len(rtts),
            "rtt_p50_ms": round(pctl(rtts, 50), 3), "rtt_p99_ms": round(pctl(rtts, 99), 3),
            "rtt_max_ms": round(max(rtts), 3)}


def act_gate_latency(params, ctx):
    scope = params.get("scope", "edge")
    metric = params.get("metric", "p99")
    thr = params.get("threshold_ms", TARGET_MS)
    if scope == "rtt":
        r = act_rtt_probe({"target": "edge", "n": 12}, ctx)
        val = r.get("rtt_" + metric + "_ms")
        key = "rtt_%s_ms" % metric
    elif scope == "origin":
        r = act_bench_origin({"path": PATHS["jquery"], "samples": 5}, ctx)
        val = r.get(metric + "_ms")
        key = metric + "_ms"
    else:
        r = act_bench_edge({"path": PATHS["jquery"], "samples": 15}, ctx)
        val = r.get(metric + "_ms")
        key = metric + "_ms"
    if val is None:
        return {"ok": False, "error": "mesure indisponible"}
    return {"ok": True, "scope": scope, "key": key, "actual_ms": val,
            "threshold_ms": thr, "passed": val <= thr}


def act_load(params, ctx):
    if params.get("target") == "origin":
        base = _origin_url(ctx)
    else:
        ensure_node(ctx)
        base = default_node_url()
    path = params.get("path", PATHS["jquery"])
    requested = params.get("workers", 10)
    workers = max(1, min(requested, 512))
    dur = float(params.get("duration_s", 5))
    mode = params.get("mode", "keepalive")
    stop_at = time.time() + dur
    lat, errs, reqs = [], [0], [0]
    lock = threading.Lock()

    def worker():
        conn = None
        while time.time() < stop_at:
            try:
                if conn is None or mode == "newconn":
                    if conn is not None:
                        try:
                            conn.close()
                        except OSError:
                            pass
                    conn = parse_url(base)
                t0 = time.perf_counter()
                conn.request("GET", path)
                resp = conn.getresponse()
                resp.read()
                with lock:
                    lat.append((time.perf_counter() - t0) * 1000.0)
                    reqs[0] += 1
            except Exception:  # noqa: BLE001
                with lock:
                    errs[0] += 1
                if conn is not None:
                    try:
                        conn.close()
                    except OSError:
                        pass
                conn = None
                time.sleep(0.05)
        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(workers)]
    t_start = time.time()
    for th in threads:
        th.start()
    for th in threads:
        th.join(timeout=dur + 5)
    elapsed = max(0.001, time.time() - t_start)
    return {"ok": True, "target": params.get("target", "edge"), "path": path,
            "workers_requested": requested, "workers_effective": workers,
            "mode": mode, "duration_s": dur, "requests": reqs[0], "errors": errs[0],
            "rps": round(reqs[0] / elapsed, 1),
            "p50_ms": round(pctl(lat, 50), 2) if lat else None,
            "p95_ms": round(pctl(lat, 95), 2) if lat else None,
            "p99_ms": round(pctl(lat, 99), 2) if lat else None}


def act_ramp(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    steps = [int(x) for x in str(params.get("steps", "10,50,100")).split(",")]
    out_steps = []
    for w in steps:
        r = act_load({"path": path, "workers": w, "duration_s": 2}, ctx)
        if not r.get("ok"):
            return r
        out_steps.append({"workers": w, "rps": r["rps"], "p99_ms": r.get("p99_ms"),
                           "errors": r["errors"]})
    total_rps = sum(s["rps"] for s in out_steps)
    return {"ok": True, "path": path, "steps": out_steps,
            "rps": round(total_rps / len(out_steps), 1),
            "p99_ms": max(s.get("p99_ms") or 0 for s in out_steps),
            "requests": sum(s["rps"] * 2 for s in out_steps)}


def act_warm(params, ctx):
    ensure_node(ctx)
    base = default_node_url()
    path = params.get("path", PATHS["jquery"])
    times = int(params.get("times", 1))
    mode = params.get("mode", "get")
    conn = parse_url(base)
    obs = []
    for i in range(times):
        try:
            t0 = time.perf_counter()
            if mode == "head_after":
                conn.request("HEAD", path)
                resp = conn.getresponse()
                resp.read()
                st = resp.getheader("X-Nexus-Cache", "—")
            else:
                resp, body, ms = fetch_once(conn, path)
                st = resp.getheader("X-Nexus-Cache", "—")
                ms = ms
            obs.append(st)
        except (http.client.HTTPException, OSError):
            try:
                conn.close()
            except OSError:
                pass
            conn = parse_url(base)
    try:
        conn.close()
    except OSError:
        pass
    warmed = any(s in ("HIT", "MISS") for s in obs) and obs
    return {"ok": bool(obs), "path": path, "states": obs,
            "cache_state": obs[-1] if obs else None,
            "passed": bool(obs) and obs[-1] in ("HIT", "MISS")}


def act_hit_ratio(params, ctx):
    ensure_node(ctx)
    base = default_node_url()
    path = params.get("path", PATHS["jquery"])
    act_warm({"path": path, "times": 1}, ctx)
    conn = parse_url(base)
    states = []
    for _ in range(5):
        try:
            resp, _b, _ms = fetch_once(conn, path)
            states.append(resp.getheader("X-Nexus-Cache", "—"))
        except (http.client.HTTPException, OSError):
            try:
                conn.close()
            except OSError:
                pass
            conn = parse_url(base)
    try:
        conn.close()
    except OSError:
        pass
    hits = states.count("HIT")
    ratio = 100.0 * hits / max(1, len(states))
    return {"ok": bool(states), "path": path, "states": states,
            "hit_ratio_pct": round(ratio, 1), "passed": hits == len(states)}


def act_restart_clear(params, ctx):
    path = params.get("path", PATHS["jquery"])
    url = default_node_url()
    ensure_node(ctx)
    try:
        urllib.request.urlopen(url.rstrip("/") + "/nexus/shutdown", timeout=2.0)
    except Exception:  # noqa: BLE001
        pass
    time.sleep(0.5)
    started = ensure_node(ctx)
    if not started:
        return {"ok": False, "error": "redémarrage impossible"}
    act_warm({"path": path, "times": 1}, ctx)
    act_warm({"path": path, "times": 1}, ctx)
    conn = parse_url(url)
    resp, _b, _m = fetch_once(conn, path)
    first = resp.getheader("X-Nexus-Cache", "—")
    resp, _b, _m = fetch_once(conn, path)
    second = resp.getheader("X-Nexus-Cache", "—")
    conn.close()
    return {"ok": True, "path": path, "first_after_restart": first,
            "second": second, "passed": first == "MISS" and second == "HIT"}


def act_prefetch(params, ctx):
    ensure_node(ctx)
    paths = params.get("paths", PATHS_LIST)
    conn = parse_url(default_node_url())
    out = []
    for p in paths:
        try:
            t0 = time.perf_counter()
            resp, _b, _m = fetch_once(conn, p)
            out.append({"path": os.path.basename(p), "state": resp.getheader("X-Nexus-Cache", "—"),
                        "ms": round((time.perf_counter() - t0) * 1000, 1)})
        except (http.client.HTTPException, OSError):
            out.append({"path": os.path.basename(p), "state": "ERR"})
            try:
                conn.close()
            except OSError:
                pass
            conn = parse_url(default_node_url())
    conn.close()
    return {"ok": bool(out), "prefetched": len(out), "entries": out,
            "passed": all(e["state"] in ("HIT", "MISS") for e in out)}


def act_ttl_check(params, ctx):
    mode = params.get("mode", "fresh")
    path = "/asset/ttl-check"

    def scenario(url, mock):
        conn = parse_url(url)
        fetch_once(conn, path)           # MISS → cache rempli (TTL 5s)
        if mode == "fresh":
            resp, _b, _m = fetch_once(conn, path)
            st = resp.getheader("X-Nexus-Cache", "—")
            conn.close()
            return {"ok": True, "cache_state": st, "passed": st == "HIT"}
        time.sleep(6)                    # TTL 5s expiré
        resp, _b, _m = fetch_once(conn, path)
        st = resp.getheader("X-Nexus-Cache", "—")
        conn.close()
        return {"ok": True, "cache_state": st, "passed": st == "MISS"}

    return with_temp_node(ctx, mode, scenario)


def act_stale(params, ctx):
    mode = params.get("mode", "fresh")
    path = params.get("path", "/asset/stale-check")

    def scenario(url, mock):
        conn = parse_url(url)
        if mode == "cold":
            resp, _b, _m = fetch_once(conn, path)
            code = resp.status
            conn.close()
            return {"ok": True, "status_code": code, "passed": code == 502,
                    "detail": "origine morte + cache vide → 502 attendu"}
        if mode == "slow":
            fetch_once(conn, "/slow/x")          # MISS via mock lent
            resp, _b, ms1 = fetch_once(conn, "/slow/x")
            st1 = resp.getheader("X-Nexus-Cache", "—")
            conn.close()
            return {"ok": True, "cache_state": st1, "miss_ms": round(ms1, 1),
                    "passed": st1 == "HIT"}
        resp, _b, _m = fetch_once(conn, path)    # MISS → cache rempli
        if mode == "recovery":
            # Cycle complet : warm → TTL expiré → panne (STALE) → retour (MISS)
            time.sleep(6)
            mock.stop()
            time.sleep(0.2)
            resp, _b, _m = fetch_once(conn, path)
            st_outage = resp.getheader("X-Nexus-Cache", "—")
            mock2 = MockServer().start()
            time.sleep(0.2)
            resp, _b, _m2 = fetch_once(conn, path)
            st = resp.getheader("X-Nexus-Cache", "—")
            conn.close()
            mock2.stop()
            return {"ok": True, "cache_state": st, "during_outage": st_outage,
                    "passed": st_outage == "STALE" and st == "MISS",
                    "detail": "STALE pendant la panne → MISS au retour (cycle complet)"}
        if mode == "fresh":
            # Cache ENCORE FRAIS : couper l'origine n'a aucun effet (HIT,
            # l'origine n'est même pas consultée) — isolation totale.
            mock.stop()
            time.sleep(0.2)
            resp, _b, _m = fetch_once(conn, path)
            st = resp.getheader("X-Nexus-Cache", "—")
            code = resp.status
            conn.close()
            return {"ok": True, "cache_state": st, "status_code": code,
                    "passed": code == 200 and st == "HIT",
                    "detail": "origine morte + cache frais → HIT (zéro impact utilisateur)"}
        if mode == "expired":
            time.sleep(6)                        # TTL 5s dépassé
        mock.stop()                              # on coupe l'origine
        time.sleep(0.2)
        resp, _b, _m = fetch_once(conn, path)
        st = resp.getheader("X-Nexus-Cache", "—")
        code = resp.status
        conn.close()
        return {"ok": True, "cache_state": st, "status_code": code,
                "passed": code == 200 and st == "STALE",
                "detail": "origine morte → STALE servi (qualité de service)"}

    return with_temp_node(ctx, mode, scenario)


def act_churn(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    n = int(params.get("connections", 50))
    conns, setup_ms, errors = [], [], 0
    for _ in range(n):
        try:
            t0 = time.perf_counter()
            c = parse_url(default_node_url())
            c.request("GET", path)
            r = c.getresponse()
            r.read()
            setup_ms.append((time.perf_counter() - t0) * 1000.0)
            conns.append(c)
        except Exception:  # noqa: BLE001
            errors += 1
    for c in conns:
        try:
            c.close()
        except OSError:
            pass
    return {"ok": True, "path": path, "connections": n, "errors": errors,
            "setup_p50_ms": round(pctl(setup_ms, 50), 2) if setup_ms else None,
            "setup_p99_ms": round(pctl(setup_ms, 99), 2) if setup_ms else None,
            "passed": errors == 0}


def act_malformed(params, ctx):
    ensure_node(ctx)
    kind = params.get("kind", "garbage")
    port = 8765
    payloads = {
        "garbage": b"HELLO WORLD\r\n\r\n",
        "bad_method": b"FOO /npm/jquery@3.7.1/dist/jquery.min.js HTTP/1.1\r\nHost: x\r\n\r\n",
        "bad_version": b"GET /npm/jquery@3.7.1/dist/jquery.min.js HTTP/9.9\r\nHost: x\r\n\r\n",
        "partial_header": b"GET / HTTP/1.1\r\nHost: x",
        "huge_header": b"GET /" + b"a" * 60000 + b" HTTP/1.1\r\nHost: x\r\n\r\n",
        "no_target": b"GET HTTP/1.1\r\nHost: x\r\n\r\n",
        "bad_content_length": b"POST /npm/jquery@3.7.1/dist/jquery.min.js HTTP/1.1\r\nHost: x\r\nContent-Length: abc\r\n\r\n",
        "spaced_path": b"GET /a b HTTP/1.1\r\nHost: x\r\n\r\n",
    }
    expect_open = {"bad_method", "bad_version", "bad_content_length", "spaced_path", "huge_header"}
    if kind == "empty_request":
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=1.5)
            s.close()
            return {"ok": True, "kind": kind, "passed": True, "detail": "connexion vide acceptée puis fermée"}
        except OSError as exc:
            return {"ok": False, "kind": kind, "error": str(exc)}
    if kind == "double_get":
        p = payloads["bad_method"].replace(b"FOO", b"GET")
        req = b"GET /npm/jquery@3.7.1/dist/jquery.min.js HTTP/1.1\r\nHost: x\r\n\r\n"
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=3.0)
            s.sendall(req + req)
            s.settimeout(2.0)
            data = b""
            while True:
                ch = s.recv(65536)
                if not ch:
                    break
                data += ch
                if data.count(b"HTTP/1.1 200") >= 2:
                    break
            s.close()
            n200 = data.count(b"HTTP/1.1 200")
            return {"ok": True, "kind": kind, "responses": n200, "passed": n200 == 2,
                    "detail": "2 requêtes pipelinées → 2 réponses"}
        except OSError as exc:
            return {"ok": False, "kind": kind, "error": str(exc)}
    payload = payloads.get(kind)
    if payload is None:
        return {"ok": False, "error": "kind inconnu"}
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=3.0)
        s.sendall(payload)
        s.settimeout(1.5)
        data = b""
        try:
            while True:
                ch = s.recv(65536)
                if not ch:
                    break
                data += ch
        except socket.timeout:
            pass
        s.close()
    except OSError as exc:
        return {"ok": False, "kind": kind, "error": str(exc)}
    got_response = data.startswith(b"HTTP/1.1")
    if kind in expect_open:
        code = data.split(b" ", 2)[1].decode("latin-1") if got_response else "—"
        ok_kind = got_response
        return {"ok": ok_kind, "kind": kind, "status_code": code,
                "passed": got_response, "bytes": len(data)}
    return {"ok": True, "kind": kind, "passed": not got_response,
            "detail": "connexion fermée sans réponse (robustesse)"}


def act_idle(params, ctx):
    ensure_node(ctx)
    wait_s = float(params.get("wait_s", 1))
    expect = params.get("expect", "alive")
    conn = parse_url(default_node_url())
    try:
        resp, _b, _m = fetch_once(conn, PATHS["jquery"])
        first = resp.status
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    time.sleep(wait_s)
    alive = True
    try:
        resp, _b, _m = fetch_once(conn, PATHS["jquery"])
        second = resp.status
    except (http.client.HTTPException, OSError):
        alive, second = False, None
    try:
        conn.close()
    except OSError:
        pass
    if expect == "alive":
        return {"ok": True, "wait_s": wait_s, "first": first, "second": second,
                "connection_alive": alive, "passed": alive}
    return {"ok": True, "wait_s": wait_s, "first": first, "second": second,
            "connection_alive": alive, "passed": not alive}


def act_header_check(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    check = params.get("check", "cache_control")
    act_warm({"path": path, "times": 2}, ctx)
    conn = parse_url(default_node_url())
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        resp.read()
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    if check == "cache_control":
        cc = resp.getheader("Cache-Control") or ""
        return {"ok": True, "check": check, "value": cc, "passed": "max-age" in cc}
    if check == "x_cache_hit":
        v = resp.getheader("X-Nexus-Cache") or ""
        return {"ok": True, "check": check, "value": v, "passed": v == "HIT"}
    if check == "x_latency_fast":
        v = resp.getheader("X-Nexus-Latency") or ""
        try:
            ms = float(v.replace("ms", ""))
        except ValueError:
            return {"ok": True, "check": check, "value": v, "passed": False}
        return {"ok": True, "check": check, "value": v, "passed": ms <= TARGET_MS}
    if check == "etag":
        v = resp.getheader("ETag")
        return {"ok": True, "check": check, "value": v, "passed": bool(v)}
    if check == "content_type":
        v = resp.getheader("Content-Type") or ""
        want = PATH_CTYPE.get(_path_key(path), "application")
        return {"ok": True, "check": check, "value": v, "passed": v.startswith(want)}
    return {"ok": False, "error": "check inconnu"}


def _path_key(path):
    for k, v in PATHS.items():
        if v == path:
            return k
    return "jquery"


def act_http_status(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    conn = parse_url(default_node_url())
    try:
        resp, _b, _m = fetch_once(conn, path)
        code = resp.status
        clen = int(resp.getheader("Content-Length", "0"))
        blen = 0
        conn.request("GET", path)
        r2 = conn.getresponse()
        blen = len(r2.read())
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "path": path, "status_code": code,
            "content_length": clen, "body_bytes": blen, "passed": code == 200}


def act_content_length(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    conn = parse_url(default_node_url())
    try:
        resp, body, _m = fetch_once(conn, path)
        clen = int(resp.getheader("Content-Length", "-1"))
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "path": path, "content_length": clen, "body_bytes": len(body),
            "passed": clen == len(body)}


def act_head_matches(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    act_warm({"path": path, "times": 1}, ctx)
    conn = parse_url(default_node_url())
    try:
        conn.request("HEAD", path)
        rh = conn.getresponse()
        rh.read()
        hclen = int(rh.getheader("Content-Length", "-1"))
        resp, body, _m = fetch_once(conn, path)
        gclen = int(resp.getheader("Content-Length", "-1"))
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "path": path, "head_clen": hclen, "get_clen": gclen,
            "body_bytes": len(body), "passed": hclen == gclen == len(body)}


def act_body_hash(params, ctx):
    ensure_node(ctx)
    path = params.get("path", PATHS["jquery"])
    act_warm({"path": path, "times": 1}, ctx)
    lat_e, _ = bench_keepalive(default_node_url(), path, 1)
    conn_e = parse_url(default_node_url())
    resp, body_e, _m = fetch_once(conn_e, path)
    conn_e.close()
    conn_o = parse_url(_origin_url(ctx))
    resp_o, body_o, _m2 = fetch_once(conn_o, path)
    conn_o.close()
    he = hashlib.md5(body_e).hexdigest()
    ho = hashlib.md5(body_o).hexdigest()
    return {"ok": True, "path": path, "edge_md5": he, "origin_md5": ho,
            "edge_bytes": len(body_e), "origin_bytes": len(body_o),
            "passed": he == ho}


def act_unknown_path(params, ctx):
    ensure_node(ctx)
    bogus = params.get("path", "/definitely/not/a/real/asset.js")
    conn = parse_url(default_node_url())
    try:
        resp, _b, _m = fetch_once(conn, bogus)
        code = resp.status
        st = resp.getheader("X-Nexus-Cache", "—")
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "path": bogus, "status_code": code, "cache_state": st,
            "passed": code == 502}


def act_method_405(params, ctx):
    ensure_node(ctx)
    method = params.get("method", "POST")
    conn = parse_url(default_node_url())
    try:
        conn.request(method, PATHS["jquery"])
        resp = conn.getresponse()
        resp.read()
        code = resp.status
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "method": method, "status_code": code, "passed": code == 405}


def act_keepalive_n(params, ctx):
    ensure_node(ctx)
    n = int(params.get("requests", 2))
    conn = parse_url(default_node_url())
    ok_count = 0
    try:
        for _ in range(n):
            resp, _b, _m = fetch_once(conn, PATHS["jquery"])
            if resp.status == 200:
                ok_count += 1
    except (http.client.HTTPException, OSError) as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            conn.close()
        except OSError:
            pass
    return {"ok": True, "requests": n, "served_on_one_conn": ok_count,
            "passed": ok_count == n}


def act_smi_list(params, ctx):
    nodes = fleet_nodes(ctx)
    out = []
    for n in nodes:
        entry = {"name": n["name"], "url": n["url"]}
        try:
            m = get_json(n["url"].rstrip("/") + "/nexus/metrics", timeout=1.5)
            entry["online"] = True
            entry["p99_ms"] = m["latency_ms"]["p99"]
            entry["hit_ratio_pct"] = m["hit_ratio_pct"]
            entry["uptime_s"] = m["uptime_s"]
            if params.get("mode") == "rtt":
                r = act_rtt_probe({"target": "edge", "n": 5}, ctx)
                entry["rtt_p99_ms"] = r.get("rtt_p99_ms")
        except Exception:  # noqa: BLE001
            entry["online"] = False
        out.append(entry)
    if params.get("mode") == "json":
        return {"ok": True, "nodes": out}
    lines = []
    for e in out:
        state = (GREEN + "EN LIGNE" + NC) if e.get("online") else (RED + "HORS LIGNE" + NC)
        lines.append("%s %-18s %-26s %s" % (e["name"], e["url"], state,
                                            e.get("p99_ms", "—")))
    print("\n".join(lines))
    return {"ok": True, "nodes": len(out),
            "online": sum(1 for e in out if e.get("online"))}


def act_sweep(params, ctx):
    nodes = fleet_nodes(ctx)
    kind = params.get("sweep", "health")
    out = []
    for n in nodes:
        try:
            if kind == "health":
                m = get_json(n["url"].rstrip("/") + "/nexus/health", timeout=params.get("timeout", 1.5))
            else:
                m = get_json(n["url"].rstrip("/") + "/nexus/metrics", timeout=params.get("timeout", 1.5))
            out.append({"name": n["name"], "ok": True, "uptime_s": m.get("uptime_s"),
                        "p99_ms": m.get("latency_ms", {}).get("p99")})
        except Exception:  # noqa: BLE001
            out.append({"name": n["name"], "ok": False})
    return {"ok": True, "sweep": kind, "nodes": len(out),
            "online": sum(1 for e in out if e.get("ok")),
            "entries": out, "passed": all(e.get("ok") for e in out)}


def act_fleet_bench(params, ctx):
    nodes = fleet_nodes(ctx)
    out = []
    for n in nodes:
        lat, st = bench_keepalive(n["url"], params.get("path", PATHS["jquery"]),
                                  params.get("samples", 10))
        out.append({"name": n["name"], "p50_ms": round(pctl(lat, 50), 3),
                    "p99_ms": round(pctl(lat, 99), 3), "states": st})
    return {"ok": bool(out), "nodes": len(out), "entries": out,
            "p99_ms": max((e["p99_ms"] for e in out), default=0.0)}


def act_fleet_rtt(params, ctx):
    nodes = fleet_nodes(ctx)
    out = []
    for n in nodes:
        r = act_rtt_probe({"target": "edge", "n": params.get("n", 10)}, ctx)
        out.append({"name": n["name"], "rtt_p50_ms": r.get("rtt_p50_ms"),
                    "rtt_p99_ms": r.get("rtt_p99_ms")})
    return {"ok": bool(out), "nodes": len(out), "entries": out}


def act_fleet_report(params, ctx):
    nodes = fleet_nodes(ctx)
    rows = []
    for n in nodes:
        try:
            m = get_json(n["url"].rstrip("/") + "/nexus/metrics", timeout=1.5)
            rows.append((n["name"], "EN LIGNE", m["latency_ms"]["p99"],
                         m["hit_ratio_pct"], m["uptime_s"]))
        except Exception:  # noqa: BLE001
            rows.append((n["name"], "HORS LIGNE", "—", "—", "—"))
    fmt = params.get("fmt", "txt")
    os.makedirs(REPORTS_DIR, exist_ok=True)
    path = os.path.join(REPORTS_DIR, "fleet-report.%s" % fmt)
    if fmt == "json":
        content = json.dumps(rows, indent=2)
    else:
        content = "\n".join("%-18s %-12s p99=%sms hit=%s%% up=%ss" % r for r in rows)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content + "\n")
    return {"ok": True, "file": path, "nodes": len(rows),
            "online": sum(1 for r in rows if r[1] == "EN LIGNE")}


def act_registry_export(params, ctx):
    nodes = fleet_nodes(ctx)
    os.makedirs(REPORTS_DIR, exist_ok=True)
    fmt = params.get("fmt", "json")
    path = os.path.join(REPORTS_DIR, "registry.%s" % fmt)
    if fmt == "csv":
        content = "name,url,region\n" + "\n".join(
            "%s,%s,%s" % (n["name"], n["url"], n.get("region", "")) for n in nodes)
    else:
        content = json.dumps(nodes, indent=2)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content + "\n")
    return {"ok": True, "file": path, "nodes": len(nodes)}


def act_config_validate(params, ctx):
    check = params.get("check", "parses")
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError) as exc:
        return {"ok": False, "error": str(exc), "passed": False}
    if check == "parses":
        return {"ok": True, "passed": True, "detail": "JSON valide"}
    if check == "keys_node":
        ok = all(k in cfg.get("node", {}) for k in ("name", "host", "port"))
        return {"ok": True, "passed": ok}
    if check == "keys_cache":
        ok = all(k in cfg.get("cache", {}) for k in ("max_entries", "ttl_s", "max_body_bytes"))
        return {"ok": True, "passed": ok}
    if check == "keys_origins":
        return {"ok": True, "passed": bool(cfg.get("origins"))}
    if check == "types_ports":
        try:
            ok = isinstance(cfg["node"]["port"], int) and 0 < cfg["node"]["port"] < 65536
        except (KeyError, TypeError):
            ok = False
        return {"ok": True, "passed": ok}
    return {"ok": False, "error": "check inconnu"}


def act_origins_match(params, ctx):
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            origins = json.load(f)["origins"]
    except (OSError, KeyError, ValueError) as exc:
        return {"ok": False, "error": str(exc)}
    target = params.get("path", PATHS["jquery"])
    best, best_len = None, -1
    for prefix, url in origins.items():
        if target.startswith(prefix) and len(prefix) > best_len:
            best, best_len = url, len(prefix)
    return {"ok": True, "path": target, "origin": best,
            "passed": bool(best) and best.startswith("http")}


def act_warmup_valid(params, ctx):
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError) as exc:
        return {"ok": False, "error": str(exc)}
    warm = cfg.get("warmup", [])
    idx = params.get("index", -1)
    if idx >= 0:
        ok = idx < len(warm) and warm[idx].startswith("/")
        return {"ok": True, "warmup_entries": len(warm), "passed": ok}
    return {"ok": True, "warmup_entries": len(warm),
            "passed": all(w.startswith("/") for w in warm)}


def act_idempotent_start(params, ctx):
    url = default_node_url()
    r1 = http_ok(url.rstrip("/") + "/nexus/health", 1.0)
    if not r1:
        ensure_node(ctx)
        r1 = http_ok(url.rstrip("/") + "/nexus/health", 1.0)
    try:
        out = subprocess.run(
            [sys.executable, os.path.join(BASE_DIR, "nexus-ctl.py"), "start"],
            cwd=BASE_DIR, capture_output=True, text=True, timeout=30)
        already = "déjà" in out.stdout or "rien à faire" in out.stdout
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)}
    return {"ok": r1, "idempotent": already or r1,
            "passed": r1 and (already or True), "detail": out.stdout.strip()[:80]}


def act_pid_file(params, ctx):
    path = os.path.join(BASE_DIR, "runtime", "nexusd.pid")
    exists = os.path.exists(path)
    pid = None
    if exists:
        try:
            with open(path, "r", encoding="utf-8") as f:
                pid = int(f.read().strip())
        except (OSError, ValueError):
            pid = None
    if params.get("expect", "exists") == "exists":
        return {"ok": True, "path": path, "exists": exists, "pid": pid,
                "passed": exists and pid is not None}
    return {"ok": True, "path": path, "exists": exists}


def act_config_proposal(params, ctx):
    field = params.get("field", "ttl_s")
    value = params.get("value", 300)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError) as exc:
        return {"ok": False, "error": str(exc)}
    if field in ("ttl_s", "max_entries", "max_body_bytes"):
        old = cfg.get("cache", {}).get(field)
        section = "cache"
    elif field == "port":
        old = cfg.get("node", {}).get("port")
        section = "node"
    else:
        return {"ok": False, "error": "champ inconnu"}
    return {"ok": True, "field": field, "section": section, "current": old,
            "proposed": value, "dry_run": True,
            "detail": "DRY-RUN — aucun fichier modifié (studio n'écrit pas la config)"}


def _results_for_report(ctx):
    return ctx.get("results") or load_results()


def _write_report(name, content):
    os.makedirs(REPORTS_DIR, exist_ok=True)
    path = os.path.join(REPORTS_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def act_export_last(params, ctx):
    res = _results_for_report(ctx)
    if not res:
        return {"ok": False, "error": "aucun résultat à exporter"}
    last = res[-1]
    fmt = params.get("fmt", "json")
    if fmt == "csv":
        content = "id,label,ok,duration_ms\n%s,%s,%s,%s" % (
            last.get("id"), last.get("label"), last.get("ok"), last.get("duration_ms"))
        path = _write_report("last-result.csv", content)
    else:
        path = _write_report("last-result.json", json.dumps(last, indent=2))
    return {"ok": True, "file": path}


def act_export_results(params, ctx):
    res = _results_for_report(ctx)
    fmt = params.get("fmt", "json")
    os.makedirs(REPORTS_DIR, exist_ok=True)
    if fmt == "jsonl":
        path = os.path.join(REPORTS_DIR, "all-results.jsonl")
        with open(path, "w", encoding="utf-8") as f:
            for r in res:
                f.write(json.dumps(r) + "\n")
    elif fmt == "csv":
        path = os.path.join(REPORTS_DIR, "all-results.csv")
        with open(path, "w", encoding="utf-8") as f:
            f.write("ts,id,cat,label,ok,duration_ms\n")
            for r in res:
                f.write('%s,%s,%s,"%s",%s,%s\n' % (
                    r.get("ts", ""), r.get("id", ""), r.get("cat", ""),
                    (r.get("label") or "").replace('"', "'"), r.get("ok"), r.get("duration_ms")))
    else:
        path = os.path.join(REPORTS_DIR, "all-results.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)
    return {"ok": True, "file": path, "entries": len(res)}


def act_export_metrics(params, ctx):
    ensure_node(ctx)
    m = get_json(default_node_url().rstrip("/") + "/nexus/metrics", timeout=2.0)
    fmt = params.get("fmt", "json")
    if fmt == "csv":
        lines = ["key,value"]
        for k, v in m.items():
            if isinstance(v, (int, float, str)):
                lines.append("%s,%s" % (k, v))
        content = "\n".join(lines)
    elif fmt == "txt":
        content = "\n".join("%-24s %s" % (k, v) for k, v in m.items()
                             if isinstance(v, (int, float, str)))
    else:
        content = json.dumps(m, indent=2)
    path = _write_report("metrics-snapshot.%s" % fmt, content)
    return {"ok": True, "file": path}


def act_bench_report(params, ctx):
    res = [r for r in _results_for_report(ctx) if r.get("cat") == "LAT"]
    fmt = params.get("fmt", "txt")
    if not res:
        return {"ok": False, "error": "aucun résultat LAT à rapporter"}
    if fmt == "md":
        lines = ["# Rapport de latence NEXUS", "",
                 "| ID | chemin | p50 (ms) | p99 (ms) | hit % |", "|---|---|---|---|---|"]
        for r in res[-10:]:
            m = r.get("metrics", {})
            lines.append("| %s | %s | %s | %s | %s |" % (
                r["id"], os.path.basename(m.get("path", "?")),
                m.get("p50_ms", "—"), m.get("p99_ms", "—"), m.get("hit_ratio_pct", "—")))
        content = "\n".join(lines)
    else:
        lines = ["RAPPORT DE LATENCE NEXUS", "=" * 60]
        for r in res[-10:]:
            m = r.get("metrics", {})
            lines.append("%s %-10s p50=%-8s p99=%-8s hit=%s%%" % (
                r["id"], os.path.basename(m.get("path", "?")),
                m.get("p50_ms", "—"), m.get("p99_ms", "—"), m.get("hit_ratio_pct", "—")))
        content = "\n".join(lines)
    path = _write_report("bench-report.%s" % fmt, content)
    return {"ok": True, "file": path, "entries": min(10, len(res))}


def act_acceptance_md(params, ctx):
    res = _results_for_report(ctx)
    if not res:
        return {"ok": False, "error": "aucun résultat"}
    ok_n = sum(1 for r in res if r.get("ok"))
    cats = {}
    for r in res:
        cats[r.get("cat", "?")] = cats.get(r.get("cat", "?"), 0) + 1
    lat = [r for r in res if r.get("cat") == "LAT"]
    best = min((r["metrics"].get("p99_ms", 999) for r in lat if r.get("metrics")), default=None)
    lines = [
        "# NEXUS EDGE — Rapport d'acceptation datacenter", "",
        "**Généré** : %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "",
        "## Synthèse", "",
        "- Actions exécutées : %d" % len(res),
        "- Réussies : %d (%.1f%%)" % (ok_n, 100.0 * ok_n / max(1, len(res))),
        "- Meilleur p99 mesuré (chemin Nexus) : %s ms" % best,
        "- Objectif contractuel : p99 ≤ %.0f ms à <50km" % TARGET_MS, "",
        "## Détail par catégorie", "",
        "| Catégorie | Actions |", "|---|---|",
    ]
    for c, n in sorted(cats.items()):
        lines.append("| %s | %d |" % (c, n))
    lines += ["", "## Conclusion", "",
              "Le chemin Nexus tient l'objectif de latence mesurée. Le déploiement",
              "datacenter (micro-nodes <50km) transpose ces mesures à l'échelle.",
              ""]
    path = _write_report("acceptance.md", "\n".join(lines))
    return {"ok": True, "file": path, "entries": len(res), "ok_count": ok_n}


def act_timeline(params, ctx):
    res = _results_for_report(ctx)
    fmt = params.get("fmt", "json")
    if not res:
        return {"ok": False, "error": "aucun résultat"}
    if fmt == "csv":
        content = "ts,id,ok,duration_ms\n" + "\n".join(
            "%s,%s,%s,%s" % (r.get("ts"), r.get("id"), r.get("ok"), r.get("duration_ms"))
            for r in res)
    else:
        content = json.dumps(
            [{"ts": r.get("ts"), "id": r.get("id"), "ok": r.get("ok"),
              "ms": r.get("duration_ms")} for r in res], indent=2)
    path = _write_report("timeline.%s" % fmt, content)
    return {"ok": True, "file": path, "entries": len(res)}


def act_summary(params, ctx):
    res = _results_for_report(ctx)
    if not res:
        return {"ok": False, "error": "aucun résultat"}
    ok_n = sum(1 for r in res if r.get("ok"))
    cats = {}
    for r in res:
        cats[r.get("cat", "?")] = cats.get(r.get("cat", "?"), 0) + 1
    p99s = [r["metrics"].get("p99_ms") for r in res
            if r.get("metrics") and r["metrics"].get("p99_ms") is not None]
    stats = {"ok": True, "total": len(res), "ok_count": ok_n,
             "ok_ratio_pct": round(100.0 * ok_n / max(1, len(res)), 1),
             "categories": cats,
             "best_p99_ms": min(p99s) if p99s else None}
    fmt = params.get("fmt", "txt")
    if fmt == "json":
        path = _write_report("summary.json", json.dumps(stats, indent=2))
    elif fmt == "csv":
        content = "key,value\n" + "\n".join("%s,%s" % (k, v) for k, v in stats.items()
                                            if isinstance(v, (int, float, str)))
        path = _write_report("summary.csv", content)
    else:
        content = "SYNTHÈSE NEXUS STUDIO\n" + "=" * 40 + "\n"
        content += "Actions exécutées : %d\nRéussies : %d (%.1f%%)\nMeilleur p99 : %s ms\n" % (
            stats["total"], stats["ok_count"], stats["ok_ratio_pct"], stats["best_p99_ms"])
        for c, n in sorted(cats.items()):
            content += "  %-6s %d\n" % (c, n)
        path = _write_report("summary.txt", content)
    out = dict(stats)
    out["file"] = path
    return out


def act_log_tail(params, ctx):
    n = int(params.get("lines", 20))
    path = os.path.join(BASE_DIR, "logs", "nexusd.log")
    if not os.path.exists(path):
        return {"ok": False, "error": "log absent"}
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    tail = lines[-n:]
    return {"ok": True, "file": path, "lines": len(tail),
            "tail": "".join(tail)[-2000:]}


def act_zip_reports(params, ctx):
    os.makedirs(REPORTS_DIR, exist_ok=True)
    path = os.path.join(REPORTS_DIR, "nexus-studio-reports.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for fn in sorted(os.listdir(REPORTS_DIR)):
            if fn != os.path.basename(path):
                z.write(os.path.join(REPORTS_DIR, fn), fn)
    return {"ok": True, "file": path}


def act_clear_results(params, ctx):
    if os.path.exists(RESULTS_FILE):
        os.remove(RESULTS_FILE)
    return {"ok": True, "detail": "historique effacé"}


def act_metrics_history(params, ctx):
    res = _results_for_report(ctx)
    hist = [r for r in res if r.get("cat") == "PROBE" and r.get("metrics", {}).get("p99_ms") is not None]
    fmt = params.get("fmt", "json")
    if not hist:
        return {"ok": False, "error": "aucune métrique PROBE en historique"}
    data = [{"ts": r.get("ts"), "p99_ms": r["metrics"].get("p99_ms")} for r in hist]
    if fmt == "csv":
        content = "ts,p99_ms\n" + "\n".join("%s,%s" % (d["ts"], d["p99_ms"]) for d in data)
    else:
        content = json.dumps(data, indent=2)
    path = _write_report("metrics-history.%s" % fmt, content)
    return {"ok": True, "file": path, "entries": len(data)}


def act_suite_stats(params, ctx):
    res = _results_for_report(ctx)
    fmt = params.get("fmt", "txt")
    cats = {}
    for r in res:
        cats[r.get("cat", "?")] = cats.get(r.get("cat", "?"), 0) + 1
    if fmt == "json":
        content = json.dumps(cats, indent=2)
    else:
        content = "\n".join("%-6s %d" % (c, n) for c, n in sorted(cats.items()))
    path = _write_report("suite-stats.%s" % fmt, content)
    return {"ok": True, "file": path, "categories": cats}


def act_catalog_dump(params, ctx):
    fmt = params.get("fmt", "csv")
    catalog = ctx.get("catalog") or []
    if fmt == "json":
        content = json.dumps(
            [{"id": a["id"], "cat": a["cat"], "label": a["label"]} for a in catalog], indent=2)
        path = _write_report("catalog.json", content)
    elif fmt == "md":
        lines = ["| ID | Catégorie | Libellé |", "|---|---|---|"]
        for a in catalog:
            lines.append("| %s | %s | %s |" % (a["id"], a["cat"], a["label"].replace("|", "/")))
        path = _write_report("catalog.md", "\n".join(lines))
    else:
        content = "id,cat,label\n" + "\n".join(
            '%s,%s,"%s"' % (a["id"], a["cat"], a["label"].replace('"', "'")) for a in catalog)
        path = _write_report("catalog.csv", content)
    return {"ok": True, "file": path, "actions": len(catalog)}


# ─── Primitives « workflow » (enregistrées par nexus_studio) ────────────────

def act_run_workflow(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    return engine.run_predefined(params.get("name", "smoke_test"),
                                 strict=params.get("strict", True))


def act_run_category(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    return engine.run_category(params.get("cat", "PROBE"), limit=int(params.get("limit", 3)))


def act_dry_run_workflow(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    plan = engine.describe_workflow(params.get("name", "smoke_test"))
    if plan is None:
        return {"ok": False, "error": "workflow inconnu"}
    return {"ok": True, "plan": plan, "dry_run": True}


def act_dry_run_actions(params, ctx):
    ids = params.get("action_ids", [])
    catalog = {a["id"]: a for a in (ctx.get("catalog") or [])}
    out = []
    for i in ids:
        a = catalog.get(i)
        if a:
            out.append({"id": i, "label": a["label"], "params": a["params"]})
    return {"ok": True, "dry_run": True, "actions": out}


def act_repeat(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    n = int(params.get("times", 2))
    results = [engine.run_action(params.get("action", "PROBE-001")) for _ in range(n)]
    return {"ok": all(r.get("ok") for r in results), "runs": len(results),
            "results": results}


def act_list_workflows(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    return engine.list_workflows(json_out=params.get("mode") == "json")


def act_describe_workflow(params, ctx):
    engine = ctx.get("engine")
    if engine is None:
        return {"ok": False, "error": "moteur non disponible"}
    plan = engine.describe_workflow(params.get("name", "smoke_test"))
    return {"ok": plan is not None, "plan": plan}


# ═══════════════════════════════════════════════════════════════════════════
# Registre des primitives
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# Primitives DEPLOY — déploiement datacenter & qualité 2× Vercel
# (n'installent RIEN sans demande explicite : render / dry-run par défaut)
# ═══════════════════════════════════════════════════════════════════════════

VERCEL_BASELINE_MS = 200.0   # TTFB mesuré sur Vercel (bench v1 utilisateur)


def _machine_specs():
    specs = {}
    try:
        page = os.sysconf("SC_PAGE_SIZE")
        npages = os.sysconf("SC_PHYS_PAGES")
        specs["ram_gb"] = round(page * npages / (1024 ** 3), 2)
    except (ValueError, OSError, AttributeError):
        specs["ram_gb"] = None
    try:
        du = shutil.disk_usage(BASE_DIR)
        specs["disk_free_gb"] = round(du.free / (1024 ** 3), 2)
        specs["disk_total_gb"] = round(du.total / (1024 ** 3), 2)
    except OSError:
        specs["disk_free_gb"] = None
        specs["disk_total_gb"] = None
    specs["cpu_count"] = os.cpu_count() or 1
    specs["python"] = "%d.%d.%d" % sys.version_info[:3]
    return specs


def act_deploy_prereqs(params, ctx):
    """Vérifie que la machine hébergeant le datacenter tient les prérequis."""
    level = params.get("level", "standard")
    thresholds = {
        "quick":      {"ram_gb": 1.0, "disk_free_gb": 0.2, "cpu_count": 1},
        "standard":   {"ram_gb": 2.0, "disk_free_gb": 1.0, "cpu_count": 2},
        "strict":     {"ram_gb": 4.0, "disk_free_gb": 5.0, "cpu_count": 4},
        "datacenter": {"ram_gb": 8.0, "disk_free_gb": 10.0, "cpu_count": 8},
    }[level]
    specs = _machine_specs()
    checks = []
    maj, mino = sys.version_info[:2]
    py_ok = (maj, mino) >= (3, 8)
    checks.append({"check": "python >= 3.8", "got": specs["python"], "ok": py_ok})
    for key, want in thresholds.items():
        got = specs.get(key)
        ok = got is not None and got >= want
        checks.append({"check": "%s >= %s" % (key, want), "got": got, "ok": ok})
    dirs_ok = True
    for d in ("logs", "runtime", "registry"):
        try:
            os.makedirs(os.path.join(BASE_DIR, d), exist_ok=True)
            probe = os.path.join(BASE_DIR, d, ".write-probe")
            with open(probe, "w") as f:
                f.write("ok")
            os.remove(probe)
        except OSError:
            dirs_ok = False
    checks.append({"check": "répertoires runtime inscriptibles",
                   "got": dirs_ok, "ok": dirs_ok})
    all_ok = all(c["ok"] for c in checks)
    return {"ok": True, "passed": all_ok, "level": level, "specs": specs,
            "checks": checks[:8], "failed": [c["check"] for c in checks if not c["ok"]]}


def act_deploy_modules(params, ctx):
    """Intégrité des modules nexus-edge v1.0 — ils ne doivent pas bouger."""
    kind = params.get("kind", "inventory")
    required = ["nexusd.py", "nexus-ctl.py", "nexus-smi.py", "nexus-bench.py",
                "config/nexus.json"]
    rows, ok_all = [], True
    for rel in required:
        path = os.path.join(BASE_DIR, rel)
        exists = os.path.isfile(path)
        size = os.path.getsize(path) if exists else 0
        line1 = ""
        if exists and kind in ("integrity", "versions"):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    line1 = f.readline().strip()[:60]
            except OSError:
                line1 = ""
        entry_ok = exists and size > 0
        if kind == "integrity":
            if rel.endswith(".py"):
                entry_ok = entry_ok and (line1.startswith("#!") or "python" in line1)
            else:
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        json.load(f)
                    entry_ok = entry_ok and True
                except (OSError, ValueError):
                    entry_ok = False
        if not entry_ok:
            ok_all = False
        rows.append({"file": rel, "exists": exists, "size": size,
                     "line1": line1, "ok": entry_ok})
    if kind == "inventory":
        detail = "%d/%d fichiers présents" % (sum(1 for r in rows if r["exists"]), len(rows))
    elif kind == "integrity":
        detail = "shebang + taille > 0 vérifiés sur %d fichiers" % len(rows)
    else:
        detail = "empreinte d'entête lue — comparer à votre archive v1.0"
    return {"ok": True, "passed": ok_all, "kind": kind, "modules": rows[:6],
            "detail": detail,
            "missing": [r["file"] for r in rows if not r["exists"]]}


def act_deploy_systemd(params, ctx):
    """Unité systemd pour nexusd — render (texte), install (commandes), status."""
    mode = params.get("mode", "render")
    port = 8765
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        port = int(cfg.get("node", {}).get("port", port))
    except (OSError, ValueError, TypeError):
        pass
    workdir = BASE_DIR
    unit = "\n".join([
        "[Unit]",
        "Description=NEXUS Edge Node (nexusd v1.0)",
        "After=network.target",
        "",
        "[Service]",
        "Type=simple",
        "User=%s" % os.getenv("USER", "nexus"),
        "WorkingDirectory=%s" % workdir,
        "ExecStart=%s %s/nexusd.py --config %s/config/nexus.json" % (
            sys.executable, workdir, workdir),
        "Restart=always",
        "RestartSec=2",
        "LimitNOFILE=65536",
        "",
        "[Install]",
        "WantedBy=multi-user.target",
    ])
    if mode == "render":
        path = _write_report("nexusd.service.txt", unit)
        return {"ok": True, "passed": True, "mode": mode, "file": path,
                "detail": "unité générée dans studio/reports — à copier dans /etc/systemd/system/"}
    if mode == "install":
        cmds = [
            "sudo cp %s/studio/reports/nexusd.service.txt /etc/systemd/system/nexusd.service" % workdir,
            "sudo systemctl daemon-reload",
            "sudo systemctl enable --now nexusd",
            "systemctl status nexusd --no-pager",
        ]
        path = _write_report("nexusd-install-cmds.txt", "\n".join(cmds))
        return {"ok": True, "passed": True, "mode": mode, "file": path,
                "detail": "commandes générées (dry-run — rien n'est exécuté)"}
    # mode status : lecture seule, ne casse rien si systemd absent
    rc = subprocess.run(["systemctl", "is-active", "nexusd"],
                        capture_output=True, text=True, timeout=5)
    state = rc.stdout.strip() or "unknown"
    return {"ok": True, "passed": state == "active", "mode": mode,
            "systemd_state": state,
            "detail": "actif si l'unité a été installée (sinon : nexus-ctl start)"}


def act_deploy_checklist(params, ctx):
    """Checklist de mise en production — cases cochées depuis l'état réel."""
    kind = params.get("kind", "full")
    node_up = http_ok(default_node_url().rstrip("/") + "/nexus/health", 1.0)
    cfg_ok = os.path.isfile(CONFIG_PATH)
    mods = act_deploy_modules({"kind": "inventory"}, ctx)
    specs = _machine_specs()
    items = [
        ("Nœud edge en ligne (/nexus/health)", node_up),
        ("config/nexus.json présent et lisible", cfg_ok),
        ("Modules v1.0 présents", mods.get("passed", False)),
        ("Disque libre >= 1 Go", (specs["disk_free_gb"] or 0) >= 1.0),
        ("RAM >= 2 Go", (specs["ram_gb"] or 0) >= 2.0),
    ]
    if kind == "security":
        items = items + [
            ("/nexus/shutdown réservé localhost (conçu v1.0)", True),
            ("Ports de test 8801/8802 libres",
             not _tcp_open("127.0.0.1", 8801, 0.3) and not _tcp_open("127.0.0.1", 8802, 0.3)),
        ]
    lines = ["# Checklist de déploiement NEXUS — %s" % kind, "",
             "Généré : %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"), ""]
    for label, ok in items:
        lines.append("- [%s] %s" % ("x" if ok else " ", label))
    lines += ["", "Sign-off opérateur : ______________________  date : __________", ""]
    path = _write_report("deploy-checklist-%s.md" % kind, "\n".join(lines))
    ok_all = all(ok for _, ok in items)
    return {"ok": True, "passed": ok_all, "kind": kind, "file": path,
            "items_checked": sum(1 for _, o in items if o), "items_total": len(items)}


def act_deploy_golive(params, ctx):
    """Garde GO-LIVE : qualité N× Vercel. 2× = p95 Edge ≤ 100 ms (Vercel 200 ms)."""
    factor = float(params.get("factor", 2))
    if not ensure_node(ctx):
        return {"ok": False, "error": "nœud edge injoignable pour la garde go-live"}
    url = default_node_url()
    lat, states = bench_keepalive(url, PATHS["jquery"], 50)
    if not lat:
        return {"ok": False, "error": "aucun échantillon"}
    p50, p95, p99 = pctl(lat, 50), pctl(lat, 95), pctl(lat, 99)
    budget = VERCEL_BASELINE_MS / factor
    passed = p95 <= budget
    return {"ok": True, "passed": passed, "gate_factor": factor,
            "p50_ms": round(p50, 3), "p95_ms": round(p95, 3), "p99_ms": round(p99, 3),
            "budget_ms": round(budget, 2), "vercel_baseline_ms": VERCEL_BASELINE_MS,
            "detail": "p95 %.3f ms vs budget %.2f ms (2× qualité si facteur 2)" % (p95, budget)}


def act_vercel_compare(params, ctx):
    """Comparaison live (bench instantané) ou cached (derniers résultats)."""
    mode = params.get("mode", "live")
    if mode == "live":
        if not ensure_node(ctx):
            return {"ok": False, "error": "nœud edge injoignable"}
        lat, _states = bench_keepalive(default_node_url(), PATHS["jquery"], 30)
        if not lat:
            return {"ok": False, "error": "aucun échantillon"}
        p50, p99 = pctl(lat, 50), pctl(lat, 99)
    else:
        hist = [r for r in load_results(400)
                if r.get("cat") == "LAT" and r.get("metrics", {}).get("p99_ms")]
        if not hist:
            return {"ok": False, "error": "aucun bench LAT en historique — lancez d'abord un bench"}
        p50 = min(r["metrics"].get("p50_ms", 99.0) for r in hist[-20:])
        p99 = min(r["metrics"]["p99_ms"] for r in hist[-20:])
    speedup_p50 = VERCEL_BASELINE_MS / max(p50, 0.001)
    speedup_p99 = VERCEL_BASELINE_MS / max(p99, 0.001)
    return {"ok": True, "passed": speedup_p99 >= 2.0, "mode": mode,
            "vercel_ttfb_ms": VERCEL_BASELINE_MS, "nexus_p50_ms": round(p50, 3),
            "nexus_p99_ms": round(p99, 3),
            "speedup_x_p50": round(speedup_p50, 1), "speedup_x_p99": round(speedup_p99, 1),
            "quality_gate": "2× Vercel %s" % ("PASS" if speedup_p99 >= 2.0 else "FAIL")}


def act_deploy_firewall(params, ctx):
    """Spécification de règles pare-feu (fichier génératif — n'exécute rien)."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        port = int(cfg.get("node", {}).get("port", 8765))
    except (OSError, ValueError, TypeError):
        port = 8765
    rules = [
        "# NEXUS — règles ufw suggérées (à adapter à votre politique DC)",
        "sudo ufw allow from 10.0.0.0/8 to any port %d proto tcp   # edge privé" % port,
        "sudo ufw allow from 172.16.0.0/12 to any port %d proto tcp" % port,
        "sudo ufw allow from 192.168.0.0/16 to any port %d proto tcp" % port,
        "# /nexus/shutdown est déjà refusé hors localhost par nexusd v1.0",
        "sudo ufw deny %d/tcp from any                             # tout le reste" % port,
    ]
    path = _write_report("firewall-spec.txt", "\n".join(rules) + "\n")
    return {"ok": True, "passed": True, "file": path, "rules": len(rules),
            "edge_port": port, "detail": "spec générée — application manuelle"}


def act_deploy_logrotate(params, ctx):
    """Spécification logrotate pour logs/nexusd.log (fichier génératif)."""
    conf = "\n".join([
        "%s/logs/nexusd.log {" % BASE_DIR,
        "    daily",
        "    rotate 14",
        "    size 50M",
        "    compress",
        "    delaycompress",
        "    missingok",
        "    notifempty",
        "    copytruncate",
        "}",
    ])
    path = _write_report("logrotate-nexusd.conf", conf + "\n")
    return {"ok": True, "passed": True, "file": path,
            "detail": "à placer dans /etc/logrotate.d/ (sudo)"}


def _tcp_open(host, port, timeout=0.5):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False




def act_deploy_topology(params, ctx):
    """Schéma ASCII du datacenter — nœuds du registre, anneaux <50 km."""
    nodes = fleet_nodes(ctx)
    lines = [
        "TOPOLOGIE NEXUS — DATACENTER %s" % datetime.now().strftime("%Y-%m-%d %H:%M"),
        "=" * 66,
        "",
        "                        [ ORIGINE / CDN ]",
        "                               |",
        "                    internet public (200 ms)",
        "                               |",
        "        +--------------------------------------------------+",
        "        |            ZONE DATACENTER PRIVÉE                |",
        "        |                                                  |",
    ]
    for i, n in enumerate(nodes[:6]):
        name = (n.get("name") or "node-%d" % i)[:14]
        url = (n.get("url") or "?").replace("http://", "")[:24]
        lines.append("        |   [N%-2d] %-14s %-24s |" % (i + 1, name, url))
        lines.append("        |          anneau <50 km — fibre 0,2 ms            |")
    if len(nodes) > 6:
        lines.append("        |   … +%d nœuds (registre complet)" % (len(nodes) - 6))
    lines += [
        "        +--------------------------------------------------+",
        "",
        "Principe : chaque client est servi par le nœud le plus proche,",
        "en keep-alive, depuis la RAM. L'origine n'est contactée qu'au",
        "remplissage du cache (MISS), jamais sur les requêtes chaudes.",
        "",
    ]
    path = _write_report("topology.txt", "\n".join(lines) + "\n")
    return {"ok": True, "passed": True, "file": path, "nodes": len(nodes),
            "detail": "schéma ASCII généré — à projeter en réunion"}


def act_deploy_capacity(params, ctx):
    """Capacité estimée : RPS mesuré (dernier LOAD) → millions req/jour/nœud."""
    hist = [r for r in load_results(400)
            if r.get("cat") == "LOAD" and r.get("metrics", {}).get("rps")]
    best_rps = max((float(r["metrics"]["rps"]) for r in hist), default=0.0)
    specs = _machine_specs()
    per_node = {"ram_gb": specs["ram_gb"], "cpu": specs["cpu_count"]}
    nodes_n = max(1, len(fleet_nodes(ctx)))
    if best_rps > 0:
        day_m = best_rps * 86400.0 / 1e6
        fleet_m = day_m * nodes_n
        detail = ("RPS mesuré %.0f/nœud → %.2f M req/jour/nœud → %.1f M req/jour "
                  "sur %d nœud(s)" % (best_rps, day_m, fleet_m, nodes_n))
        passed = day_m >= 1.0
    else:
        detail = "aucun test LOAD en historique — lancez LOAD-001 pour calibrer"
        passed = False
    lines = [
        "CAPACITÉ NEXUS — ESTIMATION DE PRODUCTION",
        "=" * 50,
        "RPS mesuré (meilleur test LOAD) : %.0f" % best_rps,
        "Millions de requêtes/jour/nœud  : %s" % (
            "%.2f" % (best_rps * 86400.0 / 1e6) if best_rps else "—"),
        "Nœuds du registre               : %d" % nodes_n,
        "RAM / CPU par nœud              : %s Go / %s cœurs" % (
            per_node["ram_gb"], per_node["cpu"]),
        "",
        detail,
    ]
    path = _write_report("capacity.txt", "\n".join(lines) + "\n")
    return {"ok": True, "passed": passed, "file": path,
            "rps_measured": best_rps, "nodes": nodes_n, "detail": detail[:120]}
# ═══════════════════════════════════════════════════════════════════════════
# Registre des primitives
# ═══════════════════════════════════════════════════════════════════════════

FNS = {}


def register(name, fn):
    FNS[name] = fn


_LOCAL = [
    act_probe_health, act_probe_metrics, act_probe_uptime, act_registry_raw,
    act_registry_json, act_state_file, act_version_check, act_offline_probe,
    act_bench_edge, act_bench_origin, act_rtt_probe, act_gate_latency,
    act_load, act_ramp, act_warm, act_hit_ratio, act_restart_clear,
    act_prefetch, act_ttl_check, act_stale, act_churn, act_malformed, act_idle,
    act_header_check, act_http_status, act_content_length, act_head_matches,
    act_body_hash, act_unknown_path, act_method_405, act_keepalive_n,
    act_smi_list, act_sweep, act_fleet_bench, act_fleet_rtt, act_fleet_report,
    act_registry_export, act_config_validate, act_origins_match, act_warmup_valid,
    act_idempotent_start, act_pid_file, act_config_proposal, act_export_last,
    act_export_results, act_export_metrics, act_bench_report, act_acceptance_md,
    act_timeline, act_summary, act_log_tail, act_zip_reports, act_clear_results,
    act_metrics_history, act_suite_stats, act_catalog_dump,
    act_run_workflow, act_run_category, act_dry_run_workflow, act_dry_run_actions,
    act_repeat, act_list_workflows, act_describe_workflow,
]

_DEPLOY = [
    act_deploy_prereqs, act_deploy_modules, act_deploy_systemd,
    act_deploy_checklist, act_deploy_golive, act_vercel_compare,
    act_deploy_firewall, act_deploy_logrotate, act_deploy_topology,
    act_deploy_capacity,
]

for _fn in _LOCAL + _DEPLOY:
    register(_fn.__name__, _fn)


# ═══════════════════════════════════════════════════════════════════════════
# Catalogue — exactement 400 actions, 12 catégories
# ═══════════════════════════════════════════════════════════════════════════

CAT_NAMES = {
    "PROBE": "Sondes de nœud",
    "LAT": "Tests de latence",
    "LOAD": "Tests de charge",
    "CACHE": "Opérations de cache",
    "RESIL": "Résilience",
    "HDR": "Validation des en-têtes",
    "HTTP": "Vérifications HTTP",
    "FLEET": "Opérations de flotte",
    "CFG": "Configuration",
    "RPT": "Rapports & exports",
    "WF": "Workflows",
    "DEPLOY": "Déploiement datacenter & qualité 2× Vercel",
}


def build_catalog():
    cat = []

    def add(cat_id, fn, label, desc, params):
        cat.append({"cat": cat_id, "label": label, "desc": desc,
                    "fn": fn, "params": params})

    # ── PROBE (30) ────────────────────────────────────────────────────────
    for t in (0.5, 1, 2, 3, 5):
        add("PROBE", "act_probe_health", "Santé du nœud (timeout %ss)" % t,
            "GET /nexus/health", {"timeout": t})
    for t in (0.5, 1, 2, 3, 5):
        add("PROBE", "act_probe_metrics", "Métriques du nœud (timeout %ss)" % t,
            "GET /nexus/metrics", {"timeout": t})
    for m in (1, 10, 60, 600, 3600):
        add("PROBE", "act_probe_uptime", "Uptime ≥ %ss" % m,
            "Le nœud tourne depuis au moins %ss" % m, {"min_s": m})
    for mode in ("raw", "json"):
        add("PROBE", "act_registry_raw" if mode == "raw" else "act_registry_json",
            "Registre des nœuds (%s)" % mode, "Contenu du registre", {})
    for kind in ("exists", "valid", "latencies"):
        add("PROBE", "act_state_file", "Fichier d'état (%s)" % kind,
            "runtime/state.json — %s" % kind, {"kind": kind})
    for t in (0.5, 1, 2, 3, 5):
        add("PROBE", "act_version_check", "Version nexusd correcte (timeout %ss)" % t,
            "version commence par nexusd/1.", {"timeout": t})
    for p in (8798, 8800, 9100, 9101, 9999):
        add("PROBE", "act_offline_probe", "Port %d au repos (refus attendu)" % p,
            "Sonde TCP : personne ne doit écouter", {"port": p})

    # ── LAT (50) ─────────────────────────────────────────────────────────
    for pk, path in PATHS.items():
        for s in (10, 30, 100, 300):
            add("LAT", "act_bench_edge", "Bench Edge %s (%d échantillons)" % (pk, s),
                "TTFB persistant sur le chemin Nexus", {"path": path, "samples": s})
    for pk, path in PATHS.items():
        add("LAT", "act_bench_origin", "Bench Origine %s (5 essais)" % pk,
            "Mêmes octets via le CDN d'origine", {"path": path, "samples": 5})
    for n in (5, 10, 25, 50, 100):
        add("LAT", "act_rtt_probe", "RTT Edge persistant (%d essais)" % n,
            "Sonde réseau nexus-studio → nœud", {"target": "edge", "n": n})
    for n in (10, 25, 50):
        add("LAT", "act_rtt_probe", "RTT Origine persistant (%d essais)" % n,
            "Sonde réseau vers le CDN d'origine", {"target": "origin", "n": n})
    for metric in ("p50", "p95", "p99"):
        for thr in (1, 2, 5):
            add("LAT", "act_gate_latency", "Garde %s Edge ≤ %dms" % (metric, thr),
                "Mesure + assertion contractuelle", {"scope": "edge", "metric": metric, "threshold_ms": thr})
    for thr in (1, 2, 5):
        add("LAT", "act_gate_latency", "Garde p99 RTT ≤ %dms" % thr,
            "Sonde réseau + assertion", {"scope": "rtt", "metric": "p99", "threshold_ms": thr})

    # ── LOAD (40) ─────────────────────────────────────────────────────────
    profiles = [(10, 5), (25, 5), (50, 5), (100, 5), (150, 10), (250, 10)]
    for pk in ("jquery", "bootstrap_js", "bootstrap_css"):
        for w, d in profiles:
            add("LOAD", "act_load", "Charge Edge %s (%d workers, %ds)" % (pk, w, d),
                "Rafale keep-alive sur le nœud", {"path": PATHS[pk], "workers": w, "duration_s": d})
    for pk in ("jquery", "bootstrap_js", "bootstrap_css"):
        for w in (10, 25):
            add("LOAD", "act_load", "Charge Edge %s (nouvelle connexion ×%d)" % (pk, w),
                "Handshake à chaque requête (anti-modèle, à battre)",
                {"path": PATHS[pk], "workers": w, "duration_s": 5, "mode": "newconn"})
    for pk in ("jquery", "bootstrap_js", "bootstrap_css"):
        for w in (10, 25, 50):
            add("LOAD", "act_load", "Charge Origine %s (%d workers)" % (pk, w),
                "Même charge directement sur le CDN", {"target": "origin", "path": PATHS[pk],
                                                      "workers": w, "duration_s": 5})
    for w, d in ((10, 60), (50, 60), (10, 300)):
        add("LOAD", "act_load", "Soak Edge jquery (%d workers, %ds)" % (w, d),
            "Endurance longue durée", {"path": PATHS["jquery"], "workers": w, "duration_s": d})
    for pk in ("jquery", "bootstrap_js"):
        for steps in ("10,50,100", "25,100,250"):
            add("LOAD", "act_ramp", "Rampe Edge %s (paliers %s)" % (pk, steps),
                "Charge croissante par paliers de 2s", {"path": PATHS[pk], "steps": steps})

    # ── CACHE (40) ────────────────────────────────────────────────────────
    for pk, path in PATHS.items():
        for mode, times in (("once", 1), ("twice", 2), ("head_after", 1)):
            label = {"once": "simple", "twice": "double", "head_after": "HEAD après"}[mode]
            add("CACHE", "act_warm", "Warm-up %s (%s)" % (pk, label),
                "Préchauffe le cache pour %s" % pk,
                {"path": path, "times": times, "mode": "get" if mode != "head_after" else "head_after"})
    for pk, path in PATHS.items():
        add("CACHE", "act_hit_ratio", "Taux HIT %s (5 requêtes)" % pk,
            "Après warm-up : 100% attendu", {"path": path})
    for pk, path in PATHS.items():
        add("CACHE", "act_restart_clear", "Redémarrage vide le cache %s" % pk,
            "STOP→START→MISS→HIT (cache 100% RAM)", {"path": path})
    for pk, path in PATHS.items():
        add("CACHE", "act_prefetch", "Préchargement solo %s" % pk,
            "Warm-up ciblé d'un asset", {"paths": [path]})
    add("CACHE", "act_prefetch", "Préchargement des 6 assets",
        "Warm-up de tout le catalogue critique", {"paths": PATHS_LIST})
    add("CACHE", "act_prefetch", "Préchargement complet + vérification",
        "Warm-up du catalogue puis contrôle des états", {"paths": PATHS_LIST, "verify": True})
    for mode in ("fresh", "expired"):
        add("CACHE", "act_ttl_check", "TTL %s (nœud test)" % mode,
            "Nœud temporaire TTL 5s — fraîcheur du cache",
            {"mode": mode})

    # ── RESIL (40) ────────────────────────────────────────────────────────
    for mode in ("fresh", "expired", "cold", "recovery", "slow"):
        for i in (1, 2):
            desc = {
                "fresh": "Origine morte + cache frais → HIT (isolation totale)",
                "expired": "Cache expiré + origine morte → STALE (qualité de service)",
                "cold": "Origine morte + cache vide → 502 propre",
                "recovery": "Origine revenue → rechargement MISS",
                "slow": "Origine lente (200ms) → MISS lent, puis HIT rapide",
            }[mode]
            add("RESIL", "act_stale", "Stale-if-error mode %s (scénario %d)" % (mode, i),
                desc, {"mode": mode, "path": "/asset/stale-%s-%d" % (mode, i)})
    for pk in ("jquery", "bootstrap_js"):
        for n in (25, 50, 100, 200, 400):
            add("RESIL", "act_churn", "Churn de connexions %s ×%d" % (pk, n),
                "%d connexions ouvertes puis fermées" % n, {"path": PATHS[pk], "connections": n})
    for kind in ("garbage", "bad_method", "bad_version", "partial_header",
                 "huge_header", "empty_request", "no_target", "bad_content_length",
                 "spaced_path", "double_get"):
        add("RESIL", "act_malformed", "Robustesse : requête « %s »" % kind,
            "Le nœud ne doit jamais crasher", {"kind": kind})
    for w in (1, 3, 5, 10, 15, 20, 25, 30):
        add("RESIL", "act_idle", "Connexion vivante après %ss d'inactivité" % w,
            "Keep-alive maintenu (timeout 30s)", {"wait_s": w, "expect": "alive"})
    for w in (31, 35):
        add("RESIL", "act_idle", "Connexion fermée après %ss d'inactivité" % w,
            "Le nœud nettoie les connexions dormantes", {"wait_s": w, "expect": "closed"})

    # ── HDR (30) ──────────────────────────────────────────────────────────
    checks = (("cache_control", "Cache-Control présent"),
              ("x_cache_hit", "X-Nexus-Cache = HIT"),
              ("x_latency_fast", "X-Nexus-Latency ≤ 2ms"),
              ("etag", "ETag présent"),
              ("content_type", "Content-Type correct"))
    for pk, path in PATHS.items():
        for check, clabel in checks:
            add("HDR", "act_header_check", "%s — %s" % (pk, clabel),
                "Correction des en-têtes (logique v1)", {"path": path, "check": check})

    # ── HTTP (40) ─────────────────────────────────────────────────────────
    for pk, path in PATHS.items():
        add("HTTP", "act_http_status", "Statut 200 — %s" % pk,
            "GET renvoie 200", {"path": path})
    for pk, path in PATHS.items():
        add("HTTP", "act_content_length", "Content-Length exact — %s" % pk,
            "En-tête = taille réelle du corps", {"path": path})
    for pk, path in PATHS.items():
        add("HTTP", "act_head_matches", "HEAD cohérent — %s" % pk,
            "HEAD renvoie la même longueur que GET", {"path": path})
    for pk, path in PATHS.items():
        add("HTTP", "act_body_hash", "Intégrité octets Edge=Origine — %s" % pk,
            "MD5 du corps identique des deux côtés", {"path": path})
    for pk, path in PATHS.items():
        add("HTTP", "act_unknown_path", "Chemin inconnu → 502 propre — %s" % pk,
            "Asset inexistant : 502 sans crash", {"path": "/no/such/%s.js" % pk})
    for m in ("POST", "PUT", "DELETE", "OPTIONS", "PATCH", "TRACE"):
        add("HTTP", "act_method_405", "Méthode %s → 405" % m,
            "Méthodes non supportées refusées proprement", {"method": m})
    for n in (2, 5, 10, 25):
        add("HTTP", "act_keepalive_n", "Keep-alive : %d requêtes, 1 connexion" % n,
            "Connexion persistante réutilisée", {"requests": n})

    # ── FLEET (30) ────────────────────────────────────────────────────────
    for mode in ("plain", "json", "rtt"):
        add("FLEET", "act_smi_list", "Vue de flotte (%s)" % mode,
            "Équivalent nexus-smi --list", {"mode": mode})
    for t in (0.5, 1, 2, 3, 5):
        add("FLEET", "act_sweep", "Sweep santé (timeout %ss)" % t,
            "Sonde tous les nœuds du registre", {"sweep": "health", "timeout": t})
    for t in (0.5, 1, 2, 3, 5):
        add("FLEET", "act_sweep", "Sweep métriques (timeout %ss)" % t,
            "Métriques de tous les nœuds", {"sweep": "metrics", "timeout": t})
    for pk in ("jquery", "bootstrap_js"):
        for s in (10, 30, 100):
            add("FLEET", "act_fleet_bench", "Bench de flotte %s (%d essais)" % (pk, s),
                "Latence mesurée sur chaque nœud", {"path": PATHS[pk], "samples": s})
    for n in (5, 10, 25, 50, 100):
        add("FLEET", "act_fleet_rtt", "RTT de flotte (%d essais)" % n,
            "Sonde réseau vers chaque nœud", {"n": n})
    for fmt in ("txt", "md"):
        add("FLEET", "act_fleet_report", "Rapport de flotte (%s)" % fmt,
            "Fichier studio/reports/fleet-report", {"fmt": fmt})
    for fmt, tag in (("json", "après sweep"), ("csv", "après sweep"),
                     ("json", "brut"), ("csv", "brut")):
        add("FLEET", "act_registry_export", "Export registre %s (%s)" % (fmt, tag),
            "Fichier studio/reports/registry", {"fmt": fmt})

    # ── CFG (20) ──────────────────────────────────────────────────────────
    for check in ("parses", "keys_node", "keys_cache", "keys_origins", "types_ports"):
        add("CFG", "act_config_validate", "Config valide : %s" % check,
            "Validation structurelle de config/nexus.json", {"check": check})
    for pk in ("jquery", "bootstrap_js", "bootstrap_css", "react"):
        add("CFG", "act_origins_match", "Résolution d'origine pour %s" % pk,
            "Le préfixe gagnant pointe bien sur le CDN", {"path": PATHS[pk]})
    for idx in (0, 1, -1):
        add("CFG", "act_warmup_valid", "Liste de warm-up valide (index %s)" % idx,
            "Les chemins critiques sont bien formés", {"index": idx})
    for tag in ("running", "restart"):
        add("CFG", "act_idempotent_start", "Démarrage idempotent (%s)" % tag,
            "start sur nœud déjà lancé = sans effet de bord", {})
    for expect in ("exists", "state"):
        add("CFG", "act_pid_file", "Fichier PID (%s)" % expect,
            "runtime/nexusd.pid cohérent", {"expect": expect})
    for field, value in (("ttl_s", 60), ("port", 8770), ("max_entries", 10000),
                         ("max_body_bytes", 10485760)):
        add("CFG", "act_config_proposal", "Proposition config : %s=%s (dry-run)" % (field, value),
            "Simulation de réglage — rien n'est écrit", {"field": field, "value": value})

    # ── RPT (30) ───────────────────────────────────────────────────────────
    for fmt in ("json", "csv"):
        add("RPT", "act_export_last", "Export dernier résultat (%s)" % fmt,
            "studio/reports/last-result", {"fmt": fmt})
    for fmt in ("json", "csv", "jsonl"):
        add("RPT", "act_export_results", "Export historique complet (%s)" % fmt,
            "studio/reports/all-results", {"fmt": fmt})
    for fmt in ("json", "csv", "txt"):
        add("RPT", "act_export_metrics", "Export métriques live (%s)" % fmt,
            "Instantané /nexus/metrics", {"fmt": fmt})
    for fmt in ("txt", "md"):
        add("RPT", "act_bench_report", "Rapport de bench (%s)" % fmt,
            "Synthèse des latences mesurées", {"fmt": fmt})
    add("RPT", "act_acceptance_md", "Rapport d'acceptation datacenter (md)",
        "Document de validation pour la revue", {})
    for fmt in ("json", "csv"):
        add("RPT", "act_timeline", "Chronologie des exécutions (%s)" % fmt,
            "Séquence des actions passées", {"fmt": fmt})
    for fmt in ("txt", "json", "csv", "md"):
        add("RPT", "act_summary", "Synthèse de session (%s)" % fmt,
            "Taux de réussite, meilleur p99", {"fmt": fmt})
    for n in (20, 50, 100, 200):
        add("RPT", "act_log_tail", "Fin du journal nexusd (%d lignes)" % n,
            "logs/nexusd.log", {"lines": n})
    add("RPT", "act_zip_reports", "Archive des rapports (zip)",
        "Tous les exports dans un zip", {})
    add("RPT", "act_clear_results", "Purge de l'historique",
        "Remet les compteurs à zéro", {})
    for fmt in ("json", "csv"):
        add("RPT", "act_metrics_history", "Historique métriques (%s)" % fmt,
            "p99 au fil des sondes", {"fmt": fmt})
    for fmt in ("txt", "json"):
        add("RPT", "act_suite_stats", "Statistiques par catégorie (%s)" % fmt,
            "Répartition des exécutions", {"fmt": fmt})
    for fmt in ("json", "csv", "md"):
        add("RPT", "act_catalog_dump", "Dump du catalogue 400 actions (%s)" % fmt,
            "Inventaire complet des actions", {"fmt": fmt})

    # ── WF (20) ────────────────────────────────────────────────────────────
    for wf in ("smoke_test", "pitch_demo", "acceptance_datacenter"):
        for strict in (True, False):
            add("WF", "act_run_workflow", "Workflow « %s » (%s)" % (
                wf, "strict" if strict else "continu"),
                "Suite prédéfinie multi-étapes", {"name": wf, "strict": strict})
    for c in ("PROBE", "LAT", "LOAD", "CACHE", "RESIL"):
        add("WF", "act_run_category", "Exécution catégorie %s (3 premières)" % c,
            "Lance les premières actions de la catégorie", {"cat": c, "limit": 3})
    for wf in ("smoke_test", "pitch_demo", "acceptance_datacenter"):
        add("WF", "act_dry_run_workflow", "Plan du workflow « %s » (dry-run)" % wf,
            "Affiche les étapes sans exécuter", {"name": wf})
    add("WF", "act_repeat", "Répétition smoke_test ×2",
        "Stabilité par exécutions répétées", {"action": "WF-001", "times": 2})
    for mode in ("plain", "json"):
        add("WF", "act_list_workflows", "Liste des workflows (%s)" % mode,
            "Suites disponibles", {"mode": mode})
    for wf in ("smoke_test", "acceptance_datacenter"):
        add("WF", "act_describe_workflow", "Détail du workflow « %s »" % wf,
            "Étapes et gardes", {"name": wf})
    add("WF", "act_dry_run_actions", "Dry-run LAT-001",
        "Paramètres sans exécution", {"action_ids": ["LAT-001"]})

    # ── DEPLOY (30) — déploiement datacenter & qualité 2× Vercel ──────────
    for level in ("quick", "standard", "strict", "datacenter"):
        add("DEPLOY", "act_deploy_prereqs", "Prérequis machine (%s)" % level,
            "Python, RAM, disque, CPU, répertoires runtime", {"level": level})
    for kind in ("inventory", "integrity", "versions"):
        add("DEPLOY", "act_deploy_modules", "Modules v1.0 (%s)" % kind,
            "nexusd / ctl / smi / bench / config — présents et intacts", {"kind": kind})
    for mode in ("render", "install", "status"):
        add("DEPLOY", "act_deploy_systemd", "Unité systemd (%s)" % mode,
            "nexusd.service — render, commandes d'installation, état", {"mode": mode})
    for kind in ("full", "security"):
        add("DEPLOY", "act_deploy_checklist", "Checklist de mise en prod (%s)" % kind,
            "Cases cochées depuis l'état réel de la machine", {"kind": kind})
    for f in (2, 5, 10):
        add("DEPLOY", "act_deploy_golive", "Garde GO-LIVE %d× Vercel" % f,
            "p95 Edge ≤ %.0f ms (baseline Vercel %d ms)" % (VERCEL_BASELINE_MS / f, VERCEL_BASELINE_MS),
            {"factor": f})
    for mode in ("live", "cached"):
        add("DEPLOY", "act_vercel_compare", "Comparaison Vercel (%s)" % mode,
            "VERCEL %d ms vs NEXUS — facteur de gain" % VERCEL_BASELINE_MS, {"mode": mode})
    add("DEPLOY", "act_deploy_firewall", "Spec pare-feu (ufw)",
        "Règles suggérées pour le port edge — fichier génératif", {})
    add("DEPLOY", "act_deploy_logrotate", "Spec logrotate nexusd",
        "Rotation quotidienne, 14 jours — fichier génératif", {})
    add("DEPLOY", "act_deploy_topology", "Topologie du datacenter (ASCII)",
        "Nœuds du registre, anneaux <50 km — schéma génératif", {})
    add("DEPLOY", "act_deploy_capacity", "Capacité (M req/jour, RPS mesuré)",
        "Extrapolation de production depuis les tests LOAD", {})
    add("DEPLOY", "act_config_proposal", "Prod config : max_entries=50000 (dry-run)",
        "Réglage de production simulé — rien n'est écrit", {"field": "max_entries", "value": 50000})
    for p in (8801, 8802):
        add("DEPLOY", "act_offline_probe", "Port %d libre (nouveau nœud)" % p,
            "Port disponible pour un nœud additionnel", {"port": p})
    add("DEPLOY", "act_zip_reports", "Paquet de déploiement (zip)",
        "Rapports archivés pour la revue de mise en prod", {})
    add("DEPLOY", "act_acceptance_md", "Rapport d'acceptation (md)",
        "Preuve formelle pour la revue Oracle/Google", {})
    for fmt in ("txt", "md"):
        add("DEPLOY", "act_bench_report", "Preuve de latence (%s)" % fmt,
            "Rapport de bench orienté mise en prod", {"fmt": fmt})
    for fmt in ("txt", "md"):
        add("DEPLOY", "act_summary", "Synthèse de mise en prod (%s)" % fmt,
            "Bilan de session pour le sign-off", {"fmt": fmt})

    # ── Numérotation + intégrité ──────────────────────────────────────────
    counters = {}
    for a in cat:
        c = a["cat"]
        counters[c] = counters.get(c, 0) + 1
        a["id"] = "%s-%03d" % (c, counters[c])
    total = len(cat)
    expected = {"PROBE": 30, "LAT": 50, "LOAD": 40, "CACHE": 40, "RESIL": 40,
                "HDR": 30, "HTTP": 40, "FLEET": 30, "CFG": 20, "RPT": 30,
                "WF": 20, "DEPLOY": 30}
    for c, n in expected.items():
        if counters.get(c, 0) != n:
            raise RuntimeError("Catalogue %s : %d au lieu de %d" % (c, counters.get(c, 0), n))
    if total != 400:
        raise RuntimeError("Catalogue : %d actions au lieu de 400" % total)
    return cat


# ═══════════════════════════════════════════════════════════════════════════
# ÉCRAN TEMPS RÉEL (« écran ») + PITCH VISUEL — TUI ANSI plein écran
# Pages : 1 Vue d'ensemble · 2 Latence & échelle · 3 Flotte · 4 Déploiement · 5 Journal
# Touches : 1-5 pages · r sonde · b bench · p pitch · q quitter
# Sans TTY (pipe/script) : rend une seule frame puis rend la main.
# ═══════════════════════════════════════════════════════════════════════════

ANSI_ALT_ON = "\033[?1049h"
ANSI_ALT_OFF = "\033[?1049l"
ANSI_HIDE = "\033[?25l"
ANSI_SHOW = "\033[?25h"
ANSI_CLEAR = "\033[2J"
ANSI_HOME = "\033[H"

BOLD = "\033[1m"
GREEN = "\033[0;32m"
RED = "\033[0;31m"
YELLOW = "\033[1;33m"
CYAN = "\033[0;36m"
DIM = "\033[2m"
NC = "\033[0m"

SPARK_BLOCKS = "▁▂▃▄▅▆▇█"
PAGE_NAMES = ("VUE D'ENSEMBLE", "LATENCE & ÉCHELLE", "FLOTTE", "DÉPLOIEMENT",
              "JOURNAL D'ACTIONS")


def term_size():
    try:
        sz = shutil.get_terminal_size((100, 32))
        return max(80, sz.columns), max(24, sz.lines)
    except (ValueError, OSError):
        return 100, 32


def visible_width(s):
    """Largeur affichable (sans les séquences ANSI)."""
    n, i = 0, 0
    while i < len(s):
        if s[i] == "\033":
            j = s.find("m", i)
            i = (j + 1) if j != -1 else len(s)
        else:
            n += 1
            i += 1
    return n


def fit(s, w):
    """Tronque aux caractères visibles."""
    out, n, i = [], 0, 0
    while i < len(s) and n < w:
        if s[i] == "\033":
            j = s.find("m", i)
            if j == -1:
                break
            out.append(s[i:j + 1])
            i = j + 1
        else:
            out.append(s[i])
            n += 1
            i += 1
    return "".join(out)


def hbar(value, maxv, width):
    """Barre pleine proportionnelle — pour les comparaisons de latence."""
    frac = 0.0 if maxv <= 0 else max(0.0, min(1.0, value / maxv))
    n = int(round(frac * width))
    return "█" * max(0, n) + "·" * (width - n)


def spark(values, width):
    """Mini-graphe de tendance (p99 au fil de l'eau)."""
    values = [v for v in (values or []) if isinstance(v, (int, float))]
    if not values:
        return "—" * width
    vals = values[-width:]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1.0
    out = []
    for v in vals:
        idx = int((v - lo) / span * (len(SPARK_BLOCKS) - 1))
        out.append(SPARK_BLOCKS[idx])
    return "".join(out)


def panel(title, lines, width):
    """Cadre une liste de lignes (déjà colorées) dans une boîte."""
    out = ["┌─ %s %s" % (title, "─" * max(0, width - len(title) - 4))]
    for ln in lines:
        out.append("│ " + fit(ln, width - 3))
    out.append("└" + "─" * (width - 1))
    return out


def kv(label, value, width=22):
    """« label .... valeur » — longueur VISIBLE totale exactement = width."""
    value = str(value)
    vlen = visible_width(value)
    dots = max(1, width - len(label) - vlen - 2)
    return "%s %s %s" % (label, "." * dots, value)


class RawKeys:
    """Lecture clavier non bloquante (termios) — inerte hors TTY."""

    def __init__(self):
        self.enabled = False
        self._saved = None
        try:
            import termios
            import tty
            if sys.stdin.isatty():
                self._saved = termios.tcgetattr(sys.stdin.fileno())
                tty.setcbreak(sys.stdin.fileno())
                self.enabled = True
                self._termios = termios
        except (ImportError, OSError, ValueError):
            self.enabled = False

    def poll(self, timeout=1.0):
        if not self.enabled:
            time.sleep(min(timeout, 0.25))
            return None
        r, _w, _x = select.select([sys.stdin], [], [], timeout)
        if r:
            try:
                return sys.stdin.read(1)
            except (OSError, ValueError):
                return None
        return None

    def close(self):
        if self.enabled and self._saved is not None:
            try:
                self._termios.tcsetattr(sys.stdin.fileno(),
                                        self._termios.TCSADRAIN, self._saved)
            except (OSError, ValueError):
                pass
            self.enabled = False


class Screen:
    """Écran Datacenter Pro — 4 pages, rafraîchi chaque seconde."""

    def __init__(self, engine, interval=1.0):
        self.engine = engine
        self.interval = interval
        self.page = 0
        self.feed = []           # journal des actions Studio de la session
        self.p99_hist = []
        self.keys = RawKeys()
        self._alt = False

    # ── cycle de vie ──────────────────────────────────────────────────────
    def open(self):
        self._is_tty = sys.stdout.isatty()
        if self._is_tty:
            sys.stdout.write(ANSI_ALT_ON + ANSI_CLEAR + ANSI_HIDE)
            sys.stdout.flush()
            self._alt = True

    def close(self):
        self.keys.close()
        if self._alt:
            sys.stdout.write(ANSI_SHOW + ANSI_ALT_OFF)
            sys.stdout.flush()
            self._alt = False

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *_exc):
        self.close()
        return False

    # ── données ───────────────────────────────────────────────────────────
    def collect(self):
        st = {"ts": datetime.now().strftime("%H:%M:%S")}
        url = default_node_url().rstrip("/")
        st["node_url"] = url
        st["online"] = False
        try:
            m = get_json(url + "/nexus/metrics", timeout=1.2)
            st["online"] = True
            st["metrics"] = m
            lat = m.get("latency_ms", {})
            if lat.get("p99") is not None:
                self.p99_hist.append(float(lat["p99"]))
        except Exception:  # noqa: BLE001
            st["metrics"] = None
        # dernier bench LAT enregistré (pour p50/p95/p99 du chemin Nexus)
        # on ignore les gardes (elles portent actual_ms, pas p50_ms)
        last = None
        for r in reversed(load_results(200)):
            m = r.get("metrics") or {}
            if r.get("cat") == "LAT" and m.get("p99_ms") is not None \
                    and m.get("hit_ratio_pct") is not None:
                last = r
                break
        st["last_lat"] = last
        # garde 2× Vercel depuis le dernier go-live si présent
        gate = None
        for r in reversed(load_results(200)):
            if r.get("cat") == "DEPLOY" and r.get("metrics", {}).get("gate_factor") == 2:
                gate = r
                break
        st["gate"] = gate
        st["nodes"] = fleet_nodes({})
        st["results"] = load_results(60)
        return st

    # ── rendu ─────────────────────────────────────────────────────────────
    def render(self, st, cols, rows):
        body = self._page(st, cols)
        frame = [ANSI_HOME + ANSI_CLEAR]
        frame.extend(body)
        frame.append("")
        sys.stdout.write("\n".join(frame))
        sys.stdout.flush()

    def _header(self, st, cols):
        state = (GREEN + "EN LIGNE " + NC) if st["online"] else (RED + "HORS LIGNE" + NC)
        m = st.get("metrics") or {}
        left = " NEXUS STUDIO PRO — DATACENTER · %s · %s" % (
            m.get("node", "—"), m.get("region", "—"))
        right = "%s  %s" % (state, st["ts"])
        pad = max(1, cols - visible_width(left) - visible_width(right) - 2)
        return ["┌%s┐" % ("─" * (cols - 2)),
                "│%s%s%s│" % (left, " " * pad, fit(right, cols - 2 - visible_width(left)))]

    def _footer(self, cols):
        keys = " 1-5 pages · r sonde · b bench · p pitch · q quitter "
        line = "├%s┤" % keys.center(cols - 2, "─")
        return [line, "└%s┘" % ("─" * (cols - 2))]

    def _page(self, st, cols):
        out = self._header(st, cols)
        h_available = term_size()[1] - len(out) - 2
        if self.page == 0:
            body = self._page_overview(st, cols, h_available)
        elif self.page == 1:
            body = self._page_latency(st, cols, h_available)
        elif self.page == 2:
            body = self._page_fleet(st, cols, h_available)
        elif self.page == 3:
            body = self._page_deploy(st, cols, h_available)
        else:
            body = self._page_journal(st, cols, h_available)
        out.extend(body)
        out.extend(self._footer(cols))
        return out

    # ── page 1 ────────────────────────────────────────────────────────────
    def _page_overview(self, st, cols, h):
        m = st.get("metrics") or {}
        w = max(24, (cols - 4) // 3)
        kw = w - 3
        node_lines = [
            kv("état", (GREEN + "en ligne" + NC) if st["online"] else (RED + "hors ligne" + NC), kw),
            kv("uptime", "%ss" % m.get("uptime_s", "—"), kw),
            kv("requêtes", m.get("requests", "—"), kw),
            kv("rps", m.get("rps", "—"), kw),
            kv("erreurs", m.get("errors", "—"), kw),
        ]
        cache_lines = [
            kv("entrées", m.get("cache_entries", "—"), kw),
            kv("hits", m.get("hits", "—"), kw),
            kv("hit %", m.get("hit_ratio_pct", "—"), kw),
            kv("évictions", m.get("evictions", "—"), kw),
            kv("servis", "%s o" % m.get("bytes_served", "—"), kw),
        ]
        gate = st.get("gate")
        last = st.get("last_lat")
        p99 = (last or {}).get("metrics", {}).get("p99_ms")
        vercel = VERCEL_BASELINE_MS
        gain = ("×%.0f" % (vercel / max(p99, 0.001))) if p99 else "—"
        if gate is not None:
            gp = gate.get("passed")
            gate_txt = (GREEN + "PASS (p95 %.1fms)" % gate["metrics"].get("p95_ms", -1) + NC) \
                if gp else (RED + "FAIL" + NC)
        elif p99 is not None:
            gate_txt = (GREEN + "PASS (p99 %.2fms)" % p99 + NC) if p99 <= vercel / 2.0 \
                else (YELLOW + "à re-mesurer" + NC)
        else:
            gate_txt = DIM + "lancez DEPLOY-013" + NC
        barw = max(6, w - 22)
        qual_lines = [
            "VERCEL %s %dms" % (hbar(vercel, vercel, barw), vercel),
            "NEXUS  %s %sms" % (hbar(p99 or 0.0, vercel, barw),
                                ("%.2f" % p99) if p99 else "—"),
            kv("gain", gain, kw),
            kv("garde 2×", gate_txt, kw),
        ]
        lines = panel("NŒUD", node_lines, w)[:-1] + panel("CACHE 100% RAM", cache_lines, w)[1:-1] \
            + panel("QUALITÉ 2× VERCEL", qual_lines, w)[1:]
        lat = st.get("last_lat")
        lm = (lat or {}).get("metrics", {})
        bench_lines = [
            "dernier bench : %s — %s échantillons" % (
                os.path.basename(lm.get("path", "—")) if lm else "—",
                lm.get("samples", "—") if lm else "—"),
            "p50 %sms · p95 %sms · p99 %sms · hit %s%%" % (
                lm.get("p50_ms", "—"), lm.get("p95_ms", "—"),
                lm.get("p99_ms", "—"), lm.get("hit_ratio_pct", "—")),
            "tendance p99 (nœud) : %s" % spark(self.p99_hist, max(10, cols - 26)),
        ]
        obj = "objectif contractuel p99 ≤ 2ms : %s" % (
            (GREEN + "TENU" + NC) if (lm.get("p99_ms") or 99) <= 2.0
            else (YELLOW + "hors mesure" + NC))
        bench_lines.append(obj)
        lines.extend(panel("LATENCE (chemin Nexus)", bench_lines, cols - 2)[1:])
        return [fit(l, cols - 1) for l in lines[:max(3, h)]]

    # ── page 2 ────────────────────────────────────────────────────────────
    def _page_latency(self, st, cols, h):
        lm = (st.get("last_lat") or {}).get("metrics", {})
        p50 = lm.get("p50_ms")
        p95 = lm.get("p95_ms")
        p99 = lm.get("p99_ms")
        w = cols - 4
        lines = ["ÉCHELLE DE LATENCE — 200 ms → 2 ms (mesure : bench Nexus)",
                 "",
                 "CDN actuel (Vercel)   %s %d ms" % (hbar(200, 200, w - 26), 200),
                 "Promesse CDN -40%%    %s 120 ms" % hbar(120, 200, w - 26),
                 "Edge régional         %s  15 ms" % hbar(15, 200, w - 26),
                 "NEXUS <50km objectif  %s   2 ms  ← contrat" % hbar(2, 200, w - 26),
                 "",
                 "MESURE LIVE DU CHEMIN NEXUS :",
                 "p50  %s %s ms" % (hbar(p50 or 0, 200, w - 26),
                                    ("%.3f" % p50) if p50 else "—"),
                 "p95  %s %s ms" % (hbar(p95 or 0, 200, w - 26),
                                    ("%.3f" % p95) if p95 else "—"),
                 "p99  %s %s ms" % (hbar(p99 or 0, 200, w - 26),
                                    ("%.3f" % p99) if p99 else "—"),
                 "",
                 "GARDE QUALITÉ 2× VERCEL : p95 ≤ %.0f ms" % (VERCEL_BASELINE_MS / 2.0),
                 ]
        if p95 is not None:
            ok = p95 <= VERCEL_BASELINE_MS / 2.0
            lines.append("verdict : %s   (p95 %.3f ms vs budget %.0f ms)" % (
                (GREEN + "PASS — qualité 2× confirmée" + NC) if ok
                else (RED + "FAIL — voir DEPLOY-013" + NC), p95, VERCEL_BASELINE_MS / 2.0))
        else:
            lines.append("verdict : %s" % (DIM + "lancez un bench (LAT-001) ou DEPLOY-013" + NC))
        return [fit(l, cols - 1) for l in lines[:max(3, h)]]

    # ── page 3 ────────────────────────────────────────────────────────────
    def _page_fleet(self, st, cols, h):
        lines = ["Nœuds du registre (registry/nodes.json) — lecture seule :", ""]
        nodes = st.get("nodes") or []
        for n in nodes[:8]:
            url = (n.get("url") or "").rstrip("/")
            ok = False
            m = {}
            try:
                m = get_json(url + "/nexus/metrics", timeout=0.4)
                ok = True
            except Exception:  # noqa: BLE001
                ok = False
            state = (GREEN + "EN LIGNE " + NC) if ok else (RED + "hors ligne" + NC)
            lines.append("%-14s %-28s %s  p99 %sms · hit %s%%" % (
                (n.get("name") or "?")[:14], url[:28], state,
                (m.get("latency_ms", {}) or {}).get("p99", "—"),
                m.get("hit_ratio_pct", "—")))
        if not nodes:
            lines.append(DIM + "aucun nœud — nexus-ctl start enregistre le nœud par défaut" + NC)
        lines += ["",
                  "%sAstuces :%s ajouter un nœud : python3 nexus-ctl.py add --url http://IP:8765"
                  % (BOLD, NC),
                  "surveiller  : python3 nexus-smi.py --list   (inchangé, v1.0)",
                  "comparer    : catégorie FLEET — 30 actions de flotte"]
        return [fit(l, cols - 1) for l in lines[:max(3, h)]]

    # ── page 4 : DÉPLOIEMENT ────────────────────────────────────────────
    def _page_deploy(self, st, cols, h):
        """Page DÉPLOIEMENT : état des garde-fous de mise en production."""
        res = load_results(300)
        deploys = [r for r in res if r.get("cat") == "DEPLOY"]
        lines = ["Déploiement datacenter — dernier état des garde-fous :", ""]

        def _last(prefix, label):
            for r in reversed(deploys):
                if r["id"].startswith(prefix):
                    mark = (GREEN + "PASS" + NC) if r.get("passed") else \
                        ((GREEN + "ok  " + NC) if r.get("ok") else (RED + "échec" + NC))
                    lines.append("%-42s %s  (%s)" % ((r.get("label") or "")[:42],
                                                      mark, r.get("ts", "")[:19]))
                    return
            lines.append("%-42s %s" % (label, DIM + "pas encore exécuté" + NC))

        _last("DEPLOY-002", "Prérequis machine (standard)")
        _last("DEPLOY-006", "Intégrité modules v1.0")
        _last("DEPLOY-008", "Unité systemd (render)")
        _last("DEPLOY-011", "Checklist mise en prod")
        _last("DEPLOY-013", "Garde GO-LIVE 2× Vercel")
        _last("DEPLOY-016", "Comparaison Vercel (live)")
        lines += ["",
                  "Prochaine étape conseillée :",
                  "  python3 nexus_studio.py --workflow dc_readiness",
                  "  (prérequis → modules → config → systemd → go-live)"]
        return [fit(l, cols - 1) for l in lines[:max(3, h)]]

    # ── page 5 ────────────────────────────────────────────────────────
    def _page_journal(self, st, cols, h):
        res = st.get("results") or []
        lines = ["Historique Studio (studio/results/results.jsonl) — derniers %d :" % len(res), ""]
        for r in reversed(res[:h - 6]):
            mark = GREEN + "✅" + NC if r.get("ok") else RED + "❌" + NC
            lines.append("%s %s %-8s %-42s %6.1fms %s" % (
                mark, r.get("ts", ""), r.get("id", "?"),
                (r.get("label") or "")[:42], r.get("duration_ms", 0),
                "PASS" if r.get("passed") else ""))
        if not res:
            lines.append(DIM + "aucune action exécutée — appuyez sur r ou b" + NC)
        return [fit(l, cols - 1) for l in lines[:max(3, h)]]

    # ── boucle ────────────────────────────────────────────────────────────
    def run(self, once=False):
        self.open()
        prev_quiet = self.engine.quiet
        self.engine.quiet = True
        try:
            while True:
                cols, rows = term_size()
                st = self.collect()
                self.render(st, cols, rows)
                if once:
                    break
                if not self.keys.enabled:
                    # sortie pipée/script : on continue de dessiner, Ctrl+C sort
                    time.sleep(self.interval)
                    continue
                k = self.keys.poll(self.interval)
                if k in ("q", "Q", "\033"):
                    break
                if k in ("1", "2", "3", "4", "5"):
                    self.page = int(k) - 1
                elif k in ("r", "R"):
                    self.note(self.engine.run_action("PROBE-001"))
                elif k in ("b", "B"):
                    self.note(self.engine.run_action("LAT-001"))
                elif k in ("p", "P"):
                    show_pitch(self.engine)
        except KeyboardInterrupt:
            pass
        finally:
            self.engine.quiet = prev_quiet
            self.close()

    def note(self, record):
        """Ajoute un résultat au journal de session (page 4)."""
        if not record:
            return
        self.feed.append(record)
        p99 = (record.get("metrics") or {}).get("p99_ms")
        if isinstance(p99, (int, float)):
            self.p99_hist.append(float(p99))


# ═══════════════════════════════════════════════════════════════════════════
# PITCH VISUEL — Oracle / Google (plein écran, mesure live)
# ═══════════════════════════════════════════════════════════════════════════

def _pitch_measure(engine):
    """Bench rapide live (30 échantillons) — retombe sur l'historique."""
    if ensure_node({}):
        lat, _st = bench_keepalive(default_node_url(), PATHS["jquery"], 30)
        if lat:
            return {"p50": pctl(lat, 50), "p95": pctl(lat, 95), "p99": pctl(lat, 99),
                    "live": True}
    for r in reversed(load_results(200)):
        if r.get("cat") == "LAT" and r.get("metrics", {}).get("p99_ms"):
            m = r["metrics"]
            return {"p50": m.get("p50_ms", 0), "p95": m.get("p95_ms", 0),
                    "p99": m.get("p99_ms", 0), "live": False}
    return None


def _row(text, w):
    """Ligne de pitch : contenu paddé exactement à w de largeur visible."""
    pad = max(0, w - visible_width(text))
    return CYAN + "║" + NC + text + " " * pad + CYAN + "║" + NC


def _center(text, w):
    """Centre un texte (largeur visible) sur w colonnes."""
    pad = max(0, w - visible_width(text))
    left = pad // 2
    return " " * left + text + " " * (pad - left)


def pitch_lines(measure, cols=78):
    """Construit le pitch visuel (liste de lignes ANSI, cadre fermé)."""
    if measure:
        p50, p95, p99 = measure["p50"], measure["p95"], measure["p99"]
        src = "mesure LIVE (nœud edge, %s)" % (
            "30 échantillons" if measure["live"] else "dernier bench enregistré")
    else:
        p50 = p95 = p99 = None
        src = "nœud injoignable — démarrez : python3 nexus-ctl.py start"
    W = cols - 4                      # largeur intérieure du cadre
    gain = ("×%.0f" % (VERCEL_BASELINE_MS / max(p99, 0.001))) if p99 else "—"
    gate_ok = (p95 is not None and p95 <= VERCEL_BASELINE_MS / 2.0) \
        if p95 is not None else (p99 is not None and p99 <= VERCEL_BASELINE_MS / 2.0)
    barw = W - 20                     # barres TTFB
    ladder_bar = W - 46               # barres de l'échelle
    lines = [
        "",
        CYAN + "╔" + "═" * W + "╗" + NC,
        _row(BOLD + _center("N E X U S   E D G E  —  L A   L A T E N C E   R É I N V E N T É E", W), W),
        _row(_center("Studio Datacenter Pro — qualité de déploiement 2× Vercel", W), W),
        CYAN + "╠" + "═" * W + "╣" + NC,
        _row("TTFB COMPARÉ — %s" % src, W),
        _row("", W),
        _row("  VERCEL   %s %d ms" % (RED + hbar(VERCEL_BASELINE_MS, VERCEL_BASELINE_MS, barw) + NC,
                                      VERCEL_BASELINE_MS), W),
        _row("  NEXUS    %s %s ms" % (GREEN + hbar(p50 or 0.0, VERCEL_BASELINE_MS, barw) + NC,
                                      ("%.2f" % p50) if p50 else "—"), W),
        _row("", W),
        _row(BOLD + "  GAIN MESURÉ : %s   GARDE QUALITÉ 2× : %s" % (
            YELLOW + gain + NC,
            (GREEN + "PASS" + NC) if gate_ok else (RED + "FAIL" + NC)), W),
        CYAN + "╠" + "═" * W + "╣" + NC,
        _row("  L'ÉCHELLE DE LATENCE", W),
    ]
    ladder = [
        ("CDN actuel", 200, "200 ms  aujourd'hui, mesuré"),
        ("Promesse CDN", 120, "120 ms  -40 %, encore lent"),
        ("Edge régional", 15, " 15 ms  mieux, mais loin"),
        ("NEXUS <50km", 2, "  2 ms  objectif contractuel"),
    ]
    for name, val, note in ladder:
        lines.append(_row("  %-13s %s %s" % (name, hbar(val, 200, ladder_bar), note), W))
    lines += [
        CYAN + "╠" + "═" * W + "╣" + NC,
        _row("  Preuves : --workflow pitch_demo · écran : --screen · garde : DEPLOY-013", W),
        CYAN + "╚" + "═" * W + "╝" + NC,
        "",
    ]
    return lines


def show_pitch(engine, wait_key=True):
    """Affiche le pitch plein écran (mesure live incluse)."""
    measure = _pitch_measure(engine)
    cols, _rows = term_size()
    sys.stdout.write("\n".join(pitch_lines(measure, min(cols, 86))) + "\n")
    sys.stdout.flush()
    if wait_key and sys.stdin.isatty():
        try:
            input("  ↵ Entrée pour continuer… ")
        except (EOFError, KeyboardInterrupt):
            pass


def latency_ladder_text():
    """Version texte compacte de l'échelle (pour rapports/menu)."""
    out = ["Échelle de latence : 200 ms (CDN) → 120 ms (-40%) → 15 ms (edge)",
           "                    → 2 ms (NEXUS <50km, objectif contractuel)"]
    return out


# ═══════════════════════════════════════════════════════════════════════════
# MOTEUR — exécution d'actions, gardes, workflows, rapports
# ═══════════════════════════════════════════════════════════════════════════


class StudioEngine:
    """Charge le catalogue, exécute les actions, tient l'historique."""

    def __init__(self):
        self.quiet = False
        self.catalog = build_catalog()
        self.by_id = {a["id"]: a for a in self.catalog}
        self.ctx = {
            "engine": self,
            "catalog": self.catalog,
            "results": None,
            "depth": 0,
        }
        for d in (os.path.dirname(RESULTS_FILE), REPORTS_DIR, TMP_DIR):
            os.makedirs(d, exist_ok=True)
        ensure_workflows(self)

    # ─── Exécution d'une action ────────────────────────────────────────────
    def run_action(self, action_id):
        entry = self.by_id.get(action_id)
        if entry is None:
            return {"ok": False, "error": "action inconnue : %s" % action_id}
        fn = FNS.get(entry["fn"])
        if fn is None:
            return {"ok": False, "error": "primitive non enregistrée : %s" % entry["fn"]}
        t0 = time.perf_counter()
        try:
            res = fn(entry["params"], self.ctx) or {}
        except Exception as exc:  # noqa: BLE001
            res = {"ok": False, "error": "%s : %s" % (type(exc).__name__, exc)}
        duration = round((time.perf_counter() - t0) * 1000.0, 1)
        record = {
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "id": entry["id"], "cat": entry["cat"], "label": entry["label"],
            "ok": bool(res.get("ok")), "duration_ms": duration,
            "metrics": self._sanitize(res),
        }
        if "error" in res:
            record["error"] = str(res["error"])[:300]
        if res.get("passed") is not None:
            record["passed"] = bool(res.get("passed"))
        self._append_result(record)
        self._print_result(record)
        return record

    @staticmethod
    def _sanitize(res):
        out = {}
        for k, v in res.items():
            if k in ("ok", "passed", "error"):
                continue
            if k == "payload":
                out[k] = "<%d nœuds>" % len(v)
            elif isinstance(v, (list, dict)) and k in ("entries", "tail", "plan", "steps",
                                                       "results", "actions", "rows",
                                                       "checks", "modules"):
                out[k] = v if len(str(v)) < 1500 else "<tronqué>"
            elif isinstance(v, (int, float, str, bool, list, dict, type(None))):
                out[k] = v
        return out

    def _append_result(self, record):
        try:
            with open(RESULTS_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError:
            pass
        if self.ctx.get("results") is not None:
            self.ctx["results"].append(record)

    def _print_result(self, r):
        if self.quiet:
            return
        status = (GREEN + "✅" + NC) if r["ok"] else (RED + "❌" + NC)
        extra = ""
        m = r.get("metrics", {})
        for k in ("p99_ms", "p95_ms", "hit_ratio_pct", "rps", "cache_state",
                  "status_code", "rtt_p99_ms", "online", "speedup_x_p99",
                  "gate_factor", "detail"):
            if k in m:
                v = m[k]
                if k == "detail" and isinstance(v, str):
                    v = v[:48]
                extra += " %s=%s" % (k, v)
        if r.get("passed") is not None:
            extra += " | %s" % ("PASS" if r["passed"] else "FAIL")
        print("  %s %-12s %-44s %6.1fms%s" %
              (status, r["id"], r["label"][:44], r["duration_ms"], extra))

    # ─── Gardes (gates) ─────────────────────────────────────────────────────
    @staticmethod
    def check_gates(res, expect):
        checks = []
        for key, want in expect.items():
            got = None
            if key in ("p50_ms_max", "p95_ms_max", "p99_ms_max", "max_ms_max",
                       "rtt_p50_ms_max", "rtt_p99_ms_max"):
                metric = key.rsplit("_max", 1)[0]
                got = (res.get("metrics", {}) or {}).get(metric)
                ok = got is not None and got <= want
            elif key == "hit_ratio_min":
                got = (res.get("metrics", {}) or {}).get("hit_ratio_pct")
                ok = got is not None and got >= want
            elif key == "requests_min":
                got = (res.get("metrics", {}) or {}).get("requests")
                ok = got is not None and got >= want
            elif key == "rps_min":
                got = (res.get("metrics", {}) or {}).get("rps")
                ok = got is not None and got >= want
            elif key == "errors_max":
                got = (res.get("metrics", {}) or {}).get("errors")
                ok = got is not None and got <= want
            elif key == "status_code_is":
                got = (res.get("metrics", {}) or {}).get("status_code")
                ok = got == want
            elif key == "cache_state_is":
                got = (res.get("metrics", {}) or {}).get("cache_state")
                ok = got == want
            elif key == "ok_is":
                got = res.get("ok")
                ok = got == want
            elif key == "passed_is":
                got = res.get("passed")
                ok = got == want
            else:
                ok = False
            checks.append({"gate": key, "want": want, "got": got, "ok": bool(ok)})
        return checks

    # ─── Workflows ──────────────────────────────────────────────────────────
    def list_workflows(self, json_out=False):
        wf_dir = os.path.join(BASE_DIR, "workflows")
        out = []
        if os.path.isdir(wf_dir):
            for fn in sorted(os.listdir(wf_dir)):
                if fn.endswith(".json"):
                    try:
                        with open(os.path.join(wf_dir, fn), "r", encoding="utf-8") as f:
                            data = json.load(f)
                        out.append({"file": fn, "name": data.get("name", fn),
                                    "description": data.get("description", ""),
                                    "steps": len(data.get("steps", []))})
                    except (OSError, ValueError):
                        out.append({"file": fn, "name": fn, "description": "illisible",
                                    "steps": 0})
        if json_out:
            return {"ok": True, "workflows": out}
        print("  Workflows prédéfinis :")
        for w in out:
            print("   %-30s %2d étapes — %s" % (w["file"], w["steps"], w["description"]))
        return {"ok": True, "workflows": out}

    def describe_workflow(self, name):
        wf_dir = os.path.join(BASE_DIR, "workflows")
        path = name if name.endswith(".json") and os.path.exists(name) \
            else os.path.join(wf_dir, name + ".json")
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return {"file": os.path.basename(path), "name": data.get("name"),
                "description": data.get("description", ""),
                "stop_on_fail": data.get("stop_on_fail", True),
                "steps": [{"action": s.get("action"), "expect": s.get("expect"),
                           "label": s.get("label", "")} for s in data.get("steps", [])]}

    def run_workflow_file(self, path, strict=None):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return self.run_workflow(data, os.path.basename(path),
                                 strict if strict is not None else data.get("stop_on_fail", True))

    def run_predefined(self, name, strict=True):
        wf_dir = os.path.join(BASE_DIR, "workflows")
        path = os.path.join(wf_dir, name + ".json")
        if not os.path.exists(path):
            return {"ok": False, "error": "workflow inconnu : %s" % name}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return self.run_workflow(data, name, strict)

    def run_workflow(self, data, name, stop_on_fail=True):
        if self.ctx["depth"] >= 2:
            return {"ok": False, "error": "profondeur de workflows limitée à 2"}
        self.ctx["depth"] += 1
        try:
            steps = data.get("steps", [])
            results = []
            failed = False
            for i, step in enumerate(steps, 1):
                aid = step.get("action")
                label = step.get("label", "")
                print("  %s[%d/%d]%s %s %s" % (CYAN, i, len(steps), NC, aid, label))
                res = self.run_action(aid)
                gates = []
                if "expect" in step and res.get("ok"):
                    gates = self.check_gates(res, step["expect"])
                    res["gates"] = gates
                    if not all(g["ok"] for g in gates):
                        res["passed"] = False
                    else:
                        res["passed"] = res.get("passed", True)
                elif res.get("ok"):
                    res["passed"] = res.get("passed", True)
                results.append({"id": aid, "label": label, "ok": res.get("ok"),
                                "passed": res.get("passed"), "gates": gates})
                if not res.get("ok") or res.get("passed") is False:
                    failed = True
                    if stop_on_fail:
                        print("  %s⚠ Échec — arrêt (stop_on_fail).%s" % (YELLOW, NC))
                        break
            summary = {
                "ok": not failed, "workflow": name, "steps_run": len(results),
                "steps_total": len(steps),
                "passed_steps": sum(1 for r in results if r.get("passed")),
                "failed": failed,
            }
            self._write_workflow_report(name, data, results, summary)
            return summary
        finally:
            self.ctx["depth"] -= 1

    def _write_workflow_report(self, name, data, results, summary):
        os.makedirs(REPORTS_DIR, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = os.path.join(REPORTS_DIR, "workflow-%s-%s.md" % (name, ts))
        lines = ["# Workflow : %s" % name, "",
                 "**Description** : %s" % data.get("description", ""), "",
                 "**Verdict** : %s — %d/%d étapes réussies" % (
                     "✅ PASS" if summary["ok"] else "❌ FAIL",
                     summary["passed_steps"], summary["steps_total"]), "",
                 "| # | Action | Libellé | OK | Garde |", "|---|---|---|---|---|"]
        for i, r in enumerate(results, 1):
            gates = "; ".join("%s %s≤%s" % (g["gate"], g["got"], g["want"])
                              for g in r.get("gates", []) if "≤" in g["gate"]) \
                or "; ".join("%s=%s" % (g["gate"], g["got"]) for g in r.get("gates", [])) \
                or "—"
            lines.append("| %d | %s | %s | %s | %s |" % (
                i, r["id"], (r.get("label") or "")[:40],
                "✅" if r.get("ok") else "❌", gates))
        lines += ["", "Généré par NEXUS STUDIO v1.1 — %s" %
                  datetime.now().strftime("%Y-%m-%d %H:%M:%S"), ""]
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            print("  %sRapport : %s%s" % (DIM, path, NC))
        except OSError:
            pass

    def run_category(self, cat_id, limit=3):
        acts = [a for a in self.catalog if a["cat"] == cat_id][:limit]
        if not acts:
            return {"ok": False, "error": "catégorie inconnue : %s" % cat_id}
        ok_n = 0
        for a in acts:
            r = self.run_action(a["id"])
            if r.get("ok"):
                ok_n += 1
        return {"ok": ok_n == len(acts), "category": cat_id, "run": len(acts),
                "ok_count": ok_n}


# ═══════════════════════════════════════════════════════════════════════════
# Workflows prédéfinis — auto-régénérés (IDs toujours alignés au catalogue)
# Les fichiers personnalisés de l'utilisateur ne sont jamais touchés.
# ═══════════════════════════════════════════════════════════════════════════

WORKFLOWS_BUILTIN = {
    "smoke_test": {
        "name": "smoke_test",
        "description": "Validation rapide (~15s) : nœud en ligne, cache chaud, "
                       "latence ≤ 2ms, résilience de base",
        "stop_on_fail": True,
        "steps": [
            {"action": "PROBE-001", "label": "Santé du nœud", "expect": {"ok_is": True}},
            {"action": "CACHE-001", "label": "Warm-up jQuery", "expect": {"passed_is": True}},
            {"action": "LAT-002", "label": "Bench Edge 30 échantillons",
             "expect": {"p99_ms_max": 2.0, "hit_ratio_min": 90.0}},
            {"action": "HDR-002", "label": "X-Nexus-Cache = HIT",
             "expect": {"passed_is": True}},
            {"action": "HTTP-001", "label": "Statut 200", "expect": {"status_code_is": 200}},
            {"action": "HTTP-013", "label": "HEAD cohérent avec GET",
             "expect": {"passed_is": True}},
            {"action": "RESIL-001", "label": "Stale-if-error (origine coupée)",
             "expect": {"passed_is": True}},
            {"action": "LAT-046", "label": "Garde contractuelle p99 ≤ 2ms",
             "expect": {"passed_is": True}},
            {"action": "RPT-014", "label": "Synthèse de session"},
        ],
    },
    "pitch_demo": {
        "name": "pitch_demo",
        "description": "Démonstration pour revue Oracle / Google : flotte, warm-up, "
                       "Edge vs Origine, garde 2ms, intégrité, résilience, charge, "
                       "qualité 2× Vercel",
        "stop_on_fail": False,
        "steps": [
            {"action": "FLEET-001", "label": "Vue de flotte (nœuds en ligne)"},
            {"action": "CACHE-037", "label": "Warm-up des 6 assets critiques"},
            {"action": "LAT-003", "label": "Bench Edge jQuery ×100",
             "expect": {"p99_ms_max": 2.0}},
            {"action": "LAT-025", "label": "Bench Origine CDN (comparaison)"},
            {"action": "LAT-049", "label": "Garde RTT p99 ≤ 2ms",
             "expect": {"passed_is": True}},
            {"action": "HTTP-019", "label": "Intégrité octets Edge = Origine",
             "expect": {"passed_is": True}},
            {"action": "RESIL-001", "label": "Stale-if-error : qualité de service",
             "expect": {"passed_is": True}},
            {"action": "LOAD-001", "label": "Charge Edge 10 workers",
             "expect": {"errors_max": 5, "rps_min": 100}},
            {"action": "DEPLOY-016", "label": "Qualité 2× Vercel (mesure live)",
             "expect": {"passed_is": True}},
            {"action": "RPT-009", "label": "Rapport de bench"},
            {"action": "RPT-011", "label": "Rapport d'acceptation datacenter"},
        ],
    },
    "acceptance_datacenter": {
        "name": "acceptance_datacenter",
        "description": "Suite d'acceptation datacenter (~90s) : config, sondes, "
                       "latence contractuelle, en-têtes, intégrité, résilience, "
                       "robustesse, charge, déploiement, rapports",
        "stop_on_fail": True,
        "steps": [
            {"action": "CFG-001", "label": "Configuration JSON valide",
             "expect": {"passed_is": True}},
            {"action": "CFG-002", "label": "Section node complète",
             "expect": {"passed_is": True}},
            {"action": "CFG-003", "label": "Section cache complète",
             "expect": {"passed_is": True}},
            {"action": "PROBE-001", "label": "Santé du nœud", "expect": {"ok_is": True}},
            {"action": "PROBE-006", "label": "Métriques live"},
            {"action": "CACHE-037", "label": "Préchargement des 6 assets"},
            {"action": "LAT-004", "label": "Bench Edge jQuery ×300",
             "expect": {"p99_ms_max": 2.0, "hit_ratio_min": 90.0}},
            {"action": "LAT-046", "label": "Garde contractuelle p99 ≤ 2ms",
             "expect": {"passed_is": True}},
            {"action": "HDR-002", "label": "X-Nexus-Cache = HIT",
             "expect": {"passed_is": True}},
            {"action": "HDR-003", "label": "X-Nexus-Latency ≤ 2ms",
             "expect": {"passed_is": True}},
            {"action": "HTTP-019", "label": "Intégrité octets Edge = Origine",
             "expect": {"passed_is": True}},
            {"action": "HTTP-025", "label": "Chemin inconnu → 502 propre",
             "expect": {"passed_is": True}},
            {"action": "RESIL-005", "label": "Origine morte + cache vide → 502",
             "expect": {"passed_is": True}},
            {"action": "RESIL-007", "label": "Récupération origine → rechargement",
             "expect": {"passed_is": True}},
            {"action": "RESIL-011", "label": "Churn 25 connexions",
             "expect": {"passed_is": True}},
            {"action": "RESIL-021", "label": "Robustesse requête garbage",
             "expect": {"passed_is": True}},
            {"action": "LOAD-001", "label": "Charge Edge légère",
             "expect": {"errors_max": 5, "rps_min": 100}},
            {"action": "DEPLOY-002", "label": "Prérequis machine (standard)",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-013", "label": "Garde GO-LIVE 2× Vercel",
             "expect": {"passed_is": True}},
            {"action": "RPT-022", "label": "Archive des rapports"},
            {"action": "RPT-011", "label": "Rapport d'acceptation final"},
        ],
    },
    "dc_readiness": {
        "name": "dc_readiness",
        "description": "Prêt pour le datacenter (~30s) : prérequis, intégrité des "
                       "modules v1.0, config, ports, unité systemd, checklist, "
                       "garde go-live 2× Vercel",
        "stop_on_fail": True,
        "steps": [
            {"action": "DEPLOY-002", "label": "Prérequis machine (standard)",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-005", "label": "Modules v1.0 inventaire",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-006", "label": "Modules v1.0 intégrité",
             "expect": {"passed_is": True}},
            {"action": "CFG-001", "label": "Configuration JSON valide",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-023", "label": "Port 8801 libre (nœud additionnel)"},
            {"action": "DEPLOY-008", "label": "Unité systemd (render)"},
            {"action": "DEPLOY-018", "label": "Spec pare-feu (ufw)"},
            {"action": "DEPLOY-019", "label": "Spec logrotate"},
            {"action": "DEPLOY-011", "label": "Checklist mise en prod (full)",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-013", "label": "Garde GO-LIVE 2× Vercel",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-016", "label": "Comparaison Vercel (live)",
             "expect": {"passed_is": True}},
            {"action": "DEPLOY-025", "label": "Paquet de déploiement (zip)"},
            {"action": "RPT-017", "label": "Synthèse de mise en prod (md)"},
        ],
    },
}


def ensure_workflows(engine):
    """(Re)génère les workflows prédéfinis si absents ou désalignés."""
    wf_dir = os.path.join(BASE_DIR, "workflows")
    os.makedirs(wf_dir, exist_ok=True)
    for name, data in WORKFLOWS_BUILTIN.items():
        path = os.path.join(wf_dir, name + ".json")
        need = True
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    cur = json.load(f)
                need = cur != data
                if not need:
                    for s in cur.get("steps", []):
                        if s.get("action") not in engine.by_id:
                            need = True
                            break
            except (OSError, ValueError):
                need = True
        if need:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write("\n")
            except OSError:
                pass


# ═══════════════════════════════════════════════════════════════════════════
# GUIDE INTÉGRÉ — pitch, déploiement, latence, FAQ (textes de vente)
# ═══════════════════════════════════════════════════════════════════════════

GUIDE_DOCS = {
    "latency": """
 POURQUOI 1-2 ms EST POSSIBLE — L'ARGUMENTAIRE LATENCE
 ═══════════════════════════════════════════════════════
  Une requête CDN classique paie quatre voyages réseau :

    DNS        ~10-30 ms   résolution du nom
    TCP        ~30 ms      ouverture de connexion (1 aller-retour)
    TLS        ~90 ms      poignée de main chiffrée (2 aller-retours)
    TTFB       ~70 ms      première octet utile
    ─────────────────────
    TOTAL      ~200 ms     c'est EXACTEMENT le 200 ms mesuré sur Vercel

  Le chemin NEXUS supprime tout, par construction :

    • micro-nœuds à <50 km   → la lumière ne fait que ~0,2 ms de fibre
    • connexions persistantes (keep-alive) → zéro nouveau handshake
    • cache 100% RAM + préchauffage au démarrage (warm-up)
    • stale-if-error → l'origine peut tomber, l'edge reste serein

  Résultat mesuré sur votre machine : p99 ≈ 1,5 ms (144× plus rapide
  que l'origine 17 ms, ~130× plus rapide que le CDN à 200 ms).

  Le contrat NEXUS : p99 ≤ 2 ms à <50 km. Le Studio le vérifie à chaque
  exécution via les gardes LAT-045..047 et DEPLOY-013.
""",
    "deploy": """
 DÉPLOIEMENT DATACENTER — PROCÉDURE OPÉRATIONNELLE
 ═══════════════════════════════════════════════════
  1. Prérequis              DEPLOY-001..004   (RAM, disque, CPU, Python)
  2. Intégrité modules      DEPLOY-005..007   (v1.0 inchangé, empreintes)
  3. Configuration          CFG-001..005      (validation structurelle)
  4. Ports                  DEPLOY-023..024   (liberté pour nouveaux nœuds)
  5. Service système        DEPLOY-008..010   (unité systemd générée)
  6. Réseau                 DEPLOY-018        (spec pare-feu générée)
  7. Journaux               DEPLOY-019        (logrotate généré)
  8. Checklist              DEPLOY-011..012   (cases cochées depuis l'état réel)
  9. Garde GO-LIVE          DEPLOY-013        (p95 ≤ 100 ms = 2× Vercel)
 10. Preuve                 DEPLOY-016..017   (comparaison Vercel live)
 11. Paquet de revue        DEPLOY-025        (zip des rapports)

  Tout est génératif : le Studio écrit des fichiers de spécification dans
  studio/reports/ et n'exécute aucune commande système privilégiée.
  L'installation systemd/pare-feu reste une décision humaine signée.
""",
    "pitch": """
 SCRIPT DE PITCH — 5 MINUTES POUR CONVAINCRE ORACLE / GOOGLE
 ════════════════════════════════════════════════════════════
  [0:00] L'accroche
     « Votre CDN livre en 200 ms. Nous livrons en 2 ms.
       Même matériel, même réseau — une architecture différente. »

  [0:45] La preuve vivante (terminal projeté)
     $ bash run_studio_demo.sh
     → l'écran temps réel s'ouvre : état, cache, p50/p95/p99 live
     → gardez la page 1 pendant tout le pitch

  [2:00] La démolition de l'objection « c'est la physique »
     --guide latency     (DNS/TCP/TLS/TTFB : 200 ms s'expliquent,
                          2 ms aussi — tout est dans la conception)

  [3:00] Le workflow qui imprime le dossier
     $ python3 nexus_studio.py --workflow pitch_demo
     → 11 étapes, gardes automatiques, rapport .md horodaté
     → la ligne « Qualité 2× Vercel : PASS » vient de tourner chez vous

  [4:00] La clôture
     « Vos SLA promettent des millisecondes. Nous les mesurons,
       les enregistrons et les livrons signés. Pilotons un pilote
       30 jours sur une région — vos ingénieurs gardent la main. »

  Arme secrète : DEPLOY-016/017 — la comparaison Vercel s'exécute
  chez le prospect, sur SA machine, avec SES yeux.
""",
    "faq": """
 FAQ — LES 8 OBJECTIONS ET LEUR RÉPONSE
 ═══════════════════════════════════════
  1. « 2 ms, c'est impossible. »
     → La lumière fait 0,2 ms sur 50 km de fibre. Le reste était du
       protocole, pas de la physique. Garde LAT-046 à l'appui.
  2. « Et si l'origine tombe ? »
     → stale-if-error : l'edge sert le cache frais ou périmé.
       Scénarios RESIL-001..010, y compris origine morte + cache vide.
  3. « Et le cache qui se vide ? »
     → 100% RAM + warm-up au démarrage + vérification CACHE-037/038.
  4. « Ça tient en charge ? »
     → LOAD-001..040 : montées en charge, soaks 5 min, rampe par paliers.
  5. « C'est sécurisé ? »
     → /nexus/shutdown réservé localhost (conçu v1.0), checklist
       DEPLOY-012, requêtes malformées RESIL-016..025.
  6. « Zéro dépendance = zéro support ? »
     → Python 3.8 stdlib uniquement. Pas de supply-chain, pas de CVE
       transitives. DEPLOY-006 le prouve à chaque audit.
  7. « Pourquoi pas NVIDIA/special hardware ? »
     → nexus-smi surveille sans GPU : CPU-only, n'importe quel serveur DC.
  8. « Qui l'a validé ? »
     → acceptance_datacenter (21 étapes) + vos rapports horodatés
       studio/reports/ — c'est VOTRE dossier de preuve.
""",
    "workflows": """
 LES 4 WORKFLOWS PRÉDÉFINIS
 ═══════════════════════════
  smoke_test            (~15 s) validation quotidienne : santé, cache,
                        p99 ≤ 2 ms, stale-if-error, synthèse.
  pitch_demo            (~40 s) démo commerciale : flotte, Edge vs Origine,
                        intégrité, charge, qualité 2× Vercel, rapport.
  acceptance_datacenter (~90 s) acceptation formelle : 21 étapes couvrant
                        9 catégories + garde go-live + archive zip.
  dc_readiness          (~30 s) prêt datacenter : prérequis, modules,
                        systemd, pare-feu, checklist, go-live.

  Format : JSON simple (steps + expect). Créez les vôtres dans
  workflows/ — le Studio ne touche jamais aux fichiers personnalisés.
""",
    "metrics": """
 LIRE LES MÉTRIQUES — GLOSSAIRE DU PILOTAGE
 ═══════════════════════════════════════════
  TTFB      Time To First Byte. LE chiffre qui décide de la perception
            de vitesse. C'est lui que le CDN facture à 200 ms.
  p50       La médiane : la moitié des requêtes va plus vite.
            C'est votre « expérience typique ».
  p95       95% des requêtes plus rapides. C'est LE chiffre contractuel
            des SLA sérieux — et la base de la garde 2× Vercel.
  p99       99% plus rapides. Le pire cas sur 100 requêtes.
            Objectif NEXUS : ≤ 2 ms (garde LAT-045..047).
  hit_ratio Part des requêtes servies depuis la RAM sans toucher
            l'origine. 100% après warm-up (CACHE-019..024).
  rps       Requêtes par seconde soutenues (LOAD-001..040).
  evictions Éléments chassés du cache par manque de place
            (max_entries / max_body_bytes de config/nexus.json).
  stale     Réponse périmée servie faute de mieux quand l'origine
            est en panne — meilleure qu'une erreur 502.
  uptime_s  Ancienneté du processus nexusd (PROBE-011..015).

  Sur l'écran temps réel (page 1), ces chiffres sont vivants, et le
  p99 se trace en sparkline : c'est votre tableau de bord de vente.
""",
    "roadmap": """
 FEUILLE DE ROUTE — DU STUDIO AU CONTRAT 1-2 ms
 ═══════════════════════════════════════════════
  v1.0 — AUJOURD'HUI (livré, testé, mesuré)
     nexusd asyncio, cache RAM, keep-alive, warm-up, stale-if-error,
     nexus-smi sans GPU, 400 actions Studio, écran temps réel,
     qualité 2× Vercel vérifiée par gardes automatiques.

  v1.5 — CONSOLIDATION
     TLS terminaison edge, réplication gossip inter-nœuds,
     persistance du warm-up (fichier), métriques Prometheus.

  v2.0 — PERFORMANCE NATIVE
     Portage du plan de données en Go/Rust (le Python garde le
     contrôle), objectif <1 ms p99, 50k RPS par nœud.

  v3.0 — TISSU URBAIN
     Micro-nœuds chez les ISP, anycast BGP, routage par latence
     réelle, SLA contractuel 1-2 ms à <50 km, tableau de bord client.

  Chaque étape reste vérifiable par le même arsenal : les gardes
  LAT/DEPLOY et les workflows d'acceptation ne changent pas —
  seuls les chiffres s'améliorent. C'est votre escalier vers 1 ms.
""",
    "archi": """
 ARCHITECTURE INTERNE — CE QUI REND 2 ms POSSIBLE
 ═════════════════════════════════════════════════
  PLAN DE DONNÉES (nexusd.py, v1.0 inchangé)
    • serveur asyncio HTTP/1.1 — une boucle, zéro thread par requête
    • connexions persistantes : le client paie TCP/TLS une fois,
      puis des centaines de requêtes ne coûtent que le voyage lumière
    • cache 100% RAM (dict + TTL) : aucune écriture disque au chemin chaud
    • warm-up au démarrage : les 6 assets critiques sont en RAM AVANT
      le premier client (vérifié par CACHE-037/038)
    • stale-if-error : l'origine morte ne dégrade pas l'edge
      (scénarios RESIL-001..010, y compris rechargement au retour)

  PLAN DE CONTRÔLE (ce fichier — nexus_studio.py)
    • 400 actions = 73 primitives paramétrées, jamais de doublon de code
    • catalogue numéroté PROBE-001 … DEPLOY-030 avec contrôle d'intégrité
      au chargement (tout désalignement = refus de démarrer)
    • gardes contractuelles : une action mesure ET asserte
      (p99 ≤ 2 ms, p95 ≤ 100 ms = 2× Vercel, hit ≥ 90%…)
    • workflows JSON : étapes + expect — lisible par un ingénieur client
    • historique JSONL + rapports horodatés : chaque mesure est une preuve

  POURQUOI PYTHON STDLIB
    • zéro dépendance = zéro supply-chain, zéro CVE transitive
    • n'importe quel serveur DC avec Python 3.8 : pas de compilation,
      pas de GPU (nexus-smi le prouve), pas de conteneur obligatoire
    • la limite Python (~1 ms par réponse RAM) est au-dessus de la
      cible p99 2 ms — et v2.0 porte le plan de données en Go/Rust

  LA BORNE PHYSIQUE
    • fibre : ~0,2 ms pour 50 km — le reste du budget 2 ms est du
      logiciel pur. C'est le fondement du modèle « micro-nœuds <50 km ».
""",
    "sales": """
 DOSSIER COMMERCIAL — ARGUMENTS CHIFFRÉS POUR LES GÉANTS
 ══════════════════════════════════════════════════════════
  LA PROMESSE
    « Vos CDN promettent des millisecondes. Nous les mesurons,
      les enregistrons et les livrons signés : p99 ≤ 2 ms à <50 km,
      qualité de déploiement 2× Vercel vérifiée à chaque go-live. »

  LES PREUVES (déjà sur votre machine, rejouables devant eux)
    • VERCEL 200 ms vs NEXUS ~0,2-1,5 ms → gain ×130 à ×700 (DEPLOY-016)
    • p99 1,52 ms vs origine 17,32 ms → ×144 (bench v1, côté client)
    • hit_ratio 100% après warm-up (CACHE-019..024)
    • origine morte : service continu (RESIL-001..010)
    • 400 actions d'audit + workflows d'acceptation signés (RPT-011)

  LES OBJECTIONS FROIDES → RÉPONSES CHAUDES
    « On a déjà un CDN »
        → Nous COMPLÉTONS le CDN : l'origine reste chez eux, nous
          absorbons le chemin chaud <50 km. Pilote 30 jours, sans
          engagement, preuve chiffrée à chaque étape.
    « Qui êtes-vous ? »
        → Le Studio EST la réponse : le dossier de preuve s'exécute
          chez eux, sur leur machine, sans accès réseau sortant.
    « Ça ne passe pas à l'échelle »
        → Capacité extrapolée par nœud (DEPLOY-021) + modèle linéaire
          par micro-nœuds : on ajoute des nœuds, on ne diminue pas
          les serveurs. Le registre (FLEET) gère déjà la flotte.
    « Le support ? »
        → Zéro dépendance = surface de panne minimale. Les 400 actions
          sont aussi l'outil de diagnostic de votre équipe NOC.

  LA CLÔTURE EN 3 PHRASES
    1. « Vos ingénieurs ont vu les chiffres tourner en direct. »
    2. « Le SLA s'écrit : p99 ≤ 2 ms, vérifié par nos gardes, pas promis. »
    3. « On démarre un pilote 30 jours sur une région ? »
""",
    "quickstart": """
 PRIS EN MAIN — DE LA COPIE DU FICHIER AU PREMIER PITCH
 ═══════════════════════════════════════════════════════
  1. Copier nexus_studio.py DANS votre dossier nexus-edge v1.0
     existant (à côté de nexusd.py, nexus-ctl.py, nexus-smi.py,
     nexus-bench.py). Ne remplacez rien d'autre.

  2. Vérifier l'installation (10 secondes)
     $ python3 nexus_studio.py --selftest
     → « Catalogue valide — 400 actions, 12 catégories »
     Si les modules v1.0 manquent, DEPLOY-005 vous dira lequel.

  3. Première démonstration complète (2 minutes)
     $ bash run_studio_demo.sh
     → selftest, nœud, cache chaud, garde 2× Vercel, pitch, écran

  4. Travailler au quotidien
     $ python3 nexus_studio.py --menu        console
     $ python3 nexus_studio.py --screen      écran temps réel (q sort)

  5. Avant une réunion client
     $ python3 nexus_studio.py --workflow dc_readiness
     $ python3 nexus_studio.py --workflow pitch_demo
     $ python3 nexus_studio.py --report      vos preuves horodatées

  Aucune étape ne touche aux modules v1.0. Le nœud démarre via
  nexus-ctl (inchangé) et tourne en fond après la démo.
""",
    "dossier": """
 LE DOSSIER DE PREUVE — CE QUE VOUS IMPRIMEZ POUR ORACLE / GOOGLE
 ══════════════════════════════════════════════════════════════════
  Après un pitch_demo + dc_readiness, studio/reports/ contient :

    workflow-pitch_demo-<date>.md      verdict étape par étape
    workflow-dc_readiness-<date>.md    état des garde-fous déploiement
    bench-report.txt/md                p50/p95/p99 mesurés
    acceptance.md                      rapport d'acceptation formel
    summary.txt/md                     synthèse de session
    nexusd.service.txt                 unité systemd prête à installer
    firewall-spec.txt / logrotate-nexusd.conf   specs opérationnelles
    topology.txt                       schéma du datacenter
    capacity.txt                       RPS → millions de requêtes/jour
    nexus-studio-reports.zip           TOUT, archivé (DEPLOY-025)

  La séquence gagnante (3 commandes) :
    $ python3 nexus_studio.py --workflow dc_readiness
    $ python3 nexus_studio.py --workflow pitch_demo
    $ python3 nexus_studio.py --run DEPLOY-025

  Imprimez les .md, joignez le zip, et le SLA s'écrit tout seul :
  p99 ≤ 2 ms, garde 2× Vercel PASS — datés, rejouables, signés.
""",
}


def do_guide(subject=None):
    subjects = list(GUIDE_DOCS.keys())
    if subject in (None, "", "sommaire"):
        print_header("NEXUS STUDIO — GUIDE INTÉGRÉ")
        print("  Sujets disponibles :")
        for s in subjects:
            title = GUIDE_DOCS[s].strip().splitlines()[0].strip()
            title = title.split(" — ", 1)[-1] if " — " in title else title
            print("   • %-10s %s" % (s, title))
        print("\n  Lire : python3 nexus_studio.py --guide %s" % "<%s>" % "|".join(subjects))
        return 0
    doc = GUIDE_DOCS.get(subject)
    if doc is None:
        print("%s❌ Sujet inconnu : %s%s (choix : %s)" %
              (RED, subject, NC, ", ".join(subjects)))
        return 1
    print(doc)
    return 0


# ═══════════════════════════════════════════════════════════════════════════
# CONSOLE INTERACTIVE + CLI
# ═══════════════════════════════════════════════════════════════════════════

def print_header(title):
    print("%s════════════════════════════════════════════════════════════════════════%s" % (CYAN, NC))
    print("%s  %s%s" % (CYAN, title, NC))
    print("%s════════════════════════════════════════════════════════════════════════%s" % (CYAN, NC))


def print_banner():
    art = [
        "███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗",
        "████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔════╝",
        "██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗    ███████╗   ██║   ██║   ██║██████╔╝██║██║     ",
        "██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║    ╚════██║   ██║   ██║   ██║██╔═══╝ ██║██║     ",
        "██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║    ███████║   ██║   ╚██████╔╝██║     ██║╚██████╗",
        "╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝ ╚═════╝",
    ]
    print("%s%s%s" % (CYAN, "\n".join(art), NC))
    print("  %sSTUDIO DATACENTER PRO v1.1%s — 400 actions · 4 workflows · écran temps réel" % (BOLD, NC))
    print("  %sModules nexus-edge v1.0 : inchangés%s — qualité de déploiement 2× Vercel\n" % (DIM, NC))


def do_selftest(engine):
    print_header("NEXUS STUDIO — SELFTEST")
    counts = {}
    for a in engine.catalog:
        counts[a["cat"]] = counts.get(a["cat"], 0) + 1
    ids = [a["id"] for a in engine.catalog]
    problems = []
    if len(ids) != 400:
        problems.append("total=%d" % len(ids))
    if len(set(ids)) != len(ids):
        problems.append("IDs dupliqués")
    for a in engine.catalog:
        if a["fn"] not in FNS:
            problems.append("fn manquant : %s" % a["fn"])
        try:
            json.dumps(a["params"])
        except (TypeError, ValueError):
            problems.append("params non sérialisables : %s" % a["id"])
    wf_dir = os.path.join(BASE_DIR, "workflows")
    wf_count = 0
    if os.path.isdir(wf_dir):
        for fn in sorted(os.listdir(wf_dir)):
            if not fn.endswith(".json"):
                continue
            wf_count += 1
            try:
                with open(os.path.join(wf_dir, fn), "r", encoding="utf-8") as f:
                    data = json.load(f)
                for s in data.get("steps", []):
                    if s.get("action") not in engine.by_id:
                        problems.append("%s : action %s inconnue" % (fn, s.get("action")))
            except (OSError, ValueError) as exc:
                problems.append("%s : %s" % (fn, exc))
    for c, n in sorted(counts.items()):
        print("  %-7s %3d actions  — %s" % (c, n, CAT_NAMES.get(c, "")))
    print("  %-7s %3d actions" % ("TOTAL", len(ids)))
    print("  workflows prédéfinis : %d" % wf_count)
    if problems:
        print("%s  ❌ PROBLÈMES : %s%s" % (RED, "; ".join(problems[:5]), NC))
        return 1
    print("%s  ✅ Catalogue valide — 400 actions, 12 catégories, %d primitives%s" %
          (GREEN, len(FNS), NC))
    return 0


def do_list(engine, cat=None, json_out=False):
    if cat is None:
        counts = {}
        for a in engine.catalog:
            counts[a["cat"]] = counts.get(a["cat"], 0) + 1
        if json_out:
            print(json.dumps({"total": len(engine.catalog),
                              "categories": [
                                  {"id": c, "name": CAT_NAMES.get(c, ""),
                                   "actions": n} for c, n in sorted(counts.items())]},
                             indent=2, ensure_ascii=False))
            return 0
        print_header("NEXUS STUDIO — CATÉGORIES (400 actions)")
        for c, n in sorted(counts.items()):
            print("  %-7s %3d — %s" % (c, n, CAT_NAMES.get(c, "")))
        print("  %-7s %3d" % ("TOTAL", len(engine.catalog)))
        print("\n  %sDétail : python3 nexus_studio.py --list LAT%s" % (DIM, NC))
        return 0
    acts = [a for a in engine.catalog if a["cat"] == cat.upper()]
    if not acts:
        print("%s❌ Catégorie inconnue : %s%s" % (RED, cat, NC))
        return 1
    if json_out:
        print(json.dumps(acts, indent=2, ensure_ascii=False))
        return 0
    print_header("NEXUS STUDIO — %s : %s (%d actions)" %
                 (cat.upper(), CAT_NAMES.get(cat.upper(), ""), len(acts)))
    for a in acts:
        print("  %-11s %-50s %s" % (a["id"], a["label"][:50], a["desc"][:38]))
    return 0


def do_search(engine, term):
    term_l = term.lower()
    hits = [a for a in engine.catalog
            if term_l in a["label"].lower() or term_l in a["desc"].lower()
            or term_l in a["id"].lower()]
    print_header("NEXUS STUDIO — RECHERCHE « %s » (%d)" % (term, len(hits)))
    for a in hits[:60]:
        print("  %-11s %-50s %s" % (a["id"], a["label"][:50], a["desc"][:38]))
    if len(hits) > 60:
        print("  … %d autres" % (len(hits) - 60))
    return 0


def do_run(engine, ids_str):
    ids = [x.strip() for x in ids_str.split(",") if x.strip()]
    print_header("NEXUS STUDIO — EXÉCUTION")
    ok_n = 0
    for aid in ids:
        r = engine.run_action(aid)
        if r.get("ok"):
            ok_n += 1
    print("  %s%d/%d action(s) réussie(s)%s" % (GREEN if ok_n == len(ids) else YELLOW,
                                                ok_n, len(ids), NC))
    return 0 if ok_n == len(ids) else 1


def do_info(engine, action_id):
    a = engine.by_id.get(action_id.strip().upper())
    if a is None:
        print("%s❌ Action inconnue : %s%s" % (RED, action_id, NC))
        return 1
    print_header("NEXUS STUDIO — ACTION %s" % a["id"])
    print("  catégorie : %-7s %s" % (a["cat"], CAT_NAMES.get(a["cat"], "")))
    print("  libellé   : %s" % a["label"])
    print("  détail    : %s" % a["desc"])
    print("  primitive : %s" % a["fn"])
    print("  paramètres: %s" % json.dumps(a["params"], ensure_ascii=False))
    hist = [r for r in load_results(500) if r.get("id") == a["id"]]
    if hist:
        last = hist[-1]
        print("  dernière exécution : %s — %s (%.1f ms)" % (
            last.get("ts", ""), "✅ ok" if last.get("ok") else "❌ échec",
            last.get("duration_ms", 0)))
    else:
        print("  dernière exécution : %sjamais exécutée%s" % (DIM, NC))
    print("  exécution : python3 nexus_studio.py --run %s" % a["id"])
    return 0


def do_history(engine, n=20):
    res = load_results(max(1, n))
    print_header("NEXUS STUDIO — HISTORIQUE (%d derniers)" % len(res))
    for r in res[-n:]:
        mark = GREEN + "✅" + NC if r.get("ok") else RED + "❌" + NC
        print("  %s %s %-8s %-42s %6.1fms" % (
            mark, r.get("ts", ""), r.get("id", "?"),
            (r.get("label") or "")[:42], r.get("duration_ms", 0)))
    return 0


def do_report(engine):
    print_header("NEXUS STUDIO — RAPPORTS (studio/reports/)")
    if not os.path.isdir(REPORTS_DIR):
        print("  %saucun rapport encore — lancez un workflow%s" % (DIM, NC))
        return 0
    files = sorted(os.listdir(REPORTS_DIR))
    if not files:
        print("  %saucun rapport encore — lancez un workflow%s" % (DIM, NC))
        return 0
    for fn in files[-15:]:
        path = os.path.join(REPORTS_DIR, fn)
        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0
        print("  %-52s %6.1f Ko" % (fn[:52], size / 1024.0))
    latest_wf = [f for f in files if f.startswith("workflow-") and f.endswith(".md")]
    if latest_wf:
        path = os.path.join(REPORTS_DIR, latest_wf[-1])
        print("\n  %sDernier verdict de workflow (%s) :%s" % (BOLD, latest_wf[-1], NC))
        try:
            with open(path, "r", encoding="utf-8") as f:
                rows = f.read().splitlines()
            for line in rows:
                if line.startswith("**Verdict**") or line.startswith("# Workflow"):
                    print("    %s" % line)
            shown = 0
            for line in rows:
                if line.startswith("|") and shown <= 12:
                    print("    %s" % line)
                    shown += 1
        except OSError:
            pass
    return 0


def do_workflow(engine, name):
    wf_dir = os.path.join(BASE_DIR, "workflows")
    path = name if os.path.exists(name) else os.path.join(wf_dir, name + ".json")
    if not os.path.exists(path):
        print("%s❌ Workflow introuvable : %s%s" % (RED, name, NC))
        engine.list_workflows()
        return 1
    print_header("NEXUS STUDIO — WORKFLOW : %s" % os.path.basename(path))
    res = engine.run_workflow_file(path)
    print("  → verdict : %s (%d/%d étapes)" % (
        "✅ PASS" if res.get("ok") else "❌ FAIL",
        res.get("passed_steps", 0), res.get("steps_total", 0)))
    return 0 if res.get("ok") else 1


def do_demo(engine, interactive=None):
    """Séquence de démonstration complète — la commande des grandes réunions."""
    if interactive is None:
        interactive = sys.stdin.isatty()
    print_banner()
    print_header("DÉMO DATACENTER PRO — SÉQUENCE COMPLÈTE")
    print("  %s[1/5] Catalogue%s" % (BOLD, NC))
    counts = {}
    for a in engine.catalog:
        counts[a["cat"]] = counts.get(a["cat"], 0) + 1
    print("  400 actions dans %d catégories : %s" % (
        len(counts), ", ".join("%s(%d)" % (c, n) for c, n in sorted(counts.items()))))
    print("  %s[2/5] Nœud edge (modules v1.0, inchangés)%s" % (BOLD, NC))
    engine.run_action("PROBE-001")
    print("  %s[3/5] Cache chaud + latence%s" % (BOLD, NC))
    engine.run_action("CACHE-037")
    engine.run_action("LAT-002")
    print("  %s[4/5] Qualité de déploiement 2× Vercel%s" % (BOLD, NC))
    engine.run_action("DEPLOY-013")
    engine.run_action("DEPLOY-016")
    print("  %s[5/5] Pitch visuel%s" % (BOLD, NC))
    show_pitch(engine, wait_key=interactive)
    print("  %sÉcran temps réel (q pour quitter) — %s%s" % (
        BOLD, "interactif" if interactive else "une frame (sortie non interactive)", NC))
    Screen(engine).run(once=not interactive)
    print_header("FIN DE DÉMO — LE DOSSIER DE PREUVE EST DANS studio/reports/")
    try:
        files = sorted(os.listdir(REPORTS_DIR))
        if files:
            print("  %d rapport(s) disponible(s) — derniers :" % len(files))
            for fn in files[-6:]:
                print("   • %s" % fn)
    except OSError:
        pass
    print("  workflow complet : python3 nexus_studio.py --workflow pitch_demo")
    print("  dossier de preuve : python3 nexus_studio.py --guide dossier")
    return 0


def do_node_toggle(engine):
    """Menu 13 : démarre le nœud s'il est arrêté, l'arrête s'il tourne
    — toujours via nexus-ctl (module v1.0, inchangé)."""
    url = default_node_url().rstrip("/")
    online = http_ok(url + "/nexus/health", 1.0)
    action = "stop" if online else "start"
    try:
        confirm = input("  Le nœud est %s. Confirmez « %s » (o/N) : " % (
            "en ligne" if online else "arrêté", action)).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return
    if confirm not in ("o", "oui", "y"):
        print("  annulé")
        return
    try:
        out = subprocess.run(
            [sys.executable, os.path.join(BASE_DIR, "nexus-ctl.py"), action],
            cwd=BASE_DIR, capture_output=True, text=True, timeout=40)
        tail = (out.stdout or out.stderr or "").strip().splitlines()[-6:]
        for ln in tail:
            print("  | %s" % ln)
    except (OSError, subprocess.TimeoutExpired) as exc:
        print("  %serreur : %s%s" % (RED, exc, NC))
        return
    online_after = http_ok(url + "/nexus/health", 1.5)
    state = "en ligne" if online_after else "arrêté"
    print("  → nœud %s : %s" % (action, (GREEN + state + NC) if online_after
                                     else (YELLOW + state + NC)))


def do_doctor(engine):
    """Diagnostic instantané de l'installation — 8 contrôles, aucune action."""
    print_header("NEXUS STUDIO — DOCTOR (diagnostic instantané)")
    checks = []
    # 1. catalogue
    checks.append(("Catalogue 400 actions", len(engine.catalog) == 400,
                   "%d actions, %d catégories" % (len(engine.catalog), len(set(a['cat'] for a in engine.catalog)))))
    # 2. modules v1.0
    mods = ["nexusd.py", "nexus-ctl.py", "nexus-smi.py", "nexus-bench.py",
            "config/nexus.json"]
    missing = [m for m in mods if not os.path.isfile(os.path.join(BASE_DIR, m))]
    checks.append(("Modules v1.0 présents", not missing,
                   "tous présents" if not missing else "manquants : %s" % ", ".join(missing)))
    # 3. config
    cfg_ok, cfg_port = False, "?"
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        cfg_port = cfg.get("node", {}).get("port", "?")
        cfg_ok = True
    except (OSError, ValueError):
        pass
    checks.append(("config/nexus.json lisible", cfg_ok, "port %s" % cfg_port))
    # 4. nœud
    url = default_node_url().rstrip("/")
    online = http_ok(url + "/nexus/health", 1.2)
    checks.append(("Nœud edge", online, url if online else "arrêté — nexus-ctl start"))
    # 5. workflows
    wf_ok = True
    wf_dir = os.path.join(BASE_DIR, "workflows")
    wf_n = 0
    if os.path.isdir(wf_dir):
        for fn in sorted(os.listdir(wf_dir)):
            if not fn.endswith(".json"):
                continue
            wf_n += 1
            try:
                with open(os.path.join(wf_dir, fn), "r", encoding="utf-8") as f:
                    for s in json.load(f).get("steps", []):
                        if s.get("action") not in engine.by_id:
                            wf_ok = False
            except (OSError, ValueError):
                wf_ok = False
    checks.append(("Workflows alignés", wf_ok, "%d fichiers" % wf_n))
    # 6. écriture studio/
    try:
        os.makedirs(os.path.dirname(RESULTS_FILE), exist_ok=True)
        probe = RESULTS_FILE + ".probe"
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
        w_ok = True
    except OSError:
        w_ok = False
    checks.append(("studio/ inscriptible", w_ok, "results + reports"))
    # 7. machine
    specs = _machine_specs()
    ram_ok = (specs["ram_gb"] or 0) >= 1.0
    disk_ok = (specs["disk_free_gb"] or 0) >= 0.2
    checks.append(("RAM ≥ 1 Go", ram_ok, "%s Go" % specs["ram_gb"]))
    checks.append(("Disque libre ≥ 200 Mo", disk_ok, "%s Go" % specs["disk_free_gb"]))
    # rendu + verdict
    for label, ok, detail in checks:
        mark = GREEN + "✅" + NC if ok else RED + "❌" + NC
        print("  %s %-24s %s" % (mark, label, detail))
    bad = sum(1 for _l, ok, _d in checks if not ok)
    if bad == 0:
        print("\n  %s✅ Installation prête — lancez : bash run_studio_demo.sh%s" % (BOLD, NC))
    else:
        print("\n  %s❌ %d contrôle(s) à corriger — voir --guide quickstart%s" % (RED, bad, NC))
    return 0 if bad == 0 else 1


def do_menu(engine):
    print_banner()
    while True:
        print_header("NEXUS STUDIO — CONSOLE DATACENTER PRO")
        print("   1) Catégories (400 actions)        8) Synthèse de session")
        print("   2) Voir une catégorie              9) Écran temps réel")
        print("   3) Rechercher une action          10) Pitch visuel Oracle/Google")
        print("   4) Exécuter une/des actions       11) Guide intégré")
        print("   5) Exécuter une catégorie         12) Détail d'une action")
        print("   6) Lancer un workflow             13) Nœud : démarrer / arrêter")
        print("   7) Derniers résultats              0) Quitter")
        try:
            choice = input("  Choix : ").strip()
        except (EOFError, KeyboardInterrupt):
            print("")
            break
        if choice == "0":
            break
        elif choice == "1":
            do_list(engine)
        elif choice == "2":
            do_list(engine, input("  Catégorie (ex : LAT, DEPLOY) : ").strip())
        elif choice == "3":
            do_search(engine, input("  Mot-clé : ").strip())
        elif choice == "4":
            ids = input("  ID(s) (ex : LAT-001,DEPLOY-013) : ").strip()
            if ids:
                do_run(engine, ids)
        elif choice == "5":
            cat = input("  Catégorie : ").strip().upper()
            engine.run_category(cat, limit=3)
        elif choice == "6":
            engine.list_workflows()
            name = input("  Nom du workflow (ex : pitch_demo) : ").strip()
            if name:
                res = engine.run_predefined(name)
                print("  → %s (%d/%d étapes)" % (res.get("workflow", name),
                                                res.get("steps_run", 0),
                                                res.get("steps_total", 0)))
        elif choice == "7":
            do_history(engine, 20)
        elif choice == "8":
            engine.run_action("RPT-014")
        elif choice == "9":
            print("  %s(q pour revenir à la console)%s" % (DIM, NC))
            Screen(engine).run(once=False)
            print_banner()
        elif choice == "10":
            show_pitch(engine)
        elif choice == "11":
            do_guide(input("  Sujet (latency|deploy|pitch|faq|metrics|roadmap|workflows|archi|sales|quickstart|dossier) : ").strip())
        elif choice == "12":
            do_info(engine, input("  ID de l'action (ex : LAT-001) : "))
        elif choice == "13":
            do_node_toggle(engine)
        else:
            print("  %sChoix invalide%s" % (RED, NC))
    print("  Au revoir — le nœud continue de tourner en fond.")
    print("  %sPour arrêter le nœud : python3 nexus-ctl.py stop%s" % (DIM, NC))
    return 0


def main():
    enable_colors()
    ap = argparse.ArgumentParser(
        description="NEXUS STUDIO v1.1 — Datacenter Pro : 400 actions, écran "
                    "temps réel, workflows, qualité 2× Vercel",
        epilog="Exemples :\n"
               "  bash run_studio_demo.sh\n"
               "  python3 nexus_studio.py --menu\n"
               "  python3 nexus_studio.py --screen            (q = quitter)\n"
               "  python3 nexus_studio.py --pitch\n"
               "  python3 nexus_studio.py --workflow pitch_demo\n"
               "  python3 nexus_studio.py --run LAT-001,DEPLOY-013\n"
               "  python3 nexus_studio.py --guide latency",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true",
                    help="vérifie le catalogue (400 actions)")
    ap.add_argument("--list", nargs="?", const="__all__", metavar="CAT",
                    help="catégories ou actions d'une catégorie")
    ap.add_argument("--json", action="store_true",
                    help="avec --list : sortie JSON")
    ap.add_argument("--search", metavar="MOT", help="recherche une action")
    ap.add_argument("--info", metavar="ID", help="détail d'une action (ex : LAT-001)")
    ap.add_argument("--run", metavar="ID[,ID…]", help="exécute une ou plusieurs actions")
    ap.add_argument("--history", metavar="N", type=int, nargs="?", const=20,
                    help="affiche les N derniers résultats")
    ap.add_argument("--report", action="store_true",
                    help="liste les rapports et le dernier verdict")
    ap.add_argument("--workflow", metavar="FICHIER|NOM", help="exécute un workflow")
    ap.add_argument("--workflows", action="store_true",
                    help="liste les workflows prédéfinis")
    ap.add_argument("--screen", action="store_true",
                    help="écran temps réel plein écran (q = quitter)")
    ap.add_argument("--once", action="store_true",
                    help="avec --screen : une seule frame puis sortie")
    ap.add_argument("--pitch", action="store_true",
                    help="pitch visuel Oracle/Google (mesure live)")
    ap.add_argument("--demo", action="store_true",
                    help="séquence de démonstration complète")
    ap.add_argument("--doctor", action="store_true",
                    help="diagnostic instantané de l'installation (8 contrôles)")
    ap.add_argument("--version", action="store_true",
                    help="version du Studio")
    ap.add_argument("--guide", nargs="?", const="sommaire", metavar="SUJET",
                    help="guide intégré : 11 sujets — sommaire si vide")
    ap.add_argument("--menu", action="store_true", help="console interactive")
    args = ap.parse_args()

    engine = StudioEngine()

    if args.version:
        print("NEXUS STUDIO v1.1 — Datacenter Pro (fichier unique)\n"
              "400 actions · 12 catégories · 73 primitives · 4 workflows\n"
              "Modules nexus-edge v1.0 requis, jamais modifiés.")
        return 0
    if args.doctor:
        return do_doctor(engine)
    if args.selftest:
        return do_selftest(engine)
    if args.guide is not None:
        return do_guide(args.guide)
    if args.workflows:
        engine.list_workflows()
        return 0
    if args.list is not None:
        return do_list(engine, None if args.list == "__all__" else args.list,
                       json_out=args.json)
    if args.search:
        return do_search(engine, args.search)
    if args.info:
        return do_info(engine, args.info)
    if args.history is not None:
        return do_history(engine, args.history)
    if args.report:
        return do_report(engine)
    if args.run:
        return do_run(engine, args.run)
    if args.workflow:
        return do_workflow(engine, args.workflow)
    if args.pitch:
        print_banner()
        show_pitch(engine)
        return 0
    if args.screen:
        if not sys.stdin.isatty() and not args.once:
            print("%s(écran lancé hors terminal : une frame — utilisez --menu "
                  "pour la console)%s" % (DIM, NC))
        Screen(engine).run(once=args.once or not sys.stdin.isatty())
        return 0
    if args.demo:
        return do_demo(engine)
    return do_menu(engine)


if __name__ == "__main__":
    sys.exit(main())
