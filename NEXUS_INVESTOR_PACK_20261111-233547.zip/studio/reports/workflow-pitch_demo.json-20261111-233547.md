# Workflow : pitch_demo.json

**Description** : Démonstration pour revue Oracle / Google : flotte, warm-up, Edge vs Origine, garde 2ms, intégrité, résilience, charge, qualité 2× Vercel

**Verdict** : ✅ PASS — 11/11 étapes réussies

| # | Action | Libellé | OK | Garde |
|---|---|---|---|---|
| 1 | FLEET-001 | Vue de flotte (nœuds en ligne) | ✅ | — |
| 2 | CACHE-037 | Warm-up des 6 assets critiques | ✅ | — |
| 3 | LAT-003 | Bench Edge jQuery ×100 | ✅ | p99_ms_max=0.266 |
| 4 | LAT-025 | Bench Origine CDN (comparaison) | ✅ | — |
| 5 | LAT-049 | Garde RTT p99 ≤ 2ms | ✅ | passed_is=True |
| 6 | HTTP-019 | Intégrité octets Edge = Origine | ✅ | passed_is=True |
| 7 | RESIL-001 | Stale-if-error : qualité de service | ✅ | passed_is=True |
| 8 | LOAD-001 | Charge Edge 10 workers | ✅ | errors_max=0; rps_min=5542.6 |
| 9 | DEPLOY-016 | Qualité 2× Vercel (mesure live) | ✅ | passed_is=True |
| 10 | RPT-009 | Rapport de bench | ✅ | — |
| 11 | RPT-011 | Rapport d'acceptation datacenter | ✅ | — |

Généré par NEXUS STUDIO v1.1 — 2026-11-11 23:35:47
