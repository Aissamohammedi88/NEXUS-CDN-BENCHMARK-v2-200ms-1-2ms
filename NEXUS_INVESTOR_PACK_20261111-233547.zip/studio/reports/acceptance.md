# NEXUS EDGE — Rapport d'acceptation datacenter

**Généré** : 2026-11-11 23:35:47

## Synthèse

- Actions exécutées : 71
- Réussies : 71 (100.0%)
- Meilleur p99 mesuré (chemin Nexus) : 0.223 ms
- Objectif contractuel : p99 ≤ 2 ms à <50km

## Détail par catégorie

| Catégorie | Actions |
|---|---|
| CACHE | 6 |
| CFG | 1 |
| DEPLOY | 23 |
| FLEET | 2 |
| HDR | 2 |
| HTTP | 6 |
| LAT | 13 |
| LOAD | 2 |
| PROBE | 6 |
| RESIL | 4 |
| RPT | 6 |

## Conclusion

Le chemin Nexus tient l'objectif de latence mesurée. Le déploiement
datacenter (micro-nodes <50km) transpose ces mesures à l'échelle.
