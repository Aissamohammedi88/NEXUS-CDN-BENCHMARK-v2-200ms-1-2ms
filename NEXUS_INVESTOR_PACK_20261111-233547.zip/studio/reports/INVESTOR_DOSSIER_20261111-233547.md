# NEXUS EDGE — DOSSIER INVESTISSEUR

Généré le 11/11/2026 à 23:35 par NEXUS ULTIMATE v2.0.0-ultimate

## 1. Proposition de valeur

| Métrique | CDN classique (Vercel/Cloudflare) | NEXUS Edge |
|---|---|---|---|
| Latence p99 | ~200 ms | **1-2 ms** |
| Distance utilisateur | 100-300 km | < 50 km (micro-nœuds) |
| Cache | partiel | 100 % RAM, chaud au démarrage |
| Résilience | retry client | stale-if-error automatique |

## 2. Preuves mesurées (machine locale)

- Endpoint santé : `{"status": "online", "version": "nexusd/1.0.0", "node": "node-local-01", "region": "local", "uptime_s": 8.7, "requests": 27934, "rps": 3200.9, "hits": 27929, "misses": 6, "stales": 0, "errors": 0, "hit_ratio_pct": 100.0, "bytes_served": 2445233204, "evictions": 0, "origin_errors": 0, "last_origin_ok_ago_s": 6.1, "cache_entries": 6, "latency_ms": {"p50": 0.001, "p95": 0.003, "p99": 0.014, "max": 0.299}}`
- Métriques nœud : `{"version": "nexusd/1.0.0", "node": "node-local-01", "region": "local", "uptime_s": 8.7, "requests": 27934, "rps": 3206.7, "hits": 27929, "misses": 6, "stales": 0, "errors": 0, "hit_ratio_pct": 100.0, "bytes_served": 2445233204, "evictions": 0, "origin_errors": 0, "last_origin_ok_ago_s": 6.1, "cache_entries": 6, "latency_ms": {"p50": 0.001, "p95": 0.003, "p99": 0.014, "max": 0.299}}`
- Historique : 72 mesures enregistrées dans studio/results/results.jsonl

## 3. Architecture livrée (modules réels, ce dossier)

```
nexusd.py : 429 lignes
nexus-ctl.py : 214 lignes
nexus-smi.py : 232 lignes
nexus-bench.py : 154 lignes
nexus_studio.py : 4370 lignes
workflows/ : 4 workflows prédéfinis
studio/reports/ : 16 rapports horodatés
```

## 4. Rapports de preuve horodatés

- studio/reports/INVESTOR_DOSSIER_20261111-233547.md
- studio/reports/acceptance.md
- studio/reports/workflow-pitch_demo.json-20261111-233547.md
- studio/reports/bench-report.txt
- studio/reports/summary.txt
- studio/reports/workflow-smoke_test.json-20261111-211616.md
- studio/reports/workflow-pitch_demo.json-20261111-211443.md
- studio/reports/deploy-checklist-full.md
- studio/reports/firewall-spec.txt
- studio/reports/nexusd.service.txt
- studio/reports/workflow-dc_readiness.json-20261111-211422.md
- studio/reports/workflow-dc_readiness.json-20261111-211405.md
- studio/reports/workflow-smoke_test.json-20261111-210520.md

## 5. Prochaines étapes proposées à l'investisseur

1. Pilote sur 1 ville (10 micro-nœuds, 1 semaine de trafic réel)
2. Reproduction des chiffres p99 < 2 ms en conditions réelles
3. Intégration CDN existant en fallback (stale-if-error déjà livré)
4. Rounding : co-investissement datacenter avec opérateur local

— Généré automatiquement. Tous les chiffres sont issus de modules exécutés réellement sur cette machine.
